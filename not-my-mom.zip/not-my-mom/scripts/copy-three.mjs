// Копирует Three.js в www/lib, чтобы игра работала офлайн внутри APK.
import { copyFileSync, mkdirSync, existsSync } from 'node:fs';
const src = 'node_modules/three/build/', dst = 'www/lib/';
mkdirSync(dst, { recursive: true });
for (const f of ['three.module.min.js', 'three.core.min.js']) {
  if (existsSync(src + f)) { copyFileSync(src + f, dst + f); console.log('copied', f); }
}
