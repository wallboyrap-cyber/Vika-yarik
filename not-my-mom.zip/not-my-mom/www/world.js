// Дом: стены, комнаты, мебель, свет, предметы квеста.
import * as THREE from 'three';
import { WALL_LINES, WT } from './logic.js';

function cv(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); return c; }
function tex(c, rx = 1, ry = 1) {
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry);
  t.colorSpace = THREE.SRGBColorSpace; return t;
}

const woodCv = cv(256, 256, (g, w, h) => {
  g.fillStyle = '#4a3220'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 8; i++) {
    const y = i * 32;
    g.fillStyle = `rgb(${80 + (Math.random() * 30 | 0)},${52 + (Math.random() * 20 | 0)},${30 + (Math.random() * 15 | 0)})`;
    g.fillRect(0, y, w, 30); g.fillStyle = '#20130a'; g.fillRect(0, y + 30, w, 2);
  }
});
const tileCv = cv(128, 128, (g, w, h) => {
  g.fillStyle = '#8a9494'; g.fillRect(0, 0, w, h);
  g.fillStyle = '#6e7878'; g.fillRect(0, 0, 64, 64); g.fillRect(64, 64, 64, 64);
  g.strokeStyle = '#444'; g.lineWidth = 2; g.strokeRect(0, 0, w, h);
});
const concreteCv = cv(256, 256, (g, w, h) => {
  g.fillStyle = '#4a4a48'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 2500; i++) { const v = 55 + (Math.random() * 40 | 0); g.fillStyle = `rgb(${v},${v},${v - 4})`; g.fillRect(Math.random() * w, Math.random() * h, 3, 3); }
  g.fillStyle = 'rgba(10,6,2,0.45)'; for (let i = 0; i < 6; i++) { g.beginPath(); g.arc(Math.random() * w, Math.random() * h, 20 + Math.random() * 30, 0, 7); g.fill(); }
});
const noiseCv = cv(128, 128, (g, w, h) => {
  g.fillStyle = '#9a9a9a'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 1800; i++) { const v = 130 + (Math.random() * 50 | 0); g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
});
const photoCv = cv(128, 160, (g, w, h) => {
  g.fillStyle = '#8c8470'; g.fillRect(0, 0, w, h);
  g.fillStyle = '#2a2420';
  [[30, 70], [64, 62], [98, 74]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 12, 0, 7); g.fill(); g.fillRect(x - 14, y + 14, 28, 60); });
  g.strokeStyle = '#7a0000'; g.lineWidth = 4;
  g.beginPath(); for (let i = 0; i < 14; i++) { g.lineTo(52 + Math.random() * 24, 50 + Math.random() * 24); } g.stroke();
});

export function buildWorld(scene) {
  const solids = []; const lights = [];
  const L = (c, o) => new THREE.MeshLambertMaterial(Object.assign({ color: c }, o || {}));
  const Bk = (c) => new THREE.MeshBasicMaterial({ color: c });
  const B = (cx, cy, cz, w, h, d, m, solid) => {
    const me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); me.position.set(cx, cy, cz); scene.add(me);
    if (solid) solids.push({ minx: cx - w / 2, maxx: cx + w / 2, minz: cz - d / 2, maxz: cz + d / 2 });
    return me;
  };
  const Pl = (cx, cy, cz, w, h, m, ry = 0, rx = 0) => {
    const me = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); me.position.set(cx, cy, cz); me.rotation.y = ry; me.rotation.x = rx; scene.add(me); return me;
  };
  const Cy = (cx, cy, cz, r, h, m, solid) => {
    const me = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 12), m); me.position.set(cx, cy, cz); scene.add(me);
    if (solid) solids.push({ minx: cx - r, maxx: cx + r, minz: cz - r, maxz: cz + r }); return me;
  };

  // ---------- свет
  const ambient = new THREE.AmbientLight(0x707088, 2.5); scene.add(ambient);
  const addLight = (x, y, z, color, I, D) => {
    const l = new THREE.PointLight(color, I, D, 2); l.position.set(x, y, z); scene.add(l); lights.push({ l, base: I });
    B(x, 2.77, z, 0.4, 0.05, 0.4, Bk(0xfff2c8), false);
  };
  addLight(10, 2.5, 7.5, 0xffe2b0, 22, 15);
  addLight(15.5, 2.5, 3, 0xffe8c0, 18, 13);
  addLight(5, 2.5, 12, 0xffd8a0, 16, 13);
  addLight(17, 2.5, 12, 0xff4a22, 14, 12);

  // ---------- пол и потолок
  const floor = (x1, z1, x2, z2, canvas, sc = 2) => {
    const w = x2 - x1, d = z2 - z1; const t = tex(canvas, w / sc, d / sc);
    Pl((x1 + x2) / 2, 0, (z1 + z2) / 2, w, d, L(0xffffff, { map: t }), 0, -Math.PI / 2);
  };
  floor(0, 0, 7, 6, woodCv); floor(7, 0, 11, 6, tileCv, 1); floor(11, 0, 20, 6, tileCv, 1);
  floor(0, 6, 20, 9, woodCv); floor(0, 9, 10, 15, woodCv); floor(10, 9, 14, 15, woodCv); floor(14, 9, 20, 15, concreteCv, 3);
  Pl(10, 2.8, 7.5, 20, 15, L(0x141414), 0, Math.PI / 2);

  // ---------- стены
  const wallColors = {};
  const wallMat = (cx, cz) => {
    let c = 0x7d6b5a;
    if (cz < 6 && cx < 7) c = 0x6f7a8a; else if (cz < 6 && cx < 11) c = 0x8fa3a0; else if (cz < 6) c = 0x9a8b5a;
    else if (cz > 9 && cx < 10) c = 0x7a5a5a; else if (cz > 9 && cx < 14) c = 0x6a6a5a; else if (cz > 9) c = 0x484846;
    if (!wallColors[c]) wallColors[c] = L(c, { map: tex(noiseCv, 2, 1) });
    return wallColors[c];
  };
  for (const [x1, z1, x2, z2] of WALL_LINES) {
    const len = Math.hypot(x2 - x1, z2 - z1); const cx = (x1 + x2) / 2, cz = (z1 + z2) / 2; const horiz = z1 === z2;
    B(cx, 1.4, cz, horiz ? len + WT : WT, 2.8, horiz ? WT : len + WT, wallMat(cx, cz), false);
  }

  // ---------- СПАЛЬНЯ
  const wood = L(0x5a3d27), cloth = L(0x4a5a7a), white = L(0xd8d4c8), dark = L(0x222222);
  B(1.3, 0.3, 1.3, 2.0, 0.5, 1.9, wood, true); B(1.3, 0.58, 1.4, 1.9, 0.14, 1.7, cloth, false); B(0.7, 0.7, 0.75, 0.5, 0.12, 0.7, white, false);
  B(6.4, 0.38, 3.0, 0.6, 0.76, 1.5, wood, true);
  B(4.5, 1.0, 0.475, 1.6, 2.0, 0.65, L(0x4a3322), true);               // корпус шкафа
  B(4.5, 1.0, 0.805, 1.5, 1.9, 0.02, Bk(0x050403), false);               // тёмное нутро
  B(4.5, 0.9, 0.82, 1.5, 0.04, 0.12, wood, false); B(4.5, 1.5, 0.82, 1.5, 0.04, 0.12, wood, false);
  const wL = new THREE.Group(); wL.position.set(3.72, 1.0, 0.89); scene.add(wL);
  const wLm = new THREE.Mesh(new THREE.BoxGeometry(0.78, 1.9, 0.04), L(0x6a4a30)); wLm.position.x = 0.39; wL.add(wLm);
  const wR = new THREE.Group(); wR.position.set(5.28, 1.0, 0.89); scene.add(wR);
  const wRm = new THREE.Mesh(new THREE.BoxGeometry(0.78, 1.9, 0.04), L(0x6a4a30)); wRm.position.x = -0.39; wR.add(wRm);
  const batts = [0, 1].map((i) => Cy(4.35 + i * 0.2, 1.57, 0.78, 0.04, 0.1, L(0xd0a020), false));

  // ---------- ВАННАЯ
  B(9, 0.45, 0.4, 0.8, 0.9, 0.5, white, true); B(9, 1.55, 0.12, 0.7, 0.9, 0.03, Bk(0x9aa8b0), false);
  const soap = B(9, 0.95, 0.4, 0.1, 0.04, 0.07, Bk(0xf2f2e0), false);
  B(7.7, 0.22, 0.55, 0.4, 0.45, 0.6, white, true); B(7.7, 0.6, 0.28, 0.4, 0.4, 0.15, white, false);
  B(10.2, 0.3, 2.7, 1.2, 0.6, 2.0, white, true);
  const ventHole = Pl(7.11, 1.8, 3, 0.5, 0.4, Bk(0x020202), Math.PI / 2);
  const ventGrill = Pl(7.125, 1.8, 3, 0.5, 0.4, L(0x9a9a9a, { map: tex(cv(64, 64, (g, w, h) => { g.fillStyle = '#9a9a9a'; g.fillRect(0, 0, w, h); g.fillStyle = '#222'; for (let i = 6; i < h; i += 10) g.fillRect(4, i, w - 8, 4); })) }), Math.PI / 2);
  const ventHome = ventGrill.position.clone();

  // ---------- КУХНЯ
  B(15.5, 0.45, 0.35, 6.0, 0.9, 0.7, L(0x6a5a40), true); B(15.5, 0.92, 0.38, 6.1, 0.04, 0.76, L(0xb0a890), false);
  const drawerXs = [13.2, 14.4, 15.6, 16.8, 18.0];
  const drawers = drawerXs.map((x) => B(x, 0.6, 0.72, 1.0, 0.35, 0.05, L(0x8a7550), false));
  B(17.2, 0.38, 3.6, 1.6, 0.76, 1.0, wood, true); B(19.4, 0.95, 0.9, 1.0, 1.9, 0.8, white, true);

  // ---------- КОРИДОР
  Pl(10, 0.012, 7.5, 18.5, 1.2, L(0x4a1414), 0, -Math.PI / 2);
  const frame = (x, z, ry) => { B(x, 1.6, z, 0.58, 0.72, 0.04, L(0x2a2018), false); Pl(x, 1.6, z + (ry ? -0.025 : 0.025), 0.46, 0.58, L(0xffffff, { map: tex(photoCv) }), ry); };
  frame(6, 6.14, 0); frame(1.5, 6.14, 0); frame(17.5, 6.14, 0); frame(9, 8.86, Math.PI); frame(15, 8.86, Math.PI);
  // код на стене (под слоем грязи)
  const codeCv = document.createElement('canvas'); codeCv.width = 512; codeCv.height = 256; const cg = codeCv.getContext('2d');
  const codeTex = new THREE.CanvasTexture(codeCv); codeTex.colorSpace = THREE.SRGBColorSpace;
  function drawCode(code) {
    cg.fillStyle = '#7d6b5a'; cg.fillRect(0, 0, 512, 256);
    cg.font = 'bold 120px monospace'; cg.textAlign = 'center'; cg.fillStyle = '#5a0e0e'; cg.fillText(code.split('').join(' '), 256, 150);
    codeTex.needsUpdate = true;
  }
  Pl(11.5, 1.5, 6.112, 1.6, 0.8, L(0xffffff, { map: codeTex }));
  const dirtCv = cv(512, 256, (g, w, h) => {
    g.fillStyle = 'rgba(46,36,26,0.93)'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(${20 + (Math.random() * 30 | 0)},${14 + (Math.random() * 20 | 0)},10,0.6)`; g.beginPath(); g.arc(Math.random() * w, Math.random() * h, 6 + Math.random() * 24, 0, 7); g.fill(); }
  });
  const dirt = Pl(11.5, 1.5, 6.118, 1.6, 0.8, new THREE.MeshLambertMaterial({ map: tex(dirtCv), transparent: true, opacity: 1 }));

  // ---------- ГОСТИНАЯ
  B(3.0, 0.4, 14.4, 2.4, 0.8, 0.9, L(0x4a2a2a), true); B(3.0, 0.85, 14.78, 2.4, 0.6, 0.14, L(0x4a2a2a), false);
  B(0.4, 0.3, 11, 0.5, 0.6, 1.6, wood, true); B(0.35, 0.95, 11, 0.08, 0.6, 1.0, Bk(0x07070c), false);
  B(4.2, 0.2, 12.0, 1.2, 0.4, 0.7, wood, true);
  B(0.45, 0.4, 13.6, 0.6, 0.8, 0.6, L(0x2e3236), true);                  // сейф
  B(0.78, 0.55, 13.6, 0.04, 0.12, 0.3, Bk(0x050505), false);             // клавиатура
  const safeDoor = new THREE.Group(); safeDoor.position.set(0.76, 0.4, 13.3); scene.add(safeDoor);
  const sdm = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.7, 0.6), L(0x40464c)); sdm.position.z = 0.3; safeDoor.add(sdm);
  const screwdriver = B(0.83, 0.45, 13.6, 0.04, 0.04, 0.14, Bk(0xff7a1a), false); screwdriver.visible = false;

  // ---------- ПРИХОЖАЯ
  const doorPivot = new THREE.Group(); doorPivot.position.set(11.35, 0, 15); scene.add(doorPivot);
  const doorM = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.1, 0.08), L(0x5a3a22)); doorM.position.set(0.65, 1.05, 0); doorPivot.add(doorM);
  const doorBlock = { minx: 11.3, maxx: 12.7, minz: 14.9, maxz: 15.1 };
  let doorClosed = true;
  B(13.6, 0.5, 13.0, 0.5, 1.0, 1.4, wood, true);
  B(13.55, 1.17, 12.8, 0.1, 0.34, 0.22, Bk(0x151515), false);            // рация
  B(13.55, 1.44, 12.9, 0.015, 0.2, 0.015, Bk(0x151515), false);
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), new THREE.MeshBasicMaterial({ color: 0x330000 })); led.position.set(13.5, 1.3, 12.7); scene.add(led);
  B(11.0, 0.05, 14.5, 0.8, 0.1, 0.4, Bk(0x1a1a1a), false);

  // ---------- МАСЛЯНАЯ КОМНАТА
  const barrel = L(0x3a3224);
  [[15.0, 10.2], [15.0, 11.0], [18.8, 10.0], [19.3, 11.5], [15.2, 14.2]].forEach(([x, z]) => Cy(x, 0.45, z, 0.35, 0.9, barrel, true));
  B(16.0, 0.4, 13.8, 1.2, 0.8, 1.2, L(0x4a3a24), true);
  B(17.6, 0.9, 11.6, 0.4, 1.8, 2.2, L(0x3a3a3a), true);
  B(19.5, 0.9, 13.9, 0.6, 1.8, 1.6, L(0x3a3a3a), true);
  Pl(17.0, 0.014, 12.6, 2.2, 1.4, Bk(0x050403), 0, -Math.PI / 2); Pl(16.4, 0.014, 10.4, 1.2, 1.0, Bk(0x050403), 0, -Math.PI / 2);
  const keyB = B(19.15, 1.0, 13.9, 0.08, 0.04, 0.2, Bk(0xd4af37), false);

  // ---------- входная дверь, сброс
  function setDoor(open) { doorClosed = !open; doorPivot.rotation.y = open ? -1.7 : 0; }
  setDoor(false);
  function reset(code) {
    wL.rotation.y = 0; wR.rotation.y = 0; batts.forEach((b) => { b.visible = true; });
    soap.visible = true; dirt.visible = true; dirt.material.opacity = 1; drawCode(code);
    ventGrill.position.copy(ventHome); ventGrill.rotation.set(0, Math.PI / 2, 0); ventHole.visible = true;
    keyB.visible = true; drawers.forEach((d) => { d.position.z = 0.72; });
    safeDoor.rotation.y = 0; screwdriver.visible = false; led.material.color.set(0x330000); setDoor(false);
  }
  reset('0000');

  return {
    solids, lights, ambient, doorBlock, setDoor, reset, drawCode,
    get doorClosed() { return doorClosed; },
    setBrightness(v) { ambient.intensity = v; },
    r: { wL, wR, batts, soap, dirt, ventGrill, ventHole, keyB, drawers, safeDoor, screwdriver, led },
  };
}
