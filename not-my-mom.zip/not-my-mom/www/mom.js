// «Мама»: модель из примитивов + ИИ (естественная / ищет / проверяет шум / гонится).
import * as THREE from 'three';
import { NODES, pathTo, los, nearestNode } from './logic.js';

const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (a) => a[(Math.random() * a.length) | 0];
function angDiff(a, b) { let d = a - b; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; }
function turn(cur, target, k) { return cur + angDiff(target, cur) * k; }

const WANDER = ['kit', 'liv', 'ent', 'bath', 'bed', 'hba', 'he'];
const PATROL = ['kit', 'liv', 'ent', 'bath', 'bed', 'oil', 'hW', 'hE', 'hba', 'he'];
const FLAVOR = [
  'Ты ведь любишь меня, солнышко?',
  'Почему ты так на меня смотришь?',
  'Мы ведь семья. Правда?',
  'Ты же не собираешься никуда уходить?',
  'Как хорошо, что мы снова вместе.',
  'Я так по тебе скучала.',
];

export class Mom {
  constructor(scene, cb) {
    this.cb = cb;
    this.mode = 'away'; this.pos = { x: 12, z: 17 }; this.heading = Math.PI;
    this.path = []; this.idle = 2; this.t = 0; this.searchT = 0; this.lostT = 0; this.last = null;
    this.pathSet = false; this.phase = 0; this.lastStep = 0; this.talkT = 0; this.lineT = rnd(20, 35);
    this.alertCool = 0; this.dist = 99; this.sees = false; this.chaseSpeed = 3.45;
    this.build(scene);
  }

  build(scene) {
    const g = new THREE.Group();
    const skin = new THREE.MeshLambertMaterial({ color: 0xdcc3b3 });
    const dress = new THREE.MeshLambertMaterial({ color: 0x3b5b7a });
    const hairM = new THREE.MeshLambertMaterial({ color: 0x2c1a12 });
    const black = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const mkLeg = (x) => {
      const p = new THREE.Group(); p.position.set(x, 0.78, 0);
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.78, 0.13), skin); m.position.y = -0.39; p.add(m); g.add(p); return p;
    };
    this.legL = mkLeg(-0.1); this.legR = mkLeg(0.1);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.34, 0.85, 12), dress); body.position.y = 1.0; g.add(body);
    const mkArm = (x) => {
      const p = new THREE.Group(); p.position.set(x, 1.38, 0);
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.62, 0.09), skin); m.position.y = -0.3; p.add(m); g.add(p); return p;
    };
    this.armL = mkArm(-0.27); this.armR = mkArm(0.27);
    this.head = new THREE.Group(); this.head.position.set(0, 1.58, 0); g.add(this.head);
    const hd = new THREE.Mesh(new THREE.SphereGeometry(0.13, 14, 12), skin); hd.scale.set(1, 1.2, 1); this.head.add(hd);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.14, 14, 12), hairM); hair.scale.set(1, 1.15, 1.05); hair.position.set(0, 0.02, -0.03); this.head.add(hair);
    const eye = (x) => { const e = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 8), black); e.scale.set(0.034, 0.048, 0.02); e.position.set(x, 0.03, 0.118); this.head.add(e); return e; };
    this.eyeL = eye(-0.05); this.eyeR = eye(0.05);
    this.mouth = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 8), black);
    this.mouth.position.set(0, -0.06, 0.117); this.mouth.scale.set(0.05, 0.012, 0.02); this.head.add(this.mouth);
    this.g = g; g.visible = false; scene.add(g);
  }

  reset() {
    this.mode = 'away'; this.g.visible = false; this.pos = { x: 12, z: 17 }; this.path = [];
    this.searchT = 0; this.lostT = 0; this.talkT = 0; this.last = null; this.lineT = rnd(20, 35);
  }

  enter() {
    this.pos = { x: 12, z: 15.4 }; this.heading = Math.PI; this.g.visible = true;
    this.path = [[12, 13.8], NODES.ent.slice()]; this.mode = 'enter'; this.lineT = rnd(25, 40);
  }

  talk(s) { this.talkT = s; }

  hunt(x, z) {
    this.mode = 'search'; this.searchT = 0; this.idle = 0.3;
    this.path = pathTo(this.pos.x, this.pos.z, x, z);
  }

  investigate(x, z, line) {
    this.mode = 'check'; this.path = pathTo(this.pos.x, this.pos.z, x, z); this.idle = 2.5;
    if (line) { this.cb.say(line, 'mom'); this.talkT = 2; }
  }

  startChase(line, px, pz) {
    if (this.mode !== 'chase') this.cb.chase();
    this.mode = 'chase'; this.last = { x: px, z: pz }; this.pathSet = false; this.lostT = 0;
    if (line) { this.cb.say(line, 'mom'); this.talkT = 2; }
  }

  follow(dt, speed) {
    if (!this.path.length) return false;
    const t = this.path[0]; const dx = t[0] - this.pos.x, dz = t[1] - this.pos.z; const d = Math.hypot(dx, dz);
    const step = speed * dt;
    if (d > 0.001) this.heading = turn(this.heading, Math.atan2(dx, dz), Math.min(1, dt * (this.mode === 'chase' ? 10 : 5)));
    if (d <= step) { this.pos.x = t[0]; this.pos.z = t[1]; this.path.shift(); }
    else { this.pos.x += (dx / d) * step; this.pos.z += (dz / d) * step; }
    return true;
  }

  look(dt) { this.heading += Math.sin(this.t * 1.3) * dt * 1.2; }

  update(dt, P, X) {
    if (this.mode === 'away') return;
    this.t += dt;
    const px = P.x, pz = P.z; const dx = px - this.pos.x, dz = pz - this.pos.z; const dist = Math.hypot(dx, dz);
    const lo = los(this.pos.x, this.pos.z, px, pz);
    const toP = Math.atan2(dx, dz); const ang = Math.abs(angDiff(toP, this.heading));
    const sees = lo && (dist < 2.5 || (dist < 12 && ang < 1.25) || (this.mode === 'chase' && dist < 40));
    const heard = P.noise > 0 && dist / (lo ? 1 : 1.5) < P.noise;
    this.dist = dist; this.sees = sees;
    let moving = false, spd = 0;

    switch (this.mode) {
      case 'enter':
        spd = 1.3; moving = this.follow(dt, spd);
        if (!this.path.length) { this.mode = 'natural'; this.idle = rnd(1, 2); }
        break;

      case 'natural': {
        if (sees && X.busy && dist < 10) { this.startChase('Что ты делаешь?!', px, pz); break; }
        if (heard && P.noise >= 8) { this.investigate(px, pz, 'Что это за шум?'); break; }
        this.lineT -= dt;
        if (this.lineT <= 0) { this.lineT = rnd(28, 50); if (dist < 14) { this.cb.say(pick(FLAVOR), 'mom'); this.talkT = 2.2; } }
        if (X.hold) { this.heading = turn(this.heading, toP, Math.min(1, dt * 3)); break; }
        if (this.path.length) { spd = 1.25; moving = this.follow(dt, spd); }
        else {
          this.idle -= dt;
          if (sees && dist < 9) this.heading = turn(this.heading, toP, Math.min(1, dt * 3));
          if (this.idle <= 0) { const n = pick(WANDER); this.path = pathTo(this.pos.x, this.pos.z, NODES[n][0], NODES[n][1]); this.idle = rnd(3, 7); }
        }
        break;
      }

      case 'search': {
        if (sees) { this.startChase('Нашла!', px, pz); break; }
        if (heard && P.noise >= 3.5 && this.t > this.alertCool) { this.path = pathTo(this.pos.x, this.pos.z, px, pz); this.alertCool = this.t + 3; }
        this.searchT += dt;
        if (!X.final && this.searchT > 38) {
          this.mode = 'natural'; this.idle = rnd(2, 4); this.path = [];
          this.cb.say('Ну где же ты, солнышко?.. Ладно, я не сержусь. Выходи.', 'mom'); this.talkT = 3; this.cb.calm(); break;
        }
        if (this.path.length) { spd = 1.7; moving = this.follow(dt, spd); }
        else {
          this.idle -= dt; this.look(dt);
          if (this.idle <= 0) {
            const n = Math.random() < 0.3 ? nearestNode(px, pz) : pick(PATROL);
            this.path = pathTo(this.pos.x, this.pos.z, NODES[n][0], NODES[n][1]); this.idle = rnd(1, 2.5);
          }
        }
        break;
      }

      case 'check':
        if (sees) { this.startChase('Вот ты где!', px, pz); break; }
        if (this.path.length) { spd = 1.8; moving = this.follow(dt, spd); }
        else { this.idle -= dt; this.look(dt); if (this.idle <= 0) { this.mode = 'search'; this.searchT = 18; this.idle = 1; } }
        break;

      case 'chase':
        if (lo) { this.last = { x: px, z: pz }; this.path = [[px, pz]]; this.lostT = 0; this.pathSet = false; }
        else {
          this.lostT += dt;
          if (!this.pathSet && this.last) { this.path = pathTo(this.pos.x, this.pos.z, this.last.x, this.last.z); this.pathSet = true; }
        }
        spd = this.chaseSpeed; moving = this.follow(dt, spd);
        if (lo && dist < 0.95) { this.cb.caught(); }
        if (!lo && (!this.path.length || this.lostT > 14)) {
          this.mode = 'search'; this.searchT = 0; this.idle = 1.5; this.path = [];
          this.cb.say('Куда ты делся?..', 'mom'); this.talkT = 2;
        }
        break;
      default: break;
    }

    // анимация
    this.phase += (moving ? spd : 0) * dt * 2.4;
    const swing = moving ? Math.sin(this.phase) * 0.6 : 0;
    this.legL.rotation.x = swing; this.legR.rotation.x = -swing;
    const hostile = this.mode === 'chase' || this.mode === 'search' || this.mode === 'check';
    const armT = this.mode === 'chase' ? -1.35 : 0;
    this.armL.rotation.x += ((armT - swing * 0.5) - this.armL.rotation.x) * Math.min(1, dt * 8);
    this.armR.rotation.x += ((armT + swing * 0.5) - this.armR.rotation.x) * Math.min(1, dt * 8);
    const stepIdx = Math.floor(this.phase / Math.PI);
    if (moving && stepIdx !== this.lastStep) { this.lastStep = stepIdx; this.cb.step(dist); }
    const want = (this.sees || dist < 10) ? Math.max(-1.1, Math.min(1.1, angDiff(toP, this.heading))) : 0;
    this.head.rotation.y += (want - this.head.rotation.y) * Math.min(1, dt * 4);
    this.head.rotation.z = Math.sin(this.t * 0.7) * 0.06 + (this.mode === 'chase' ? 0.25 : 0);
    this.talkT = Math.max(0, this.talkT - dt);
    let mh = 0.012, mw = 0.05;
    if (this.mode === 'chase') { mh = 0.05 + 0.02 * Math.abs(Math.sin(this.t * 18)); mw = 0.06; }
    else if (this.talkT > 0) mh = 0.012 + 0.03 * Math.abs(Math.sin(this.t * 14));
    else if (hostile) mh = 0.03;
    this.mouth.scale.set(mw, mh, 0.02);
    const es = hostile ? 1.25 : 1; this.eyeL.scale.set(0.034 * es, 0.048 * es, 0.02); this.eyeR.scale.set(0.034 * es, 0.048 * es, 0.02);
    this.g.position.set(this.pos.x, Math.abs(Math.sin(this.phase)) * (moving ? 0.03 : 0), this.pos.z);
    this.g.rotation.y = this.heading;
  }
}
