// Чистая логика без THREE: стены, комнаты, граф навигации мамы, видимость, коллизии.
export const WT = 0.2; // толщина стен

export const NODES = {
  hW: [1.2, 7.5], hb: [3.6, 7.5], hl: [4.6, 7.5], hba: [8.5, 7.5], he: [12.1, 7.5],
  hk: [14.6, 7.5], ho: [16.6, 7.5], hE: [18.8, 7.5],
  dBed: [3.6, 6], dBath: [8.5, 6], dKit: [14.6, 6], dLiv: [4.6, 9], dEnt: [12.1, 9], dOil: [16.6, 9],
  bed: [3.4, 3.4], bath: [9, 3.8], kit: [15.5, 3.6], liv: [5.8, 12.2], ent: [12, 12.8],
  oil: [17, 11.6], gap: [10, 11.6], front: [12, 14.2],
};

export const EDGES = [
  ['hW', 'hb'], ['hb', 'hl'], ['hl', 'hba'], ['hba', 'he'], ['he', 'hk'], ['hk', 'ho'], ['ho', 'hE'],
  ['hb', 'dBed'], ['dBed', 'bed'], ['hba', 'dBath'], ['dBath', 'bath'], ['hk', 'dKit'], ['dKit', 'kit'],
  ['hl', 'dLiv'], ['dLiv', 'liv'], ['he', 'dEnt'], ['dEnt', 'ent'], ['ho', 'dOil'], ['dOil', 'oil'],
  ['liv', 'gap'], ['gap', 'ent'], ['ent', 'front'],
];

function hseg(z, x1, x2, gaps = []) {
  const out = []; let cur = x1;
  for (const g of [...gaps].sort((a, b) => a - b)) { out.push([cur, z, g - 0.7, z]); cur = g + 0.7; }
  out.push([cur, z, x2, z]); return out;
}
function vseg(x, z1, z2, gaps = []) {
  const out = []; let cur = z1;
  for (const g of [...gaps].sort((a, b) => a - b)) { out.push([x, cur, x, g - 0.7]); cur = g + 0.7; }
  out.push([x, cur, x, z2]); return out;
}

// Планировка: верхний ряд — спальня, ванная, кухня; коридор z 6..9; нижний ряд — гостиная, прихожая, масляная комната
export const WALL_LINES = [
  ...hseg(0, 0, 20), ...hseg(15, 0, 20, [12]),
  ...hseg(6, 0, 20, [3.6, 8.5, 14.6]), ...hseg(9, 0, 20, [4.6, 12.1, 16.6]),
  ...vseg(0, 0, 15), ...vseg(20, 0, 15),
  ...vseg(7, 0, 6), ...vseg(11, 0, 6), ...vseg(10, 9, 15, [11.6]), ...vseg(14, 9, 15),
];

export const WALLS = WALL_LINES.map(([x1, z1, x2, z2]) => ({
  minx: Math.min(x1, x2) - WT / 2, maxx: Math.max(x1, x2) + WT / 2,
  minz: Math.min(z1, z2) - WT / 2, maxz: Math.max(z1, z2) + WT / 2,
}));

export const ROOMS = {
  bedroom: [0, 0, 7, 6], bath: [7, 0, 11, 6], kitchen: [11, 0, 20, 6],
  hall: [0, 6, 20, 9], living: [0, 9, 10, 15], entry: [10, 9, 14, 15], oil: [14, 9, 20, 15],
};

export function roomAt(x, z) {
  for (const k in ROOMS) { const [a, b, c, d] = ROOMS[k]; if (x >= a && x < c && z >= b && z < d) return k; }
  return 'out';
}

const ADJ = {};
for (const k in NODES) ADJ[k] = [];
for (const [a, b] of EDGES) { ADJ[a].push(b); ADJ[b].push(a); }

export function bfs(a, b) {
  if (a === b) return [a];
  const prev = { [a]: null }; const q = [a];
  while (q.length) {
    const c = q.shift();
    for (const n of ADJ[c]) {
      if (!(n in prev)) {
        prev[n] = c;
        if (n === b) { const out = []; let p = b; while (p) { out.unshift(p); p = prev[p]; } return out; }
        q.push(n);
      }
    }
  }
  return [a];
}

export function segBox(ax, az, bx, bz, b) {
  let t0 = 0, t1 = 1; const dx = bx - ax, dz = bz - az;
  const axes = [[ax, dx, b.minx, b.maxx], [az, dz, b.minz, b.maxz]];
  for (const [p, d, mn, mx] of axes) {
    if (Math.abs(d) < 1e-9) { if (p < mn || p > mx) return false; }
    else {
      let u = (mn - p) / d, v = (mx - p) / d; if (u > v) { const t = u; u = v; v = t; }
      t0 = Math.max(t0, u); t1 = Math.min(t1, v); if (t0 > t1) return false;
    }
  }
  return true;
}

export function los(ax, az, bx, bz) {
  for (const w of WALLS) if (segBox(ax, az, bx, bz, w)) return false;
  return true;
}

export function nearestNode(x, z) {
  let best = null, bd = 1e9, any = null, ba = 1e9;
  for (const k in NODES) {
    const [nx, nz] = NODES[k]; const d = Math.hypot(nx - x, nz - z);
    if (d < ba) { ba = d; any = k; }
    if (d < bd && los(x, z, nx, nz)) { bd = d; best = k; }
  }
  return best || any;
}

export function pathTo(x1, z1, x2, z2) {
  if (los(x1, z1, x2, z2)) return [[x2, z2]];
  const a = nearestNode(x1, z1), b = nearestNode(x2, z2);
  const pts = bfs(a, b).map((n) => NODES[n].slice());
  pts.push([x2, z2]);
  return pts;
}

// Выталкивает круг радиуса r из прямоугольников. p = {x, z}
export function pushOut(p, r, boxes) {
  for (let it = 0; it < 2; it++) {
    for (const b of boxes) {
      const cx = Math.max(b.minx, Math.min(p.x, b.maxx));
      const cz = Math.max(b.minz, Math.min(p.z, b.maxz));
      const dx = p.x - cx, dz = p.z - cz; const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-9) { const d = Math.sqrt(d2); p.x = cx + (dx / d) * r; p.z = cz + (dz / d) * r; }
        else {
          const l = p.x - b.minx, rr = b.maxx - p.x, t = p.z - b.minz, bt = b.maxz - p.z;
          const m = Math.min(l, rr, t, bt);
          if (m === l) p.x = b.minx - r; else if (m === rr) p.x = b.maxx + r;
          else if (m === t) p.z = b.minz - r; else p.z = b.maxz + r;
        }
      }
    }
  }
}
