// Процедурный звук: без внешних файлов. Всё синтезируется через WebAudio.
let ctx = null, master = null, nbuf = null, staticSrc = null, staticGain = null;

function tone(f, d, type = 'sine', v = 0.3, slide = null, delay = 0) {
  if (!ctx) return;
  const t = ctx.currentTime + delay;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(1, slide), t + d);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, v), t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + d + 0.05);
}

function noise(d, v = 0.3, ft = 'lowpass', ff = 800, q = 1, delay = 0) {
  if (!ctx) return;
  const t = ctx.currentTime + delay;
  const s = ctx.createBufferSource(); s.buffer = nbuf;
  const f = ctx.createBiquadFilter(); f.type = ft; f.frequency.value = ff; f.Q.value = q;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, v), t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  s.connect(f); f.connect(g); g.connect(master);
  s.start(t, Math.random() * 1.2); s.stop(t + d + 0.05);
}

export const A = {
  init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC(); master = ctx.createGain(); master.gain.value = 0.85; master.connect(ctx.destination);
    nbuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const data = nbuf.getChannelData(0); for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    // фоновый гул
    const o1 = ctx.createOscillator(), o2 = ctx.createOscillator();
    o1.type = 'sine'; o1.frequency.value = 43; o2.type = 'triangle'; o2.frequency.value = 45.3;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 170;
    const g = ctx.createGain(); g.gain.value = 0.08;
    o1.connect(lp); o2.connect(lp); lp.connect(g); g.connect(master); o1.start(); o2.start();
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.12;
    const lg = ctx.createGain(); lg.gain.value = 0.03; lfo.connect(lg); lg.connect(g.gain); lfo.start();
    setInterval(() => { if (Math.random() < 0.55) A.creak(); }, 9000);
  },
  knock() { for (let i = 0; i < 3; i++) { tone(95, 0.16, 'sine', 0.9, 45, i * 0.32); noise(0.09, 0.5, 'lowpass', 500, 1, i * 0.32); } },
  step(v = 0.12) { noise(0.07, v, 'lowpass', 260, 1); },
  momStep(v = 0.3) { if (v < 0.01) return; tone(70, 0.14, 'sine', v, 38); noise(0.08, v * 0.6, 'lowpass', 300, 1); },
  heart(v = 0.5) { tone(58, 0.14, 'sine', v, 36); tone(52, 0.16, 'sine', v * 0.8, 34, 0.17); },
  creak() { tone(180 + Math.random() * 120, 0.7, 'sawtooth', 0.025, 90 + Math.random() * 60); noise(0.5, 0.03, 'bandpass', 700, 6); },
  pickup() { tone(660, 0.09, 'square', 0.1); tone(990, 0.12, 'square', 0.1, null, 0.08); },
  deny() { tone(150, 0.18, 'square', 0.12, 110); },
  door() { noise(0.5, 0.35, 'lowpass', 400, 1); tone(120, 0.5, 'sawtooth', 0.12, 60); },
  sting() { tone(233, 0.9, 'sawtooth', 0.22, 190); tone(247, 0.9, 'sawtooth', 0.22, 200); noise(0.6, 0.25, 'highpass', 1800, 1); },
  scream() {
    noise(1.4, 0.9, 'highpass', 1200, 1);
    tone(620, 1.2, 'sawtooth', 0.45, 190); tone(655, 1.2, 'sawtooth', 0.4, 210); tone(55, 1.2, 'sine', 0.9, 30);
  },
  murmur(d = 1.2) {
    if (!ctx) return;
    const t = ctx.currentTime; const o = ctx.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(118, t);
    for (let i = 0; i < d * 4; i++) o.frequency.setValueAtTime(100 + Math.random() * 50, t + i * 0.25);
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 650; f.Q.value = 3;
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.07, t + 0.1); g.gain.setValueAtTime(0.07, t + d - 0.2);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(f); f.connect(g); g.connect(master); o.start(t); o.stop(t + d + 0.05);
  },
  staticOn() {
    if (!ctx || staticSrc) return;
    staticSrc = ctx.createBufferSource(); staticSrc.buffer = nbuf; staticSrc.loop = true;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 2200; f.Q.value = 0.7;
    staticGain = ctx.createGain(); staticGain.gain.value = 0.09;
    staticSrc.connect(f); f.connect(staticGain); staticGain.connect(master); staticSrc.start();
  },
  staticOff() { if (staticSrc) { try { staticSrc.stop(); } catch (e) { /* уже остановлен */ } staticSrc = null; } },
};
