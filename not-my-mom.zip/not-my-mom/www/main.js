import * as THREE from 'three';
import { A } from './audio.js';
import { buildWorld } from './world.js';
import { Mom } from './mom.js';
import { WALLS, roomAt, pushOut, los } from './logic.js';

const $ = (id) => document.getElementById(id);
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pick = (a) => a[(Math.random() * a.length) | 0];

// ---------- рендер
const renderer = new THREE.WebGLRenderer({ canvas: $('c'), antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x020203);
scene.fog = new THREE.FogExp2(0x020203, 0.07);
const camera = new THREE.PerspectiveCamera(72, 1, 0.05, 45);
camera.rotation.order = 'YXZ';
scene.add(camera);
const torch = new THREE.PointLight(0xffe2b8, 16, 11, 2);
camera.add(torch);
function resize() { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();

const W = buildWorld(scene);
const staticCols = WALLS.concat(W.solids);

// ---------- состояние
let state = 'menu'; // menu | play | dead | won
const P = { x: 3.4, z: 2.4, yaw: Math.PI, pitch: 0, stam: 4, tired: false, busy: false, noise: 0, moveNoise: 0, bob: 0, stepT: 0 };
const S = {};
const T = {};
let order = null, holdMom = false, modal = false, inp = '', danger = 0, heartT = 0, subT = 0, clock = 0;
let actDown = false, actEdge = false, consumed = false, heldObj = null;

function resetState() {
  Object.assign(S, {
    batt: false, soap: false, screw: false, keyA: false, keyB: false, tape: false, key: false,
    wardrobeOpen: false, codeRev: false, safeOpen: false, ventOpen: false, radioFixed: false, called: false,
    momIn: false, drawers: [0, 0, 0, 0, 0], tapeIdx: (Math.random() * 5) | 0,
    code: String(1000 + ((Math.random() * 9000) | 0)),
  });
  Object.assign(T, { knockT: 7, wait: 0, k: 0, nextOrder: 30, oilT: 0, oilAlert: false, noiseUntil: 0, noiseR: 0 });
  Object.assign(P, { x: 3.4, z: 2.4, yaw: Math.PI, pitch: 0, stam: 4, tired: false });
  order = null; holdMom = false; modal = false; danger = 0;
}

// ---------- субтитры, шум
function say(text, who = 'me', ms = 4200) {
  const s = $('sub'); s.textContent = text; s.className = who; s.style.opacity = 1; subT = ms / 1000;
  if (who === 'mom') A.murmur(Math.min(2.6, text.length * 0.05 + 0.6));
}
function makeNoise(r, secs = 0.4) { T.noiseR = Math.max(T.noiseR * (clock < T.noiseUntil ? 1 : 0), r); T.noiseUntil = clock + secs; }

const mom = new Mom(scene, {
  say: (t, w) => say(t, w),
  step: (d) => A.momStep(clamp(0.35 - d * 0.03, 0, 0.35)),
  chase: () => { A.sting(); },
  calm: () => { T.nextOrder = rnd(25, 40); },
  caught: () => caught(),
});

// ---------- предметы и взаимодействия
const D = [13.2, 14.4, 15.6, 16.8, 18.0];
const I = [];
const add = (o) => { o.prog = 0; I.push(o); };

function checkCraft() {
  if (S.keyA && S.keyB && S.tape && !S.key) { S.key = true; say('Склеил две части ключа скотчем. Теперь у меня есть ключ от двери.', 'me', 5500); A.pickup(); }
}
function take(msg) { A.pickup(); say(msg); renderInv(); checkCraft(); renderInv(); }

function openForMom(auto) {
  S.momIn = true; W.setDoor(true); A.door(); mom.enter(); T.nextOrder = 30;
  say(auto ? 'У меня есть ключ, солнышко. Что ж ты не открываешь?' : 'Наконец-то. Почему так долго? Я замёрзла, солнышко.', 'mom', 5000);
  setTimeout(() => { if (state === 'play') { W.setDoor(false); A.door(); } }, 3500);
  renderInv();
}

add({ id: 'door', p: [12, 1.2, 14.8], r: 2.4, st: () => {
  if (!S.momIn) return { label: 'Открыть дверь', run: () => openForMom(false) };
  if (!S.key) return { label: 'Входная дверь', blocked: 'Заперто. Нужен ключ.' };
  if (!S.called) return { label: 'Входная дверь', blocked: 'Если я выбегу сейчас, она догонит. Сначала нужно вызвать помощь по рации.' };
  return { label: 'Открыть ключом и бежать', hold: 2.5, noise: 6, run: () => win() };
} });

add({ id: 'wardrobe', p: [4.5, 1.0, 1.1], st: () => {
  if (!S.wardrobeOpen) return { label: 'Поддеть дверцу скребком', hold: 2.5, noise: 5, run: () => {
    S.wardrobeOpen = true; W.r.wL.rotation.y = -1.9; W.r.wR.rotation.y = 1.9; A.creak(); say('Дверца поддалась. Внутри батарейки.'); } };
  if (!S.batt) return { label: 'Взять батарейки', run: () => { S.batt = true; W.r.batts.forEach((b) => { b.visible = false; }); take('Две батарейки. Пригодятся для рации.'); } };
  return null;
} });

add({ id: 'soap', p: [9, 1.0, 0.8], st: () => (S.soap ? null : { label: 'Взять мыло', run: () => { S.soap = true; W.r.soap.visible = false; take('Кусок мыла.'); } }) });

add({ id: 'code', p: [11.5, 1.5, 6.3], keep: true, st: () => {
  if (S.codeRev) return null;
  if (!S.soap) return { label: 'Грязное пятно на стене', blocked: 'Под слоем грязи что-то написано. Нужно чем-то оттереть.' };
  return { label: 'Оттереть стену мылом', hold: 3.5, noise: 5, keep: true, run: () => {
    S.codeRev = true; W.r.dirt.visible = false; say(`На стене цифры: ${S.code}. Запомню.`, 'me', 6000); renderInv(); A.pickup(); } };
} });

add({ id: 'safe', p: [0.9, 0.6, 13.6], st: () => {
  if (!S.safeOpen) return { label: 'Открыть сейф', run: () => openSafe() };
  if (!S.screw) return { label: 'Взять отвёртку', run: () => { S.screw = true; W.r.screwdriver.visible = false; take('Отвёртка.'); } };
  return null;
} });

add({ id: 'vent', p: [7.3, 1.7, 3.0], keep: true, st: () => {
  if (S.ventOpen) return null;
  if (!S.screw) return { label: 'Вентиляция', blocked: 'Решётка закручена винтами. Нужна отвёртка.' };
  return { label: 'Открутить вентиляцию', hold: 3, noise: 7, keep: true, run: () => {
    S.ventOpen = true; S.keyA = true; W.r.ventGrill.position.set(7.45, 0.3, 3.0); W.r.ventGrill.rotation.set(0, Math.PI / 2, 1.4);
    take('Внутри лежала часть ключа (1/2).'); } };
} });

add({ id: 'keyB', p: [19.15, 1.0, 13.9], st: () => (S.keyB ? null : { label: 'Взять часть ключа', run: () => {
  S.keyB = true; W.r.keyB.visible = false; makeNoise(4, 1); take('Вторая часть ключа. Надо быстрее уходить отсюда.'); } }) });

D.forEach((x, i) => add({ id: 'drawer' + i, p: [x, 0.65, 0.9], st: () => {
  if (S.drawers[i]) return null;
  return { label: 'Открыть ящик', hold: 0.8, noise: 5, run: () => {
    S.drawers[i] = 1; W.r.drawers[i].position.z = 1.05; A.creak();
    if (i === S.tapeIdx) { S.tape = true; take('Скотч!'); }
    else say(pick(['Пусто.', 'Старые ложки.', 'Какие-то тряпки.', 'Только крошки.', 'Нитки и пуговицы.']));
  } };
} }));

add({ id: 'radio', p: [13.5, 1.2, 12.8], st: () => {
  if (!S.radioFixed) {
    if (!S.batt) return { label: 'Рация', blocked: 'Рация не включается. Нужны батарейки.' };
    return { label: 'Вставить батарейки', hold: 2.5, noise: 4, run: () => { S.radioFixed = true; W.r.led.material.color.set(0x22ff44); A.pickup(); say('Рация ожила. Теперь нужен ключ, чтобы можно было сбежать.', 'me', 5000); } };
  }
  if (!S.called) {
    if (!S.key) return { label: 'Рация', blocked: 'Рация работает. Сначала нужен ключ: позвоню — и сразу бежать.' };
    return { label: 'Вызвать милицию', hold: 6, noise: 14, run: () => {
      S.called = true; A.staticOff(); say('— Дежурный слушает. — Это не моя мама! Приезжайте! — Выезжаем. Держитесь.', 'me', 6500);
      mom.hunt(P.x, P.z); mom.talk(3); setTimeout(() => say('Ты с кем там разговариваешь?..', 'mom'), 3000); } };
  }
  return null;
} });

// ---------- цели
const OBJ = [
  [() => S.momIn, 'Кто-то стучит. Подойди к входной двери.'],
  [() => S.batt, 'У тебя только скребок. Что им можно открыть?'],
  [() => S.soap, 'Найди, чем оттереть грязь со стены.'],
  [() => S.codeRev, 'В коридоре на стене что-то написано под грязью.'],
  [() => S.screw, 'Найди сейф и открой его кодом.'],
  [() => S.keyA, 'Открути вентиляцию в ванной.'],
  [() => S.keyB, 'Вторая часть ключа в масляной комнате. Не задерживайся там дольше 10 секунд!'],
  [() => S.tape, 'Чем склеить две части ключа? Поищи в ящиках.'],
  [() => S.radioFixed, 'Почини рацию батарейками.'],
  [() => S.called, 'Вызови помощь по рации.'],
];
function objective() { for (const [f, t] of OBJ) if (!f()) return t; return 'БЕГИ К ВХОДНОЙ ДВЕРИ!'; }

function renderInv() {
  const c = ['🧰 скребок'];
  if (S.batt) c.push(S.radioFixed ? '' : '🔋 батарейки');
  if (S.soap && !S.codeRev) c.push('🧼 мыло');
  if (S.codeRev && !S.safeOpen) c.push('🔢 код ' + S.code);
  if (S.screw) c.push('🪛 отвёртка');
  if (S.key) c.push('🗝 ключ'); else if (S.keyA || S.keyB) c.push(`🗝 часть ключа ${(S.keyA ? 1 : 0) + (S.keyB ? 1 : 0)}/2`);
  if (S.tape && !S.key) c.push('📎 скотч');
  $('inv').innerHTML = c.filter(Boolean).map((t) => `<span>${t}</span>`).join('');
}

// ---------- сейф
const pad = $('pad');
['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].forEach((k) => {
  const b = document.createElement('button'); b.textContent = k; b.addEventListener('click', () => keypad(k)); pad.appendChild(b);
});
const closeB = document.createElement('button'); closeB.className = 'x'; closeB.textContent = 'Закрыть'; closeB.addEventListener('click', closeSafe); pad.appendChild(closeB);
function openSafe() { modal = true; inp = ''; $('disp').textContent = ''; $('safe').style.display = 'flex'; }
function closeSafe() { modal = false; $('safe').style.display = 'none'; }
function keypad(k) {
  A.step(0.15);
  if (k === 'C') inp = '';
  else if (k === 'OK') {
    if (inp === S.code) {
      S.safeOpen = true; W.r.safeDoor.rotation.y = 1.6; W.r.screwdriver.visible = true; closeSafe(); A.door(); makeNoise(6, 1); say('Щёлк. Сейф открылся. Внутри отвёртка.');
    } else { A.deny(); const d = $('disp'); d.classList.remove('shake'); void d.offsetWidth; d.classList.add('shake'); inp = ''; makeNoise(5, 0.6); }
  } else if (inp.length < 4) inp += k;
  $('disp').textContent = inp;
}

// ---------- ввод
const keys = {}; let jx = 0, jy = 0, stickRun = false;
addEventListener('keydown', (e) => {
  keys[e.code] = true;
  if ((e.code === 'KeyE' || e.code === 'Space' || e.code === 'KeyF') && !actDown) { actDown = true; actEdge = true; }
  if (e.code === 'Escape' && modal) closeSafe();
});
addEventListener('keyup', (e) => { keys[e.code] = false; if (e.code === 'KeyE' || e.code === 'Space' || e.code === 'KeyF') actDown = false; });

const touch = $('touch'); let stickId = null, lookId = null, sO = { x: 0, y: 0 }, lastL = { x: 0, y: 0 };
const stickEl = $('stick'), knob = $('knob'); const R = 65;
touch.addEventListener('pointerdown', (e) => {
  e.preventDefault(); A.init();
  if (e.pointerType === 'mouse') { if (document.pointerLockElement !== touch && touch.requestPointerLock) touch.requestPointerLock(); else { actDown = true; actEdge = true; } return; }
  try { touch.setPointerCapture(e.pointerId); } catch (_) { /* не критично */ }
  if (e.clientX < innerWidth * 0.45 && stickId === null) {
    stickId = e.pointerId; sO = { x: e.clientX, y: e.clientY };
    stickEl.style.display = 'block'; stickEl.style.left = e.clientX + 'px'; stickEl.style.top = e.clientY + 'px'; knob.style.transform = '';
  } else if (e.clientX >= innerWidth * 0.45 && lookId === null) { lookId = e.pointerId; lastL = { x: e.clientX, y: e.clientY }; }
});
touch.addEventListener('pointermove', (e) => {
  if (e.pointerType === 'mouse') return;
  if (e.pointerId === stickId) {
    let dx = e.clientX - sO.x, dy = e.clientY - sO.y; const l = Math.hypot(dx, dy); if (l > R) { dx = dx / l * R; dy = dy / l * R; }
    jx = dx / R; jy = -dy / R; knob.style.transform = `translate(${dx}px,${dy}px)`;
    stickRun = Math.hypot(jx, jy) > 0.95; knob.className = stickRun ? 'run' : '';
  } else if (e.pointerId === lookId) {
    P.yaw -= (e.clientX - lastL.x) * 0.0062; P.pitch = clamp(P.pitch - (e.clientY - lastL.y) * 0.0052, -1.2, 1.2); lastL = { x: e.clientX, y: e.clientY };
  }
});
const up = (e) => {
  if (e.pointerType === 'mouse') { actDown = false; return; }
  if (e.pointerId === stickId) { stickId = null; jx = jy = 0; stickRun = false; stickEl.style.display = 'none'; }
  if (e.pointerId === lookId) lookId = null;
};
touch.addEventListener('pointerup', up); touch.addEventListener('pointercancel', up);
document.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement === touch) { P.yaw -= e.movementX * 0.0025; P.pitch = clamp(P.pitch - e.movementY * 0.0025, -1.2, 1.2); }
});
const act = $('act');
act.addEventListener('pointerdown', (e) => { e.preventDefault(); A.init(); actDown = true; actEdge = true; try { act.setPointerCapture(e.pointerId); } catch (_) { /* не критично */ } });
const actUp = () => { actDown = false; }; act.addEventListener('pointerup', actUp); act.addEventListener('pointercancel', actUp);
document.addEventListener('contextmenu', (e) => e.preventDefault());

// ---------- игровая логика
function movePlayer(dt) {
  let mx = jx, my = jy;
  if (keys.KeyW || keys.ArrowUp) my += 1; if (keys.KeyS || keys.ArrowDown) my -= 1;
  if (keys.KeyD || keys.ArrowRight) mx += 1; if (keys.KeyA || keys.ArrowLeft) mx -= 1;
  if (modal) { mx = 0; my = 0; }
  let mag = Math.hypot(mx, my); if (mag > 1) { mx /= mag; my /= mag; mag = 1; }
  const moving = mag > 0.05;
  const wantRun = stickRun || keys.ShiftLeft || keys.ShiftRight;
  const run = moving && wantRun && !P.tired && P.stam > 0;
  if (run) { P.stam -= dt; if (P.stam <= 0) { P.stam = 0; P.tired = true; } }
  else { P.stam = Math.min(4, P.stam + dt * 0.7); if (P.tired && P.stam > 1.5) P.tired = false; }
  const sp = run ? 3.7 : 2.2;
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw), rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw);
  const p = { x: P.x + (fx * my + rx * mx) * sp * dt, z: P.z + (fz * my + rz * mx) * sp * dt };
  pushOut(p, 0.3, staticCols); if (W.doorClosed) pushOut(p, 0.3, [W.doorBlock]);
  P.x = p.x; P.z = p.z;
  P.moveNoise = moving ? (run ? 9 : 3.5) : 0;
  if (moving) { P.bob += dt * (run ? 11 : 7); P.stepT -= dt; if (P.stepT <= 0) { P.stepT = run ? 0.32 : 0.52; A.step(run ? 0.22 : 0.12); } }
  const st = $('stam'); st.style.opacity = P.stam < 3.9 ? 0.8 : 0; st.firstChild.style.width = (P.stam / 4 * 100) + '%';
  st.firstChild.style.background = P.tired ? '#a33' : '#d8d0b8';
}

const KNOCKS = ['Солнышко, открой, это мама!', 'Я же слышу, что ты дома.', 'Открой дверь, мне холодно...', 'Солнышко... почему ты молчишь?'];
function intro(dt) {
  if (S.momIn) return;
  T.knockT -= dt; T.wait += dt;
  if (T.knockT <= 0) { T.knockT = rnd(18, 24); A.knock(); say(KNOCKS[T.k++ % KNOCKS.length], 'mom'); }
  if (T.wait > 150) openForMom(true);
}

const dist2 = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const ORDERS = [
  { k: 'come', s: 'Солнышко, подойди ко мне. Мне нужна твоя помощь.', h: 'Подойди к маме', ok: () => dist2(mom.pos, P) < 2.7 },
  { k: 'kitchen', s: 'Иди на кухню. Я приготовила тебе поесть.', h: 'Иди на кухню', ok: () => roomAt(P.x, P.z) === 'kitchen' },
  { k: 'bedroom', s: 'Уже поздно. Иди в свою комнату.', h: 'Иди в свою комнату', ok: () => roomAt(P.x, P.z) === 'bedroom' },
  { k: 'bath', s: 'Ты весь грязный. Иди умойся.', h: 'Иди в ванную', ok: () => roomAt(P.x, P.z) === 'bath' },
];
function orders(dt) {
  const el = $('order');
  if (!S.momIn || mom.mode !== 'natural') { if (order && mom.mode !== 'natural') { order = null; holdMom = false; } el.textContent = ''; return; }
  if (!order) {
    el.textContent = ''; T.nextOrder -= dt;
    if (T.nextOrder <= 0) {
      const cand = ORDERS.filter((o) => !o.ok()); order = { ...pick(cand), t: 25 };
      say(order.s, 'mom', 5000); mom.talk(3); holdMom = order.k === 'come';
    }
    return;
  }
  order.t -= dt;
  if (order.ok()) { say('Умница.', 'mom'); order = null; holdMom = false; T.nextOrder = rnd(35, 60); el.textContent = ''; return; }
  el.textContent = `Мама ждёт: ${order.h} (${Math.ceil(order.t)})`;
  if (order.t <= 0) {
    say('Ты меня не слышишь?.. Я же просила.', 'mom'); order = null; holdMom = false; mom.hunt(P.x, P.z); el.textContent = '';
  }
}

function oil(dt) {
  const inOil = roomAt(P.x, P.z) === 'oil';
  T.oilT = inOil ? T.oilT + dt : Math.max(0, T.oilT - dt * 0.6);
  if (T.oilT > 10 && !T.oilAlert && S.momIn && (mom.mode === 'natural' || mom.mode === 'search')) {
    T.oilAlert = true; order = null; holdMom = false; mom.investigate(17, 11.2, 'Кто там? Я слышу тебя!');
  }
  if (T.oilT <= 0) T.oilAlert = false;
  const bar = $('oilbar'); bar.style.opacity = T.oilT > 1 ? 1 : 0; bar.querySelector('i').style.width = Math.min(100, T.oilT * 10) + '%';
}

function findTarget() {
  let best = null, bs = -1e9;
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw); // наведение только по горизонтали, чтобы не целиться по высоте
  for (const o of I) {
    const st = o.st(); if (!st) continue;
    const dx = o.p[0] - P.x, dz = o.p[2] - P.z; const d = Math.hypot(dx, dz);
    if (d > (o.r || 2.1)) continue;
    const dot = d > 0.01 ? (fx * dx + fz * dz) / d : 1; if (dot < 0.72 && d > 0.7) continue;
    if (!los(P.x, P.z, o.p[0], o.p[2])) continue;
    const sc = dot * 2 - d * 0.3; if (sc > bs) { bs = sc; best = { o, st }; }
  }
  return best;
}

function interact(dt) {
  let t = null; if (!modal) t = findTarget();
  const st = t ? t.st : null;
  $('prompt').textContent = st ? st.label : '';
  act.classList.toggle('on', !!st && !st.blocked);
  P.busy = modal;
  heldObj = null;
  if (!actDown) consumed = false;
  if (st && actEdge) {
    if (st.blocked) { say(st.blocked); A.deny(); }
    else if (!st.hold) { st.run(); consumed = true; }
  }
  if (st && actDown && !st.blocked && st.hold > 0 && !consumed) {
    heldObj = t.o; t.o.prog += dt / st.hold; P.busy = true;
    if (st.noise) makeNoise(st.noise, 0.3);
    if (t.o.prog >= 1) { t.o.prog = 0; consumed = true; st.run(); }
  }
  actEdge = false;
  for (const o of I) if (o !== heldObj && !o.keep) o.prog = 0;
  const h = $('hold'); const pr = t ? t.o.prog : 0; h.style.opacity = pr > 0 ? 1 : 0; h.firstChild.style.width = (pr * 100) + '%';
  if (!S.codeRev) W.r.dirt.material.opacity = 1 - I.find((o) => o.id === 'code').prog;
  if (S.called === false && S.radioFixed && heldObj && heldObj.id === 'radio') A.staticOn(); else if (!S.called) A.staticOff();
  $('obj').textContent = objective();
}

function caught() {
  if (state !== 'play') return;
  state = 'dead'; A.staticOff(); A.scream();
  const f = $('flash'); f.style.opacity = 1; setTimeout(() => { f.style.opacity = 0; }, 140);
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);
  mom.pos.x = P.x + fx * 0.7; mom.pos.z = P.z + fz * 0.7; mom.heading = Math.atan2(-fx, -fz); mom.mode = 'chase'; mom.path = []; mom.talkT = 9;
  P.pitch = 0.2; if (modal) closeSafe();
  setTimeout(() => showOver('Она нашла тебя', '«Умница, — прошептала мама. — Теперь мы всегда будем вместе».', 'Попробовать снова'), 1600);
}
function win() {
  state = 'won'; A.staticOff(); A.door();
  showOver('Ты выбрался', 'Через несколько минут приехала милиция. Дом оказался пустым. Только на кухонном столе лежала записка: «Я скоро вернусь, солнышко. Мама».', 'Играть снова');
}
function showOver(t, p, b) { $('overT').textContent = t; $('overP').textContent = p; $('again').textContent = b; $('over').style.display = 'flex'; }

function startGame() {
  resetState(); W.reset(S.code); mom.reset(); renderInv(); $('over').style.display = 'none'; $('menu').style.display = 'none';
  $('sub').style.opacity = 0; $('order').textContent = ''; state = 'play';
  say('Ты один дома. Родители велели никому не открывать...', 'me', 5000);
}
$('start').addEventListener('click', () => {
  A.init(); W.setBrightness(parseFloat($('bri').value));
  const el = document.documentElement; if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
  if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {});
  startGame();
});
$('again').addEventListener('click', () => { A.init(); startGame(); });
$('bri').addEventListener('input', () => W.setBrightness(parseFloat($('bri').value)));

// ---------- цикл
function frame(dt) {
  clock += dt;
  P.noise = Math.max(P.moveNoise, clock < T.noiseUntil ? T.noiseR : 0);
  if (state === 'play') {
    movePlayer(dt); intro(dt); orders(dt); oil(dt); interact(dt);
    mom.update(dt, P, { busy: P.busy, final: S.called, hold: holdMom });
  } else if (state === 'dead') {
    mom.update(dt * 0.001, P, { busy: false, final: true, hold: true });
  }
  // опасность: виньетка, сердцебиение, мерцание
  let d1 = 0;
  if (state === 'play' && mom.mode === 'chase') d1 = 1;
  else if (state === 'play' && (mom.mode === 'search' || mom.mode === 'check')) d1 = clamp(1 - (mom.dist - 3) / 12, 0.15, 0.8);
  const target = state === 'dead' ? 1 : Math.max(d1, (T.oilT || 0) / 10 * 0.6);
  danger += (target - danger) * Math.min(1, dt * 2);
  $('vig').style.opacity = clamp(danger * 0.9, 0, 0.9);
  if (danger > 0.12 && state === 'play') { heartT -= dt; if (heartT <= 0) { heartT = 1.3 - danger * 0.8; A.heart(0.25 + danger * 0.5); } }
  W.lights.forEach(({ l, base }) => { l.intensity = base * (danger > 0.5 && Math.random() < 0.06 ? 0.15 : (state === 'dead' ? 0.4 : 1)); });
  if (subT > 0) { subT -= dt; if (subT <= 0) $('sub').style.opacity = 0; }
  // камера
  const shake = state === 'dead' ? 0.02 : 0;
  camera.position.set(P.x + (Math.random() - 0.5) * shake, 1.6 + Math.sin(P.bob) * 0.035, P.z + (Math.random() - 0.5) * shake);
  camera.rotation.set(P.pitch, P.yaw, Math.sin(P.bob * 0.5) * 0.004, 'YXZ');
  renderer.render(scene, camera);
}
let last = performance.now();
renderer.setAnimationLoop((now) => { const dt = Math.min(0.05, (now - last) / 1000); last = now; frame(dt); });

resetState(); W.reset(S.code); renderInv();

// для отладки в консоли
window.__game = { P, S, T, mom, I, W, frame, get state() { return state; } };
