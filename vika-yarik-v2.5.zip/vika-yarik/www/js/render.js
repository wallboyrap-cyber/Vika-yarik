'use strict';
/* Рисование мира: дом (все этажи и подвал), двор и амбар — в двух режимах камеры:
   'side' — вид сбоку (2D, как раньше), 'top' — вид сверху. */

/* ---------- геометрия дома ---------- */
const ROOM_X = [30, 230, 430], ROOM_W = 200, FL = 410, CEIL = 190;   // вид сбоку (этаж 1)
const HX0 = 30, HY0 = 112, HW = 600, HH = 340;                       // вид сверху: план этажа
const WALLS = { bedwall: ['#e9b7c8', 0], kitwall: ['#bfe3cd', 1], livwall: ['#f0d9a0', 2] };
const TRASH = [
  { x: 75, y: 230, e: '🗑️' }, { x: 170, y: 150, e: '📦' }, { x: 265, y: 260, e: '🪵' },
  { x: 350, y: 100, e: '📰' }, { x: 490, y: 200, e: '🍂' }, { x: 585, y: 250, e: '🧱' },
];
/* Мебель: f — этаж, sx — положение в виде сбоку, tp — прямоугольник в виде сверху [x, y, w, h]. */
const FURN = {
  bed:      { f: 1, sx: 44,  tp: [44, 40, 92, 130],   col: '#d9566f', ic: '🛏️' },
  wardrobe: { f: 1, sx: 160, tp: [150, 8, 64, 40],    col: '#8a5a2b', ic: '🚪' },
  stove:    { f: 1, sx: 240, tp: [244, 8, 60, 40],    col: '#c9ccd2', ic: '🍳' },
  table:    { f: 1, sx: 308, tp: [290, 150, 90, 70],  col: '#a87a4a', ic: '🍽️' },
  fridge:   { f: 1, sx: 382, tp: [376, 8, 44, 44],    col: '#eef3f6', ic: '🧊' },
  sofa:     { f: 1, sx: 440, tp: [470, 130, 110, 48], col: '#3f8f9c', ic: '🛋️' },
  tv:       { f: 1, sx: 570, tp: [490, 10, 70, 24],   col: '#1b1b22', ic: '📺' },
  dtable:   { f: 2, sx: 70,  tp: [90, 110, 160, 110], col: '#a87a4a', ic: '🍽️' },
  chand:    { f: 2, sx: 170, tp: [160, 150, 30, 30],  col: '#ffd98a', ic: '💡' },
  bar:      { f: 2, sx: 40,  tp: [40, 30, 140, 36],   col: '#7e5830', ic: '🍸' },
  arm:      { f: 2, sx: 380, tp: [380, 200, 70, 60],  col: '#b0603c', ic: '🪑' },
  fire:     { f: 2, sx: 480, tp: [450, 10, 100, 40],  col: '#7a4a3a', ic: '🔥' },
  shelf:    { f: 2, sx: 570, tp: [570, 60, 40, 150],  col: '#6e4720', ic: '📚' },
  mat:      { f: 3, sx: 60,  tp: [60, 60, 120, 60],   col: '#58b0bd', ic: '🧘' },
  treadm:   { f: 3, sx: 240, tp: [240, 40, 70, 130],  col: '#2b2b33', ic: '🏃' },
  weights:  { f: 3, sx: 360, tp: [360, 60, 120, 50],  col: '#8e929a', ic: '🏋️' },
  bike:     { f: 3, sx: 520, tp: [510, 50, 60, 90],   col: '#d9792f', ic: '🚴' },
  mirror:   { f: 3, sx: 60,  tp: [60, 24, 250, 10],    col: '#bfe6f2', ic: '🪞' },
};
/* Куда вставлять картинки мебели в виде сверху [x, y, w, h]; картинка вписывается с сохранением пропорций. */
const TI = {
  bed: [44, 40, 92, 130], wardrobe: [148, 2, 68, 98], stove: [240, 2, 66, 104], table: [286, 126, 92, 104],
  fridge: [372, 2, 58, 92], sofa: [466, 122, 120, 62], tv: [488, 0, 68, 62], dtable: [60, 96, 220, 150],
  chand: [146, 132, 62, 50], bar: [30, 4, 190, 100], arm: [380, 196, 74, 70], fire: [438, 4, 140, 86],
  shelf: [566, 40, 58, 156], mat: [56, 56, 130, 76], treadm: [236, 36, 78, 148], weights: [352, 40, 130, 84],
  bike: [506, 44, 66, 96], mirror: [60, 18, 250, 26],
};
const CARPET_TP = [455, 70, 130, 90];

/* Куда идти, чтобы сменить место или этаж (логические координаты места). */
const EXITS = {
  house: { door: { x: 330, y: 316 }, up: { x: 600, y: 70 }, down: { x: 600, y: 296 }, hatch: { x: 62, y: 296 }, base: { x: 62, y: 70 } },
  yard:  { house: { x: 175, y: 176 }, barn: { x: 530, y: 176 } },
  barn:  { door: { x: 70, y: 300 } },
};
/* Границы, где можно ходить в каждом месте (логические координаты). */
const BOUNDS = {
  house: { x0: 48, x1: 612, y0: 28, y1: 318 },
  yard:  { x0: 30, x1: 635, y0: 150, y1: 535 },
  barn:  { x0: 48, x1: 612, y0: 40, y1: 318 },
};

/* ---------- сетка грядок ---------- */
const PCOLS = 6;
function plotRect(i, mode) {
  const col = i % PCOLS, row = Math.floor(i / PCOLS);
  return mode === 'top' ? [36 + col * 100 + 6, 178 + row * 58, 88, 50] : [36 + col * 100 + 6, 168 + row * 54, 88, 44];
}
const stallPos = (k, mode) => mode === 'top' ? [130 + (k % 3) * 190, 170 + Math.floor(k / 3) * 140] : [150 + k * 90, 0];
const podPos = (k, mode) => mode === 'top' ? [120 + (k % 4) * 130, 170 + Math.floor(k / 4) * 120] : [100 + k * 66, 0];

const ALL_ITEMS = [].concat.apply([], ROOMS.map(r => r.items));
const EXTRA_ITEMS = [].concat.apply([], ROOMS2.map(r => r.items));
const CROP = {}; CROPS.forEach(k => CROP[k.id] = k);
CROP.mega = { id: 'mega', name: 'Мега-растение', cost: 0, rate: 0 };
const EMOJI_FONT = '"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
const topFloor = () => S.floors[3] ? 3 : S.floors[2] ? 2 : 1;

const blob = (x, y, r) => { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); };
const rect = (col, x, y, w, h) => { c.fillStyle = col; c.fillRect(x, y, w, h); };
const emo = (e, x, y, sz) => { c.font = sz + 'px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(e, x, y); };

/* ---------- мебель: вид сбоку ---------- */
const IDRAW = {
  bed(x) { rect('#6b4a32', x, FL - 30, 86, 30); rect('#e9e2d6', x + 4, FL - 42, 78, 14); rect('#e9748f', x + 30, FL - 42, 52, 14); rect('#fff', x + 6, FL - 50, 22, 10); rect('#6b4a32', x - 2, FL - 60, 8, 60); },
  wardrobe(x) { rect('#8a5a2b', x, FL - 92, 48, 92); rect('#6e4720', x + 23, FL - 92, 2, 92); rect('#e6c46a', x + 17, FL - 50, 4, 8); rect('#e6c46a', x + 28, FL - 50, 4, 8); },
  stove(x) { rect('#c9ccd2', x, FL - 52, 54, 52); rect('#8e929a', x, FL - 54, 54, 4); rect('#2b2b33', x + 8, FL - 58, 14, 4); rect('#2b2b33', x + 32, FL - 58, 14, 4); rect('#33343c', x + 8, FL - 36, 38, 24); rect('#f4a64a', x + 12, FL - 32, 30, 3); },
  table(x) { rect('#a87a4a', x, FL - 46, 70, 8); rect('#7e5830', x + 6, FL - 38, 6, 38); rect('#7e5830', x + 58, FL - 38, 6, 38); rect('#fff', x + 28, FL - 54, 14, 8); c.fillStyle = '#e9748f'; blob(x + 35, FL - 60, 5); },
  fridge(x) { rect('#eef3f6', x, FL - 92, 44, 92); rect('#b9c4cc', x, FL - 56, 44, 3); rect('#8e9aa3', x + 34, FL - 84, 3, 20); rect('#8e9aa3', x + 34, FL - 50, 3, 22); },
  sofa(x) { rect('#3f8f9c', x, FL - 34, 100, 34); rect('#357c88', x, FL - 62, 100, 30); rect('#2f6f7a', x - 8, FL - 46, 14, 46); rect('#2f6f7a', x + 94, FL - 46, 14, 46); rect('#58b0bd', x + 8, FL - 40, 40, 14); rect('#58b0bd', x + 52, FL - 40, 40, 14); },
  carpet(x) { c.fillStyle = '#d9566f'; c.beginPath(); c.ellipse(x, FL + 4, 54, 9, 0, 0, 7); c.fill(); c.strokeStyle = '#f6c0cc'; c.lineWidth = 2; c.beginPath(); c.ellipse(x, FL + 4, 40, 6, 0, 0, 7); c.stroke(); },
  tv(x) {
    rect('#4a4a55', x + 14, FL - 24, 28, 24); rect('#1b1b22', x, FL - 62, 56, 38);
    const g = c.createLinearGradient(x, 0, x + 56, 0); const k = (T * 0.4) % 1;
    g.addColorStop(0, '#5ac8fa'); g.addColorStop(k, '#ff9bd0'); g.addColorStop(1, '#ffd98a');
    c.fillStyle = g; c.fillRect(x + 3, FL - 59, 50, 32);
  },
  /* --- новые этажи --- */
  dtable(x) { rect('#a87a4a', x, FL - 50, 160, 10); rect('#7e5830', x + 10, FL - 40, 8, 40); rect('#7e5830', x + 142, FL - 40, 8, 40); rect('#fff', x + 30, FL - 58, 18, 8); rect('#fff', x + 100, FL - 58, 18, 8); c.fillStyle = '#e9748f'; blob(x + 80, FL - 62, 7); rect('#6a9a4a', x + 78, FL - 56, 4, 6); },
  chand(x) { rect('#555', x, CEIL, 2, 36); c.fillStyle = '#d9b45a'; c.beginPath(); c.moveTo(x - 24, CEIL + 52); c.lineTo(x + 26, CEIL + 52); c.lineTo(x + 12, CEIL + 34); c.lineTo(x - 10, CEIL + 34); c.closePath(); c.fill(); c.fillStyle = 'rgba(255,230,150,.28)'; blob(x + 1, CEIL + 58, 34); c.fillStyle = '#fff3c8'; blob(x - 12, CEIL + 54, 4); blob(x + 14, CEIL + 54, 4); blob(x + 1, CEIL + 56, 4); },
  bar(x) { rect('#7e5830', x, FL - 58, 130, 58); rect('#a9794a', x - 4, FL - 64, 138, 8); rect('#5e3f20', x + 8, FL - 48, 114, 6); c.fillStyle = '#3f8f5b'; rect('#3f8f5b', x + 20, FL - 82, 8, 18); rect('#b3342d', x + 40, FL - 78, 8, 14); rect('#e8c46a', x + 60, FL - 80, 8, 16); rect('#bfe6f2', x + 92, FL - 74, 12, 10); rect('#6b4a32', x + 150, FL - 34, 6, 34); rect('#b0603c', x + 142, FL - 38, 22, 6); },
  arm(x) { rect('#b0603c', x, FL - 40, 64, 40); rect('#8f4b2e', x, FL - 72, 64, 36); rect('#8f4b2e', x - 8, FL - 52, 14, 52); rect('#8f4b2e', x + 58, FL - 52, 14, 52); rect('#d98b60', x + 8, FL - 46, 48, 12); },
  fire(x) { rect('#7a4a3a', x, FL - 84, 96, 84); rect('#a9705a', x - 6, FL - 90, 108, 10); rect('#1c1612', x + 20, FL - 56, 56, 56); const k = Math.sin(T * 9); c.fillStyle = '#f4a64a'; c.beginPath(); c.moveTo(x + 30, FL); c.quadraticCurveTo(x + 38, FL - 30 - k * 5, x + 48, FL - 38); c.quadraticCurveTo(x + 58, FL - 24 + k * 4, x + 66, FL); c.closePath(); c.fill(); c.fillStyle = '#ffd98a'; c.beginPath(); c.moveTo(x + 40, FL); c.quadraticCurveTo(x + 46, FL - 18, x + 50, FL - 22); c.quadraticCurveTo(x + 56, FL - 12, x + 58, FL); c.closePath(); c.fill(); },
  shelf(x) { rect('#6e4720', x, FL - 140, 46, 140); for (let r = 0; r < 4; r++) { rect('#4e3216', x + 3, FL - 134 + r * 34, 40, 3); ['#d9566f', '#3f8f9c', '#e6c46a', '#7fd19a', '#8a5ad9'].forEach((col, i) => rect(col, x + 6 + i * 7, FL - 130 + r * 34, 5, 26 - (i % 2) * 4)); } },
  mat(x) { rect('#58b0bd', x, FL - 6, 100, 6); rect('#e9748f', x + 40, FL - 12, 100, 6); rect('#7fd19a', x + 110, FL - 6, 60, 6); },
  treadm(x) { rect('#2b2b33', x, FL - 22, 100, 14); rect('#555a66', x + 4, FL - 20, 92, 8); rect('#8e929a', x + 8, FL - 96, 5, 76); rect('#8e929a', x + 8, FL - 96, 34, 5); rect('#e9748f', x + 36, FL - 100, 12, 10); c.strokeStyle = '#8e929a'; c.lineWidth = 4; c.beginPath(); c.moveTo(x + 6, FL - 22); c.lineTo(x + 12, FL - 58); c.stroke(); },
  weights(x) { rect('#6b4a32', x + 8, FL - 56, 6, 56); rect('#6b4a32', x + 106, FL - 56, 6, 56); rect('#c9ccd2', x, FL - 64, 120, 6); c.fillStyle = '#2b2b33'; [x + 6, x + 106].forEach(px => { rect('#2b2b33', px - 6, FL - 82, 8, 40); rect('#2b2b33', px + 6, FL - 82, 8, 40); }); },
  bike(x) { c.strokeStyle = '#2b2b33'; c.lineWidth = 5; c.beginPath(); c.arc(x + 14, FL - 20, 18, 0, 7); c.stroke(); c.beginPath(); c.arc(x + 70, FL - 20, 18, 0, 7); c.stroke(); c.strokeStyle = '#d9792f'; c.lineWidth = 6; c.beginPath(); c.moveTo(x + 14, FL - 20); c.lineTo(x + 40, FL - 58); c.lineTo(x + 70, FL - 20); c.moveTo(x + 40, FL - 58); c.lineTo(x + 28, FL - 62); c.moveTo(x + 40, FL - 58); c.lineTo(x + 62, FL - 66); c.stroke(); rect('#2b2b33', x + 20, FL - 70, 20, 6); rect('#2b2b33', x + 58, FL - 72, 16, 5); },
  mirror(x) { rect('#e6c46a', x - 4, CEIL + 38, 168, 94); const g = c.createLinearGradient(x, CEIL + 42, x + 160, CEIL + 126); g.addColorStop(0, '#dff3fa'); g.addColorStop(.5, '#bfe6f2'); g.addColorStop(1, '#a5d8ea'); c.fillStyle = g; c.fillRect(x, CEIL + 42, 160, 86); rect('rgba(255,255,255,.4)', x + 20, CEIL + 46, 10, 78); rect('rgba(255,255,255,.3)', x + 50, CEIL + 46, 5, 78); },
};

/* Картинки мебели в виде сбоку: если есть своя картинка сбоку (fs_), берём её, иначе общую (f_).
   [x для картинки (null = как у FURN.sx), высота] — ширина считается по пропорциям. */
const SIDE_IMG = {
  bed: [44, 82], wardrobe: [158, 98], stove: [236, 70], table: [304, 76], fridge: [382, 98], sofa: [446, 64], tv: [572, 66],
  dtable: [232, 92], bar: [34, 104], arm: [372, 68], fire: [440, 86], shelf: [572, 132],
  mat: [60, 52], treadm: [236, 100], weights: [350, 84], bike: [520, 98],
};
function sidePic(id) { return Art.img('fs_' + id) || Art.img('f_' + id); }
function drawSidePic(pic, x, y, h, maxW) {
  let dw = pic.width * h / pic.height, dh = h;
  if (maxW && dw > maxW) { dh = h * maxW / dw; dw = maxW; }
  c.imageSmoothingEnabled = false; c.drawImage(pic, x, y - dh, dw, dh); c.imageSmoothingEnabled = true;
}
Object.keys(SIDE_IMG).forEach(id => {
  const old = IDRAW[id];
  IDRAW[id] = function (x) { const pic = sidePic(id); if (!pic) return old(x); drawSidePic(pic, SIDE_IMG[id][0], FL + 10, SIDE_IMG[id][1]); };
});
{
  const oc = IDRAW.chand, om = IDRAW.mirror;
  IDRAW.chand = function (x) {
    const pic = sidePic('chand'); if (!pic) return oc(x);
    const cx = 300; rect('#555', cx - 1, CEIL, 2, 20); c.fillStyle = 'rgba(255,230,150,.22)'; blob(cx, CEIL + 42, 40);
    c.imageSmoothingEnabled = false; c.drawImage(pic, cx - 36, CEIL + 14, 72, 72 * pic.height / pic.width); c.imageSmoothingEnabled = true;
  };
  IDRAW.mirror = function (x) {
    const pic = sidePic('mirror'); if (!pic) return om(x);
    c.imageSmoothingEnabled = false; c.drawImage(pic, x, CEIL + 52, 220, 220 * pic.height / pic.width); c.imageSmoothingEnabled = true;
  };
}

function drawWindow(x, y, done) {
  if (done) {
    const night = Day.dark(S.clock) > 0.55;
    rect('#fdf6e6', x - 4, y - 4, 68, 58); rect(night ? '#ffd98a' : '#9fd6f0', x, y, 60, 50);
    rect('#fdf6e6', x + 28, y, 4, 50); rect('#fdf6e6', x, y + 23, 60, 4);
    rect('rgba(240,96,122,.85)', x, y, 12, 50); rect('rgba(240,96,122,.85)', x + 48, y, 12, 50);
  } else {
    rect('#4c4f57', x, y, 60, 50);
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 8, y + 4); c.lineTo(x + 30, y + 26); c.lineTo(x + 20, y + 44); c.moveTo(x + 30, y + 26); c.lineTo(x + 52, y + 18); c.stroke();
    c.fillStyle = '#7a5a3a';
    c.save(); c.translate(x + 30, y + 25); c.rotate(-0.4); c.fillRect(-42, -5, 84, 10); c.rotate(0.8); c.fillRect(-42, -5, 84, 10); c.restore();
  }
}

function drawRoof(t) {
  const ok = S.bought.roof;
  rect('#7a4b3a', 520, 100, 26, 52);
  c.fillStyle = ok ? '#9a3d3d' : '#5b4a45';
  c.beginPath(); c.moveTo(14, CEIL); c.lineTo(330, 76); c.lineTo(646, CEIL); c.closePath(); c.fill();
  if (ok) {
    c.strokeStyle = 'rgba(0,0,0,.22)'; c.lineWidth = 2;
    for (let y = CEIL - 18; y > 90; y -= 18) { const dx = (CEIL - y) * 2.772; c.beginPath(); c.moveTo(14 + dx, y); c.lineTo(646 - dx, y); c.stroke(); }
  } else {
    c.fillStyle = '#2a2420'; blob(200, 152, 16); blob(420, 140, 12); blob(250, 170, 9);
    c.fillStyle = '#8ec5e8'; c.beginPath(); c.moveTo(285, 124); c.lineTo(345, 108); c.lineTo(362, 144); c.lineTo(300, 152); c.closePath(); c.fill();
    c.strokeStyle = '#7a5a3a'; c.lineWidth = 6; c.beginPath(); c.moveTo(270, 140); c.lineTo(372, 118); c.stroke();
  }
  if (S.bought.porch) {
    for (let k = 0; k <= 20; k++) {
      let x, y;
      if (k <= 10) { const f = k / 10; x = 14 + f * 316; y = CEIL - f * 114; } else { const f = (k - 10) / 10; x = 330 + f * 316; y = 76 + f * 114; }
      const on = Math.sin(t * 3 + k) > -0.3;
      c.fillStyle = ['#ffd98a', '#ff9bd0', '#9be3ff'][k % 3];
      c.globalAlpha = on ? 1 : 0.45; blob(x, y + 10, 4); c.globalAlpha = 1;
    }
  }
}

/* лестницы, люк и дверь — вид сбоку */
function stairsSide(f) {
  const up = f < 3 && (f === 1 ? S.floors[2] : S.floors[3]), down = f > 1;
  const blockCol = '#8f6b49';
  if (f < 3) {   // лестница вверх
    rect(up ? blockCol : '#5a4a3c', 586, CEIL + 8, 46, FL - CEIL - 70);
    c.fillStyle = 'rgba(0,0,0,.2)'; for (let i = 0; i < 6; i++) c.fillRect(586, CEIL + 14 + i * 22, 46, 4);
    c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillStyle = up ? '#fff6e6' : 'rgba(255,255,255,.35)'; c.fillText(up ? '▲' : '🔒', 609, CEIL + 52);
  }
  if (down) {
    rect(blockCol, 586, FL - 60, 46, 60);
    c.fillStyle = 'rgba(0,0,0,.2)'; for (let i = 0; i < 3; i++) c.fillRect(586, FL - 54 + i * 18, 46, 4);
    c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('▼', 609, FL - 22);
  }
}
function hatchSide() {
  rect('#3a2a1c', 40, FL + 2, 54, 14); rect('#6b4a2a', 42, FL + 4, 50, 10);
  c.font = 'bold 14px sans-serif'; c.textAlign = 'center'; c.fillStyle = S.floors[0] ? '#fff6e6' : 'rgba(255,255,255,.4)'; c.fillText(S.floors[0] ? '▼ подвал' : '🔒 подвал', 67, FL + 13);
}
function doorSide() {
  rect('#4a2f22', 304, FL - 36, 52, 36); rect('#6b4a32', 308, FL - 32, 44, 32); c.fillStyle = '#d9b45a'; blob(344, FL - 16, 2.5);
  c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('во двор', 330, FL + 13);
}

/* ============================ ДОМ, ВИД СБОКУ ============================ */
/* ============ ДОМ, 1 ЭТАЖ, ВИД СБОКУ: новые текстуры (assets/house1) ============
   Рисуем в «координатах референса» (картинка 1846×852), потом масштабируем в игровые.
   Логическая координата героя x (30..630) растягивается в мире вида сбоку: sideX(). */
const H1 = { S: 0.667, X0: 30, RX0: 135, Y0: 190, RY0: 241, XS: 1057 / 600, W: 1087 };
const H1_ROOMS = [[135, 645, 'bedwall'], [660, 1195, 'kitwall'], [1212, 1720, 'livwall']];
const H1_WIN = [[292, 268, 170, 148], [770, 268, 164, 148], [1288, 268, 166, 148]];
const h1ok = () => !!Art.img('h_shell');
const sideX = (lx, f) => (f === 1 && h1ok()) ? H1.X0 + (lx - H1.X0) * H1.XS : lx;
const logX = (wx, f) => (f === 1 && h1ok()) ? H1.X0 + (wx - H1.X0) / H1.XS : wx;

function houseSide1(t) {
  const P = n => Art.img('h_' + n), B = S.bought;
  Art.grad(c, 0, 432, [[0, '#8ec5e8'], [1, '#f6e7c8']]);
  c.save();
  c.translate(H1.X0 - H1.RX0 * H1.S, H1.Y0 - H1.RY0 * H1.S); c.scale(H1.S, H1.S);
  // оболочка дома: крыша, стены, пол — три полосы растягиваются под референс
  const sh = P('shell'), fx = 1661 / sh.width;
  [[0, 38, 194, 240], [38, 284, 241, 572], [284, 340, 573, 661]].forEach(r => c.drawImage(sh, 0, r[0], sh.width, r[1] - r[0], 95, r[2], 1661, r[3] - r[2]));
  // непокрашенные стены — прежний облупленный вид
  H1_ROOMS.forEach((r, i) => {
    if (B[r[2]]) return;
    rect('#82776d', r[0], 241, r[1] - r[0], 331);
    rect('rgba(40,30,25,.22)', r[0] + 60 + i * 20, 290, 120, 70); rect('rgba(40,30,25,.18)', r[0] + 280, 400, 150, 90); rect('rgba(40,30,25,.16)', r[0] + 160, 470, 110, 60);
    c.strokeStyle = 'rgba(30,22,18,.5)'; c.lineWidth = 5; c.beginPath(); c.moveTo(r[0] + 400, 241); c.lineTo(r[0] + 380, 340); c.lineTo(r[0] + 420, 410); c.stroke();
  });
  if (!B.windows) H1_WIN.forEach(w => {
    rect('#4c4f57', w[0], w[1], w[2], w[3]);
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 3; c.beginPath(); c.moveTo(w[0] + 20, w[1] + 10); c.lineTo(w[0] + w[2] / 2, w[1] + w[3] / 2); c.lineTo(w[0] + 50, w[1] + w[3] - 10); c.stroke();
    c.fillStyle = '#7a5a3a'; c.save(); c.translate(w[0] + w[2] / 2, w[1] + w[3] / 2); c.rotate(-0.4); c.fillRect(-w[2] / 2, -12, w[2], 24); c.rotate(0.8); c.fillRect(-w[2] / 2, -12, w[2], 24); c.restore();
  });
  // предметы: [картинка, x слева, y низа, ширина, условие]
  const obj = (n, x, yb, w, atTop) => { const im = P(n); if (!im) return; const h = w * im.height / im.width; c.drawImage(im, x, atTop ? yb : yb - h, w, h); };
  const wallDecor = [
    ['pic_bear', 162, 397, 62, 'bedwall'], ['shelf_books', 522, 368, 106, 'bedwall'],
    ['shelf_jars', 1020, 368, 105, 'kitwall'], ['pic_land', 1222, 392, 58, 'livwall'],
  ];
  wallDecor.forEach(d => { if (B[d[4]]) obj(d[0], d[1], d[2], d[3]); });
  if (B.kitwall) obj('ceil_lamp', 912, 241, 56, true);
  if (B.carpet) { obj('rug', 272, 608, 193); obj('rug', 1258, 608, 265); }
  const items = [];
  const add = (cond, n, x, yb, w) => { if (cond) { yb += 30; items.push([yb, n, x, yb, w]); } };
  add(B.bed, 'bed', 163, 588, 115); add(B.bed, 'nightstand_plant', 290, 572, 98);
  add(B.wardrobe, 'wardrobe', 400, 570, 133); add(B.wardrobe, 'nightstand_lamp', 535, 572, 99); add(B.wardrobe, 'box', 532, 596, 74);
  add(B.stove, 'stove', 680, 558, 92); add(B.stove, 'counter', 782, 558, 211);
  add(B.table, 'table_chairs', 815, 592, 215);
  add(B.fridge, 'fridge', 1070, 558, 102);
  add(B.sofa, 'sofa', 1265, 572, 213); add(B.sofa, 'floor_lamp', 1220, 570, 48);
  add(B.tv, 'brick', 1475, 558, 81); add(B.tv, 'tv_stand', 1558, 570, 144);
  items.sort((a, b) => a[0] - b[0]).forEach(o => obj(o[1], o[2], o[3], o[4]));
  // дверь на второй этаж: замок, пока этаж не достроен; люк в подвал и коврик у выхода
  if (!S.floors[2]) { rect('rgba(20,14,10,.45)', 1625, 250, 92, 210); c.font = '64px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🔒', 1671, 380); }
  rect('#3a2a1c', 170, 590, 140, 40); rect('#5a4430', 176, 595, 128, 30); rect('#d9b45a', 236, 606, 8, 8);
  c.font = '34px ' + EMOJI_FONT; if (!S.floors[0]) c.fillText('🔒', 240, 622);
  c.font = 'bold 22px sans-serif'; c.fillStyle = 'rgba(255,246,230,.85)'; c.fillText('подвал', 240, 586);
  rect('#6b4a32', 860, 596, 140, 22); c.fillStyle = '#fff6e6'; c.font = 'bold 18px sans-serif'; c.fillText('во двор ↓', 930, 613);
  c.restore();
  // мусор (пока не убрали)
  const cl = S.trash.filter(Boolean).length;
  c.font = '38px ' + EMOJI_FONT; c.textAlign = 'center';
  TRASH.forEach((tr, i) => { if (!S.trash[i]) { c.fillStyle = '#000'; c.fillText(tr.e, sideX(tr.x, 1), FL + 8); } });
  rect('rgba(45,35,28,' + (0.25 * (1 - cl / S.trash.length)).toFixed(2) + ')', 30, CEIL, 1057, FL - CEIL + 40);
}

function houseSide(t, f) {
  if (f === 0) return baseSide(t);
  if (f === 1 && h1ok()) return houseSide1(t);
  Art.grad(c, 0, 432, [[0, '#8ec5e8'], [1, '#f6e7c8']]);
  Art.clouds(c, t);
  Day.sun(c, S.clock, 330, 230);
  Art.hills(c, 360, 18, '#9cc08f', 0.7, 0);
  if (f === 1) {
    rect('#6fae6a', 0, 432, W, 108); rect('#5f9a5c', 0, 474, W, 66);
    c.fillStyle = '#c9ad82'; c.beginPath(); c.moveTo(250, 432); c.lineTo(410, 432); c.lineTo(470, 540); c.lineTo(190, 540); c.closePath(); c.fill();
  } else {
    rect('#a98f75', 14, 432, 632, 108);   // фасад этажей ниже
    c.fillStyle = 'rgba(0,0,0,.12)'; for (let y = 440; y < 540; y += 14) c.fillRect(14, y, 632, 2);
    for (let wx = 60; wx < 600; wx += 150) { rect('#fdf6e6', wx - 4, 454, 68, 54); rect(Day.dark(S.clock) > .55 ? '#ffd98a' : '#9fd6f0', wx, 458, 60, 46); }
  }
  const cl = S.trash.filter(Boolean).length;
  if (f === 1) {
    for (let r = 0; r < 3; r++) {
      const x = ROOM_X[r], wid = ['bedwall', 'kitwall', 'livwall'][r];
      if (S.bought[wid]) {
        rect(WALLS[wid][0], x, CEIL, ROOM_W, FL - CEIL);
        for (let sx = x; sx < x + ROOM_W; sx += 24) rect('rgba(255,255,255,.28)', sx, CEIL, 10, FL - CEIL);
      } else {
        rect('#82776d', x, CEIL, ROOM_W, FL - CEIL);
        rect('rgba(40,30,25,.22)', x + 20 + r * 7, CEIL + 30, 44, 28); rect('rgba(40,30,25,.18)', x + 110, CEIL + 90, 56, 34); rect('rgba(40,30,25,.16)', x + 60, CEIL + 150, 40, 24);
        c.strokeStyle = 'rgba(30,22,18,.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(x + 150, CEIL); c.lineTo(x + 140, CEIL + 40); c.lineTo(x + 156, CEIL + 70); c.stroke();
      }
      drawWindow(x + 70, CEIL + 28, !!S.bought.windows);
    }
  } else if (f === 2) {
    [0, 1].forEach(r => {
      const x = 30 + r * 300; rect(r ? '#e9dcc4' : '#efe3cf', x, CEIL, 300, FL - CEIL);
      for (let sx = x; sx < x + 300; sx += 30) rect('rgba(255,255,255,.3)', sx, CEIL, 12, FL - CEIL);
    });
    drawWindow(80, CEIL + 28, true); drawWindow(220, CEIL + 28, true); drawWindow(380, CEIL + 28, true); drawWindow(520, CEIL + 28, true);
  } else {
    rect('#dce8ee', 30, CEIL, 600, FL - CEIL);
    for (let sx = 30; sx < 630; sx += 40) rect('rgba(255,255,255,.35)', sx, CEIL, 14, FL - CEIL);
    drawWindow(400, CEIL + 28, true); drawWindow(520, CEIL + 28, true);
  }
  rect(f === 3 ? '#4a4f58' : '#6d4b33', 30, FL, 600, 22); rect('rgba(0,0,0,.18)', 30, FL - 6, 600, 6);
  c.strokeStyle = 'rgba(0,0,0,.2)'; c.lineWidth = 1; for (let x = 60; x < 630; x += 40) { c.beginPath(); c.moveTo(x, FL); c.lineTo(x - 6, FL + 22); c.stroke(); }
  c.strokeStyle = '#3a2a20'; c.lineWidth = 4;
  if (f === 1) for (let r = 0; r < 3; r++) c.strokeRect(ROOM_X[r], CEIL, ROOM_W, FL - CEIL);
  else if (f === 2) { c.strokeRect(30, CEIL, 300, FL - CEIL); c.strokeRect(330, CEIL, 300, FL - CEIL); }
  else c.strokeRect(30, CEIL, 600, FL - CEIL);

  if (f === 1 && S.bought.carpet) IDRAW.carpet(535);
  Object.keys(FURN).forEach(id => { if (FURN[id].f === f && S.bought[id]) IDRAW[id](FURN[id].sx); });

  if (f === 1) {
    c.font = '38px ' + EMOJI_FONT; c.textAlign = 'center';
    TRASH.forEach((tr, i) => { if (!S.trash[i]) { c.fillStyle = '#000'; c.fillText(tr.e, tr.x, FL + 6); } });
    rect('rgba(45,35,28,' + (0.25 * (1 - cl / S.trash.length)).toFixed(2) + ')', 30, CEIL, 600, FL - CEIL);
    doorSide();
    if (S.floors[0] || true) hatchSide();
  } else if (f === 3 && !S.bought.mat && !S.bought.treadm && !S.bought.weights && !S.bought.bike && !S.bought.mirror) {
    c.font = 'bold 17px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(40,40,60,.6)'; c.fillText('Здесь будет спортзал — купи тренажёры справа', 330, 300);
  } else if (f === 2 && !EXTRA_ITEMS.some(i => FURN[i.id].f === 2 && S.bought[i.id])) {
    c.font = 'bold 17px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(40,40,60,.6)'; c.fillText('Пустой этаж — обставь его справа', 330, 300);
  }
  stairsSide(f);
  if (f === topFloor()) drawRoof(t); else { rect('#6d4b33', 14, CEIL - 22, 632, 22); rect('rgba(0,0,0,.2)', 14, CEIL - 2, 632, 2); }
  if (f === 1 && S.bought.porch) {
    rect('#b99269', 290, 434, 80, 8); rect('#8f6b49', 280, 442, 100, 8);
    rect('#4a3326', 262, 398, 6, 36); rect('#4a3326', 392, 398, 6, 36);
    c.fillStyle = 'rgba(255,226,154,.3)'; blob(265, 392, 16); blob(395, 392, 16);
    c.fillStyle = '#ffe29a'; blob(265, 392, 6); blob(395, 392, 6);
  }
  c.font = 'bold 13px sans-serif'; c.textAlign = 'left';
  const labs = f === 1 ? [['Спальня', 'bedwall', 0], ['Кухня', 'kitwall', 1], ['Гостиная', 'livwall', 2]] : null;
  if (labs) labs.forEach(l => { c.fillStyle = S.bought[l[1]] ? 'rgba(40,30,30,.6)' : 'rgba(255,255,255,.8)'; c.fillText(l[0], ROOM_X[l[2]] + 8, CEIL + 18); });
  else { c.fillStyle = 'rgba(40,30,30,.55)'; (f === 2 ? [['Столовая', 38], ['Гостиная-лаунж', 338]] : [['Спортзал', 38]]).forEach(l => c.fillText(l[0], l[1], CEIL + 18)); }
  if (f === 1 && cl === 0 && false) { /* подсказка только в начале (см. world.js) */ }
}

/* ============================ ПОДВАЛ ============================ */
function baseSide(t) {
  rect('#1d1a22', 0, 0, W, H); rect('#2a2430', 0, 0, W, 120);
  c.fillStyle = 'rgba(255,255,255,.05)'; for (let i = 0; i < 40; i++) c.fillRect((i * 83) % 660, 20 + (i * 47) % 90, 4, 3);
  rect('#2d3b44', 30, CEIL, 600, FL - CEIL);
  for (let sx = 30; sx < 630; sx += 40) rect('rgba(255,255,255,.04)', sx, CEIL, 18, FL - CEIL);
  rect('#222a31', 30, FL, 600, 22);
  c.strokeStyle = '#14181c'; c.lineWidth = 4; c.strokeRect(30, CEIL, 600, FL - CEIL);
  c.font = 'bold 13px sans-serif'; c.textAlign = 'left'; c.fillStyle = 'rgba(180,230,210,.7)'; c.fillText('ТАЙНАЯ КОМНАТА ЯРИКА · никому не говорить', 40, CEIL + 18);
  for (let k = 0; k < CFG.cloneMax; k++) drawPod(podPos(k, 'side')[0], FL, k, 'side', t);
  rect('#3f4a54', 586, FL - 60, 46, 60); c.fillStyle = 'rgba(0,0,0,.2)'; for (let i = 0; i < 3; i++) c.fillRect(586, FL - 54 + i * 18, 46, 4);
  c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('▲', 609, FL - 22);
  rect('#3a2a1c', 40, CEIL - 6, 54, 8);
  c.font = 'bold 12px sans-serif'; c.fillStyle = '#fff6e6'; c.fillText('▲ в дом', 67, CEIL + 12);
}
function drawPod(x, y, k, mode, t) {
  const has = k < S.clones, mono = mode === 'top';
  if (mono) {
    c.fillStyle = 'rgba(0,0,0,.35)'; Art.rr(c, x - 42, y - 44, 84, 94, 12); c.fill();
    c.fillStyle = has ? 'rgba(127,255,190,.25)' : 'rgba(150,170,190,.12)'; Art.rr(c, x - 38, y - 40, 76, 86, 10); c.fill();
    c.strokeStyle = has ? '#7fffbe' : '#52606c'; c.lineWidth = 3; Art.rr(c, x - 38, y - 40, 76, 86, 10); c.stroke();
  } else {
    rect('#222a31', x - 28, y - 112, 56, 112);
    c.fillStyle = has ? 'rgba(127,255,190,.28)' : 'rgba(150,170,190,.12)'; Art.rr(c, x - 24, y - 106, 48, 100, 10); c.fill();
    c.strokeStyle = has ? '#7fffbe' : '#52606c'; c.lineWidth = 3; Art.rr(c, x - 24, y - 106, 48, 100, 10); c.stroke();
  }
  if (has) {
    const bob = Math.sin(t * 2 + k) * 1.5;
    Art.person(c, 'yarik', x, mono ? y + 34 + bob : y - 8 + bob, mono ? 70 : 92, k % 2 ? -1 : 1, 0, 'hue-rotate(100deg) saturate(1.4) brightness(1.05)');
    c.fillStyle = 'rgba(127,255,190,.18)'; Art.rr(c, x - 24, y - 106, 48, 100, 10); if (!mono) c.fill();
  } else {
    c.font = 'bold 20px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(180,200,215,.35)'; c.fillText('пусто', x, mono ? y + 6 : y - 54);
  }
}

/* ============================ ДОМ, ВИД СВЕРХУ ============================ */
function drawFurnTop(id) {
  const F = FURN[id], x = F.tp[0], y = HY0 + F.tp[1], w = F.tp[2], h = F.tp[3];
  const pic = Art.img('f_' + id);
  if (pic && TI[id]) {
    const r = TI[id], bx = r[0], by = HY0 + r[1];
    let dw = r[2], dh = r[3];
    if (id !== 'mirror') { const k = Math.min(r[2] / pic.width, r[3] / pic.height); dw = pic.width * k; dh = pic.height * k; }
    const dx = bx + (r[2] - dw) / 2, dy = by + (r[3] - dh);
    c.imageSmoothingEnabled = false;
    c.drawImage(pic, dx, dy, dw, dh);
    c.imageSmoothingEnabled = true;
    return;
  }
  if (id === 'mirror') { rect('#e6c46a', x - 3, y - 3, w + 6, h + 6); rect('#bfe6f2', x, y, w, h); return; }
  if (id === 'chand') { c.fillStyle = 'rgba(255,230,150,.35)'; blob(x + 15, y + 15, 34); c.fillStyle = '#ffd98a'; blob(x + 15, y + 15, 14); c.fillStyle = '#fff3c8'; blob(x + 15, y + 15, 6); return; }
  c.fillStyle = 'rgba(0,0,0,.22)'; Art.rr(c, x + 3, y + 4, w, h, 8); c.fill();
  c.fillStyle = F.col; Art.rr(c, x, y, w, h, 8); c.fill();
  c.fillStyle = 'rgba(255,255,255,.18)'; Art.rr(c, x + 3, y + 3, w - 6, Math.min(14, h - 6), 6); c.fill();
  if (id === 'bed') { c.fillStyle = '#e9e2d6'; Art.rr(c, x + 6, y + 6, w - 12, 36, 8); c.fill(); c.fillStyle = '#fff'; Art.rr(c, x + 10, y + 10, 30, 22, 6); c.fill(); Art.rr(c, x + w - 40, y + 10, 30, 22, 6); c.fill(); }
  if (id === 'tv') { const g = c.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, '#5ac8fa'); g.addColorStop((T * 0.4) % 1, '#ff9bd0'); g.addColorStop(1, '#ffd98a'); c.fillStyle = g; c.fillRect(x + 4, y + 4, w - 8, h - 8); return; }
  if (id === 'sofa') { c.fillStyle = '#2f6f7a'; Art.rr(c, x, y + h - 14, w, 14, 6); c.fill(); }
  emo(F.ic, x + w / 2, y + h / 2 + Math.min(w, h) * 0.18, clamp(Math.min(w, h) * 0.55, 18, 40));
}
function stairsTop(f) {
  const up = f < 3 && (f === 1 ? S.floors[2] : S.floors[3]);
  const blk = (x, y, w, h, col, txt, on) => {
    c.fillStyle = col; Art.rr(c, x, y, w, h, 6); c.fill();
    c.fillStyle = 'rgba(0,0,0,.2)'; for (let i = 1; i < 5; i++) c.fillRect(x + 3, y + i * h / 5, w - 6, 3);
    c.font = 'bold 20px sans-serif'; c.textAlign = 'center'; c.fillStyle = on ? '#fff6e6' : 'rgba(255,255,255,.4)'; c.fillText(txt, x + w / 2, y + h / 2 + 7);
  };
  if (f === 0) { blk(36, HY0 + 8, 50, 44, '#4d5964', '▲', true); return; }
  if (f < 3) blk(572, HY0 + 8, 54, 44, up ? '#8f6b49' : '#5a4a3c', up ? '▲' : '🔒', up);
  if (f > 1) blk(572, HY0 + HH - 52, 54, 44, '#8f6b49', '▼', true);
  if (f === 1) {
    blk(36, HY0 + HH - 52, 50, 44, '#4a3a2a', S.floors[0] ? '▼' : '🔒', S.floors[0]);
    rect('#6b4a32', 300, HY0 + HH - 6, 60, 14); rect('#d9b45a', 346, HY0 + HH + 1, 5, 4);
    c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('во двор', 330, HY0 + HH + 26);
  }
}
function houseTop(t, f) {
  if (f === 0) return baseTop(t);
  const g = f === 1 ? ['#3d5a43', '#35503b'] : ['#46566b', '#3f4e62'];
  rect(g[0], 0, 60, 664, 480);
  for (let i = 0; i < 60; i++) rect(g[1], (i * 113) % 640 + 10, 66 + (i * 71) % 460, 18, 3);
  rect('#3a2a20', HX0 - 10, HY0 - 10, HW + 20, HH + 20);
  rect(f === 3 ? '#6a6f7a' : f === 2 ? '#caa878' : '#b58a5c', HX0, HY0, HW, HH);
  if (f === 3) { c.strokeStyle = 'rgba(0,0,0,.18)'; c.lineWidth = 1; for (let x = HX0; x <= HX0 + HW; x += 40) { c.beginPath(); c.moveTo(x, HY0); c.lineTo(x, HY0 + HH); c.stroke(); } for (let y = HY0; y <= HY0 + HH; y += 40) { c.beginPath(); c.moveTo(HX0, y); c.lineTo(HX0 + HW, y); c.stroke(); } }
  else { c.strokeStyle = 'rgba(60,40,20,.22)'; c.lineWidth = 1; for (let y = HY0 + 20; y < HY0 + HH; y += 20) { c.beginPath(); c.moveTo(HX0, y); c.lineTo(HX0 + HW, y); c.stroke(); } }
  const cl = S.trash.filter(Boolean).length;
  const rooms = f === 1 ? [[30, 200], [230, 200], [430, 200]] : f === 2 ? [[30, 300], [330, 300]] : [[30, 600]];
  const wallIds = ['bedwall', 'kitwall', 'livwall'];
  rooms.forEach((r, i) => {
    if (f === 1) {
      const wid = wallIds[i];
      if (S.bought[wid]) {
        c.fillStyle = WALLS[wid][0]; c.globalAlpha = .38; c.fillRect(r[0], HY0, r[1], HH); c.globalAlpha = 1;
        rect(WALLS[wid][0], r[0], HY0, r[1], 14); for (let sx = r[0]; sx < r[0] + r[1]; sx += 24) rect('rgba(255,255,255,.3)', sx, HY0, 10, 14);
      } else { rect('rgba(40,30,25,.22)', r[0] + 16, HY0 + 120 + i * 9, 44, 28); rect('rgba(40,30,25,.18)', r[0] + 120, HY0 + 210, 56, 34); }
    }
    // окна
    const wxs = f === 1 ? [r[0] + 70] : f === 2 ? [r[0] + 50, r[0] + 190] : [400, 520];
    wxs.forEach(wx => { const ok = f !== 1 || S.bought.windows; rect(ok ? '#fdf6e6' : '#4c4f57', wx - 3, HY0 - 11, 66, 11); rect(ok ? (Day.dark(S.clock) > .55 ? '#ffd98a' : '#9fd6f0') : '#6b5a45', wx, HY0 - 8, 60, 6); });
    c.font = 'bold 12px sans-serif'; c.textAlign = 'left'; c.fillStyle = 'rgba(40,30,30,.6)';
    const nm = f === 1 ? ['Спальня', 'Кухня', 'Гостиная'][i] : f === 2 ? ['Столовая', 'Гостиная-лаунж'][i] : 'Спортзал';
    c.fillText(nm, r[0] + 8, HY0 + 14 + (f === 1 ? 12 : 0));
  });
  if (rooms.length > 1) rooms.slice(1).forEach(r => { rect('#3a2a20', r[0] - 4, HY0, 8, 120); rect('#3a2a20', r[0] - 4, HY0 + 200, 8, HH - 200); });
  if (f === 1 && S.bought.carpet) { c.fillStyle = '#d9566f'; Art.rr(c, CARPET_TP[0], HY0 + CARPET_TP[1], CARPET_TP[2], CARPET_TP[3], 14); c.fill(); c.strokeStyle = '#f6c0cc'; c.lineWidth = 2; Art.rr(c, CARPET_TP[0] + 8, HY0 + CARPET_TP[1] + 8, CARPET_TP[2] - 16, CARPET_TP[3] - 16, 10); c.stroke(); }
  Object.keys(FURN).forEach(id => { if (FURN[id].f === f && S.bought[id]) drawFurnTop(id); });
  if (f === 1) {
    c.font = '34px ' + EMOJI_FONT; c.textAlign = 'center';
    TRASH.forEach((tr, i) => { if (!S.trash[i]) { c.fillStyle = '#000'; c.fillText(tr.e, tr.x, HY0 + tr.y + 12); } });
    rect('rgba(45,35,28,' + (0.25 * (1 - cl / S.trash.length)).toFixed(2) + ')', HX0, HY0, HW, HH);
  }
  stairsTop(f);
}

function baseTop(t) {
  rect('#14111a', 0, 60, 664, 480);
  rect('#0e0c12', HX0 - 10, HY0 - 10, HW + 20, HH + 20);
  rect('#2d3b44', HX0, HY0, HW, HH);
  c.strokeStyle = 'rgba(255,255,255,.06)'; c.lineWidth = 1; for (let x = HX0; x <= HX0 + HW; x += 40) { c.beginPath(); c.moveTo(x, HY0); c.lineTo(x, HY0 + HH); c.stroke(); } for (let y = HY0; y <= HY0 + HH; y += 40) { c.beginPath(); c.moveTo(HX0, y); c.lineTo(HX0 + HW, y); c.stroke(); }
  c.font = 'bold 13px sans-serif'; c.textAlign = 'left'; c.fillStyle = 'rgba(180,230,210,.7)'; c.fillText('ТАЙНАЯ КОМНАТА ЯРИКА · никому не говорить', HX0 + 100, HY0 + 18);
  for (let k = 0; k < CFG.cloneMax; k++) { const p = podPos(k, 'top'); drawPod(p[0] + 20, p[1] + 20, k, 'top', t); }
  stairsTop(0);
}

/* ============================ ДВОР ============================ */
function drawCrop(id, x, y, t, age) {
  const k = age < 0.5 ? 0.4 + age * 1.2 : 1, sw = Math.sin(t * 2 + x * 0.05) * 1.5;
  c.save(); c.translate(x, y); c.scale(k, k);
  if (id === 'bush') {
    c.fillStyle = '#2f7d3d'; blob(-12 + sw, -12, 14); blob(10 + sw, -12, 13); blob(sw, -22, 15);
    c.fillStyle = '#43a357'; blob(-3 + sw, -26, 8);
  } else if (id === 'berry') {
    c.fillStyle = '#3a8f45'; blob(-10 + sw, -9, 11); blob(10 + sw, -9, 11); blob(sw, -16, 11);
    c.fillStyle = '#e03a4e'; blob(-12 + sw, -6, 3); blob(8 + sw, -4, 3); blob(2 + sw, -14, 3); blob(14 + sw, -12, 3); blob(-4 + sw, -2, 3);
  } else if (id === 'pumpkin') {
    c.fillStyle = '#3a8f45'; blob(-20, -8, 9); blob(20, -8, 9);
    c.fillStyle = '#f08a2b'; c.beginPath(); c.ellipse(0, -15, 21, 16, 0, 0, 7); c.fill();
    c.strokeStyle = '#c7681a'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -30); c.lineTo(0, 0); c.moveTo(-10, -29); c.quadraticCurveTo(-14, -15, -10, -1); c.moveTo(10, -29); c.quadraticCurveTo(14, -15, 10, -1); c.stroke();
    rect('#4a7a2f', -2, -34, 5, 8);
  } else if (id === 'apple') {
    rect('#6b4a32', -5, -34, 10, 34);
    c.fillStyle = '#2f7d3d'; blob(-16 + sw, -42, 18); blob(16 + sw, -42, 18); blob(sw, -54, 20);
    c.fillStyle = '#43a357'; blob(sw - 4, -58, 10);
    c.fillStyle = '#e8393f'; blob(-14 + sw, -38, 4); blob(12 + sw, -46, 4); blob(2 + sw, -34, 4); blob(-4 + sw, -56, 4);
  } else if (id === 'mega') {
    megaPlant(0, -22, t, age, false);
  }
  c.restore();
}
/* Мега-растение: светящийся цветок, расцветает за CFG.megaGrow секунд. */
function megaPlant(x, y, t, age, top) {
  const p = clamp(age / CFG.megaGrow, 0, 1), r = 8 + p * 20, pulse = 1 + Math.sin(t * 9) * 0.08;
  c.save(); c.translate(x, y);
  c.fillStyle = 'rgba(160,120,255,' + (0.18 + p * 0.25).toFixed(2) + ')'; blob(0, 0, r * 1.9 * pulse);
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4 + t * 0.6;
    c.fillStyle = i % 2 ? '#7be0d1' : '#b48cff';
    c.beginPath(); c.ellipse(Math.cos(a) * r * 0.7, Math.sin(a) * r * 0.7, r * 0.55, r * 0.28, a, 0, 7); c.fill();
  }
  c.fillStyle = '#ffe58a'; blob(0, 0, r * 0.38); c.fillStyle = '#fff'; blob(-r * 0.1, -r * 0.1, r * 0.12);
  c.restore();
}
function drawCropTop(id, x, y, t, age) {
  const k = age < 0.5 ? 0.4 + age * 1.2 : 1, sw = Math.sin(t * 2 + x * 0.05) * 1.2;
  c.save(); c.translate(x, y); c.scale(k, k);
  if (id === 'bush') {
    c.fillStyle = 'rgba(0,0,0,.18)'; blob(2, 4, 21);
    c.fillStyle = '#2f7d3d'; blob(-9 + sw, -2, 13); blob(9 + sw, -2, 13); blob(sw, 7, 12); blob(sw, -9, 12);
    c.fillStyle = '#43a357'; blob(-4 + sw, -4, 7); blob(6 + sw, 4, 6);
  } else if (id === 'berry') {
    c.fillStyle = 'rgba(0,0,0,.18)'; blob(2, 4, 22);
    c.fillStyle = '#3a8f45'; blob(-11 + sw, 0, 12); blob(11 + sw, 0, 12); blob(sw, -8, 12); blob(sw, 8, 12);
    c.fillStyle = '#e03a4e'; [[-12, -3], [8, 3], [0, -10], [13, -6], [-5, 9], [4, 11], [-14, 8]].forEach(p => blob(p[0] + sw, p[1], 3.2));
  } else if (id === 'pumpkin') {
    c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.ellipse(2, 5, 26, 18, 0, 0, 7); c.fill();
    c.fillStyle = '#3a8f45'; blob(-26, 4, 8); blob(26, 4, 8);
    c.fillStyle = '#f08a2b'; c.beginPath(); c.ellipse(0, 0, 24, 18, 0, 0, 7); c.fill();
    c.strokeStyle = '#c7681a'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -17); c.lineTo(0, 17); c.moveTo(-12, -14); c.quadraticCurveTo(-16, 0, -12, 14); c.moveTo(12, -14); c.quadraticCurveTo(16, 0, 12, 14); c.stroke();
    rect('#4a7a2f', -2, -22, 5, 8);
  } else if (id === 'apple') {
    c.fillStyle = 'rgba(0,0,0,.2)'; blob(4, 8, 34);
    c.fillStyle = '#2f7d3d'; blob(-14 + sw, -4, 22); blob(14 + sw, -4, 22); blob(sw, -16, 22); blob(sw, 10, 20);
    c.fillStyle = '#43a357'; blob(-6 + sw, -10, 12); blob(10 + sw, 2, 10);
    c.fillStyle = '#e8393f'; [[-16, -4], [14, -10], [4, 10], [-6, -20], [20, 8], [-18, 12]].forEach(p => blob(p[0] + sw, p[1], 4.5));
  } else if (id === 'mega') {
    megaPlant(0, 0, t, age, true);
  }
  c.restore();
}
function drawSoil(r, hot, mode) {
  const [x, y, w, h] = r;
  c.fillStyle = hot ? '#7a5636' : '#6b4a32'; Art.rr(c, x, y, w, h, mode === 'top' ? 10 : 12); c.fill();
  c.fillStyle = 'rgba(0,0,0,.18)'; const n = mode === 'top' ? 3 : 2;
  for (let k = 0; k < n; k++) c.fillRect(x + 8, y + 10 + k * (h - 14) / n, w - 16, 3);
}
function drawPlots(t, mode) {
  const G = SCENES.game, nextCost = S.plotCount < CFG.plotsMax ? (EXPAND_COST[(S.plotCount - CFG.plotsStart) / 6] || 300) : 0;
  for (let i = 0; i < CFG.plotsMax; i++) {
    const r = plotRect(i, mode), x = r[0], y = r[1], w = r[2], h = r[3];
    if (i < S.plotCount) {
      const fl = G.wt[i] && T - G.wt[i] < 0.35;
      drawSoil(r, fl, mode);
      const age = T - (G.pt[i] || -9);
      if (S.plots[i]) {
        if (mode === 'top') drawCropTop(S.plots[i], x + w / 2, y + h / 2, t, age);
        else { const sc = S.plots[i] === 'apple' ? 0.55 : 0.78; c.save(); c.scale(sc, sc); drawCrop(S.plots[i], (x + w / 2) / sc, (y + h - 5) / sc, t, age); c.restore(); }
      } else { c.fillStyle = 'rgba(255,255,255,.22)'; c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.fillText('+', x + w / 2, y + h / 2 + 9); }
    } else {
      const next = i < S.plotCount + CFG.plotsStart;
      c.strokeStyle = 'rgba(255,255,255,' + (next ? 0.4 : 0.14) + ')'; c.lineWidth = 2; c.setLineDash([6, 6]); Art.rr(c, x, y, w, h, 10); c.stroke(); c.setLineDash([]);
      if (i === S.plotCount) {
        c.font = '22px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🔒', x + w / 2, y + h / 2 + 2);
        c.font = 'bold 13px sans-serif'; c.fillStyle = '#fff6e6'; c.fillText('ряд $' + fmt(nextCost), x + w / 2, y + h / 2 + 20);
      }
    }
  }
}
function barnOutside(x, y, w, h) {
  const l = x - w / 2;
  c.fillStyle = '#9c3a33'; c.fillRect(l, y - h, w, h);
  c.fillStyle = 'rgba(0,0,0,.14)'; for (let i = 1; i < 8; i++) c.fillRect(l, y - h + i * h / 8, w, 2);
  c.fillStyle = '#6e2723'; c.beginPath(); c.moveTo(l - 10, y - h + 4); c.lineTo(x, y - h - h * 0.55); c.lineTo(l + w + 10, y - h + 4); c.closePath(); c.fill();
  c.fillStyle = '#f2e6d0'; c.fillRect(x - 28, y - 56, 56, 56);
  c.strokeStyle = '#9c3a33'; c.lineWidth = 3; c.strokeRect(x - 28, y - 56, 56, 56); c.beginPath(); c.moveTo(x - 28, y - 56); c.lineTo(x + 28, y); c.moveTo(x + 28, y - 56); c.lineTo(x - 28, y); c.stroke();
  c.fillStyle = '#f2e6d0'; c.beginPath(); c.arc(x, y - h - 14, 10, 0, 7); c.fill();
}

function yardSide(t) {
  Art.grad(c, 0, 150, [[0, '#8ec5e8'], [1, '#f6e7c8']]);
  Art.clouds(c, t);
  Day.sun(c, S.clock, 125, 80);
  Art.hills(c, 120, 12, '#9cc08f', 1.1, 0);
  Art.grad(c, 130, 540, [[0, '#8fd08a'], [1, '#5ea85f']]);
  Art.oldHouse(c, 175, 150, 150, 92, {});
  barnOutside(530, 150, 150, 80);
  c.fillStyle = '#e8dcc0'; for (let x = 6; x < 660; x += 22) c.fillRect(x, 140, 10, 34);
  c.fillRect(0, 150, 660, 5); c.fillRect(0, 164, 660, 5);
  drawPlots(t, 'side');
  if (S.upg.scare) emo('🎃', 640, 150, 34);
  if (S.upg.ghouse) emo('🏡', 20, 150, 34);
}
function yardTop(t) {
  Art.grad(c, 60, 540, [[0, '#7fc27c'], [1, '#6bb06a']]);
  for (let i = 0; i < 90; i++) { const x = (i * 97) % 650 + 5, y = 70 + (i * 61) % 460; c.fillStyle = 'rgba(40,110,50,.28)'; c.fillRect(x, y, 2, 6); c.fillRect(x + 4, y + 2, 2, 5); }
  // дом (крыша сверху)
  rect('rgba(0,0,0,.2)', 26, 72, 310, 90); rect('#9a3d3d', 20, 64, 310, 88);
  c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 2; for (let x = 20; x <= 330; x += 22) { c.beginPath(); c.moveTo(x, 64); c.lineTo(x, 152); c.stroke(); }
  rect('rgba(255,255,255,.12)', 20, 64, 310, 8); rect('#6e3a3a', 20, 106, 310, 6);
  rect('#7a4b3a', 270, 76, 28, 28); rect('#4a2f22', 160, 148, 30, 8);
  // амбар
  rect('rgba(0,0,0,.2)', 416, 72, 230, 90); rect('#a33d36', 410, 64, 230, 88);
  rect('#6e2723', 410, 104, 230, 8); c.strokeStyle = 'rgba(0,0,0,.2)'; c.lineWidth = 2; for (let x = 410; x <= 640; x += 18) { c.beginPath(); c.moveTo(x, 64); c.lineTo(x, 152); c.stroke(); }
  rect('#f2e6d0', 505, 118, 50, 34); c.strokeStyle = '#a33d36'; c.lineWidth = 3; c.strokeRect(505, 118, 50, 34); c.beginPath(); c.moveTo(505, 118); c.lineTo(555, 152); c.moveTo(555, 118); c.lineTo(505, 152); c.stroke();
  c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('ДОМ', 175, 96); c.fillText('АМБАР', 525, 96);
  // дорожки
  c.fillStyle = '#d6bb8a'; c.fillRect(160, 156, 30, 16); c.fillRect(515, 156, 30, 16);
  // забор огорода
  c.strokeStyle = '#e8dcc0'; c.lineWidth = 4; c.strokeRect(26, 166, 614, 372);
  c.fillStyle = '#e8dcc0'; for (let x = 26; x <= 640; x += 40) { c.fillRect(x - 3, 162, 7, 10); c.fillRect(x - 3, 534, 7, 10); }
  c.fillStyle = 'rgba(70,50,30,.18)'; c.fillRect(30, 170, 606, 364);
  drawPlots(t, 'top');
  if (S.upg.scare) emo('🎃', 626, 192, 30);
  if (S.upg.ghouse) emo('🏡', 365, 130, 40);
}

/* ============================ АМБАР ============================ */
function barnSide(t) {
  rect('#6a3a2e', 0, 60, 664, 480);
  c.fillStyle = 'rgba(0,0,0,.14)'; for (let x = 14; x < 664; x += 30) c.fillRect(x, 60, 3, 480);
  rect('#8a5a3e', 14, 140, 632, 8);
  // сеновал
  c.fillStyle = '#d9b45a'; for (let i = 0; i < 14; i++) { const x = 40 + i * 44; c.beginPath(); c.moveTo(x, 140); c.lineTo(x + 20, 112 + (i % 3) * 6); c.lineTo(x + 40, 140); c.closePath(); c.fill(); }
  rect('#b7945a', 30, FL, 600, 30);
  c.fillStyle = '#d9b45a'; for (let i = 0; i < 60; i++) c.fillRect(34 + (i * 53) % 590, FL + 4 + (i * 17) % 22, 7, 2);
  for (let k = 0; k < CFG.cowMax; k++) {
    const x = stallPos(k, 'side')[0];
    rect('#7e5830', x + 44, FL - 60, 5, 60); rect('#7e5830', x - 44, FL - 60, 5, 60); rect('#7e5830', x - 44, FL - 52, 93, 4);
    if (k < S.cows) Art.cow(c, x, FL + 4, 0.78, k % 2 ? -1 : 1, t, 'side', k);
    else { c.font = 'bold 15px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(255,255,255,.4)'; c.fillText('место', x, FL - 20); }
  }
  rect('#4a2f22', 36, FL - 78, 62, 78); rect('#6b4a32', 40, FL - 74, 54, 74);
  c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('во двор', 67, FL + 14);
  c.font = 'bold 14px sans-serif'; c.textAlign = 'left'; c.fillStyle = 'rgba(255,255,255,.75)'; c.fillText('Амбар · ' + S.cows + '/' + CFG.cowMax + ' коров', 40, 84);
}
function barnTop(t) {
  rect('#5a4a36', 0, 60, 664, 480);
  rect('#3a2a20', HX0 - 10, HY0 - 10, HW + 20, HH + 20);
  rect('#b7945a', HX0, HY0, HW, HH);
  c.fillStyle = '#d9b45a'; for (let i = 0; i < 160; i++) c.fillRect(HX0 + 6 + (i * 53) % 588, HY0 + 6 + (i * 37) % 326, 8, 2);
  for (let k = 0; k < CFG.cowMax; k++) {
    const p = stallPos(k, 'top'), x = p[0], y = p[1];
    c.strokeStyle = '#7e5830'; c.lineWidth = 4; c.strokeRect(x - 80, y - 58, 160, 116);
    rect('#8a6a3c', x - 70, y + 38, 70, 12);   // кормушка
    if (k < S.cows) Art.cow(c, x, y - 4, 1.1, k % 2 ? -1 : 1, t, 'top', k);
    else { c.font = 'bold 15px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(60,40,20,.5)'; c.fillText('свободное место', x, y + 4); }
  }
  rect('#6b4a32', 40, HY0 + HH - 6, 60, 14); c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.fillText('во двор', 70, HY0 + HH + 26);
  c.font = 'bold 14px sans-serif'; c.textAlign = 'left'; c.fillStyle = 'rgba(255,255,255,.75)'; c.fillText('Амбар · ' + S.cows + '/' + CFG.cowMax + ' коров', HX0, 90);
}

/* Рисует то, что сейчас показывает камера. */
function drawWorld(view, floor, mode, t) {
  if (view === 'house') (mode === 'top' ? houseTop : houseSide)(t, floor);
  else if (view === 'yard') (mode === 'top' ? yardTop : yardSide)(t);
  else (mode === 'top' ? barnTop : barnSide)(t);
}
