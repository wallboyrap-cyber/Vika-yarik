'use strict';
/* Основная игра: дом (этажи, подвал), двор, амбар. Два героя живут своей жизнью:
   тот, за кого ты играешь, ходит куда нажмёшь, второй занят своими делами сам. */

/* ---------- иконки интерфейса (в одном стиле) ---------- */
const ICO = (() => {
  const mk = d => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>';
  return {
    house: mk('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>'),
    yard:  mk('<path d="M12 21v-8"/><path d="M12 13c0-4 3-6 7-6 0 4-3 6-7 6z"/><path d="M12 16c0-3-2-5-6-5 0 3 2 5 6 5z"/><path d="M5 21h14"/>'),
    barn:  mk('<path d="M3 21V10l9-6 9 6v11z"/><path d="M8 21v-7h8v7"/><path d="M8 14l8 7M16 14l-8 7"/>'),
    cart:  mk('<path d="M3 4h3l2.2 10.5a1 1 0 0 0 1 .8h8.6a1 1 0 0 0 1-.8L21 7H7"/><circle cx="10" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/>'),
    top:   mk('<rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="M3.5 10h17M10 10v10.5"/>'),
    side:  mk('<path d="M3 21h18"/><path d="M4.5 21V5h15v16"/><path d="M4.5 13h15M12 5v8"/>'),
  };
})();

/* ---------- маршруты между местами ---------- */
const NODEP = { H0: ['house', 0], H1: ['house', 1], H2: ['house', 2], H3: ['house', 3], Y: ['yard', 1], B: ['barn', 1] };
const nodeOf = (place, floor) => place === 'house' ? 'H' + floor : place === 'yard' ? 'Y' : 'B';
const ADJ = { H0: ['H1'], H1: ['H0', 'H2', 'Y'], H2: ['H1', 'H3'], H3: ['H2'], Y: ['H1', 'B'], B: ['Y'] };
const EDGE = {
  'H1>H2': [EXITS.house.up, EXITS.house.down], 'H2>H1': [EXITS.house.down, EXITS.house.up],
  'H2>H3': [EXITS.house.up, EXITS.house.down], 'H3>H2': [EXITS.house.down, EXITS.house.up],
  'H1>H0': [EXITS.house.hatch, EXITS.house.base], 'H0>H1': [EXITS.house.base, EXITS.house.hatch],
  'H1>Y': [EXITS.house.door, EXITS.yard.house], 'Y>H1': [EXITS.yard.house, EXITS.house.door],
  'Y>B': [EXITS.yard.barn, EXITS.barn.door], 'B>Y': [EXITS.barn.door, EXITS.yard.barn],
};
function nodePath(a, b) {
  if (a === b) return [a];
  const q = [[a]], seen = { [a]: 1 };
  while (q.length) {
    const p = q.shift(), last = p[p.length - 1];
    for (const n of ADJ[last]) { if (seen[n]) continue; seen[n] = 1; const np = p.concat(n); if (n === b) return np; q.push(np); }
  }
  return [a];
}

/* ---------- экономика ---------- */
const trashLeft = () => S.trash.filter(x => !x).length;
const trashDone = () => trashLeft() === 0;
const comfort = () => EXTRA_ITEMS.filter(i => S.bought[i.id]).length * CFG.comfort;
function foodMult() {
  const a = S.food.vika, b = S.food.yarik;
  if (a < CFG.hungryBelow || b < CFG.hungryBelow) return CFG.hungryMult;
  if (a > 70 && b > 70) return CFG.fedMult;
  return 1;
}
function mult() {
  let m = 1; UPGRADES.forEach(u => { if (S.upg[u.id]) m += u.bonus; });
  if (S.char === 'yarik') m *= CFG.yarikFarmBonus;
  if (S.mood > 0) m *= 0.5;
  m *= 1 + comfort(); m *= foodMult();
  if (S.boostT > 0) m *= CFG.megaBoost;
  return m;
}
function income() { let b = 0; S.plots.forEach((p, i) => { if (p && i < S.plotCount && CROP[p].rate) b += CROP[p].rate; }); return b * mult() + S.clones * CFG.cloneRate; }
const price = it => Math.round(it.cost * (S.char === 'vika' ? CFG.vikaDiscount : 1));
const progress = () => ALL_ITEMS.filter(i => S.bought[i.id]).length / ALL_ITEMS.length;
const other = w => w === 'yarik' ? 'vika' : 'yarik';
const floorBuilt = f => f === 1 || !!S.floors[f];
const cowCost = () => Math.round(CFG.cowCost * Math.pow(CFG.cowGrow, S.cows));
const cloneCost = () => Math.round(CFG.cloneCost * Math.pow(CFG.cloneGrow, S.clones));
const mmss = s => Math.floor(s / 60) + ':' + String(Math.ceil(s % 60) % 60).padStart(2, '0');

/* что рисуется над головой при занятии */
const BUB = { eat: '🥛', gym: '🏋️', yoga: '🧘', beer: '🍺', water: '💧', cook: '🍳', tv: '📺', clone: '🧬', pet: '🐄', read: '📚', sit: '🛋️' };

const LOCICO = ch => {
  if (S.jail > 0 && ch.who === 'vika') return '⛓️';
  if (ch.place === 'yard') return '🌱';
  if (ch.place === 'barn') return '🐄';
  if (ch.floor === 3) return '🏋️';
  if (ch.floor === 2) return '🍽️';
  if (ch.floor === 0) return S.char === 'yarik' ? '🧬' : '🏠';   // про подвал Вика не знает
  return '🏠';
};

function chScreen(ch, mode) {
  const k = ch.who === 'vika' ? 0.96 : 1;
  if (ch.place === 'yard') return mode === 'top' ? { x: ch.x, y: ch.y, h: 84 * k } : { x: ch.x, y: 500 + (ch.y - 150) / 385 * 28, h: 118 * k };
  return mode === 'top' ? { x: ch.x, y: HY0 + ch.y + 14, h: 86 * k } : { x: sideX(ch.x, ch.floor), y: FL + 12 + (ch.y - 28) / 290 * 12, h: 124 * k };
}

/* Камера «как в Toca Boca»: в виде сбоку дом приближен и едет за героем из комнаты в комнату. */
const CAM_Z = 2.3, CAM_VW = 660, CAM_VH = 540;
function camOn(G) { return settings.cam === 'side' && G.view === 'house' && G.floor !== 0; }
function camTarget(G) {
  const vw = CAM_VW / CAM_Z, vh = CAM_VH / CAM_Z;
  let fx = 330;
  const ch = G.ch && G.ch[S.char], wide = G.floor === 1 && h1ok();
  if (ch && !ch.hidden && ch.place === 'house' && ch.floor === G.floor) fx = sideX(ch.x, G.floor);
  return { x: clamp(fx - vw / 2, 32, (wide ? H1.W : 628) - vw), y: CEIL + (wide ? 17 : 4) };
}
function camStep(G, dt) {
  const tg = camTarget(G), key = G.view + ':' + G.floor + ':' + S.char;
  if (!G.cam || G.camKey !== key) { G.cam = { x: tg.x, y: tg.y }; G.camKey = key; return; }
  const k = 1 - Math.exp(-dt * 6);
  G.cam.x += (tg.x - G.cam.x) * k; G.cam.y += (tg.y - G.cam.y) * k;
}
function camBegin(g, G) { g.save(); g.translate(-G.cam.x * CAM_Z, -G.cam.y * CAM_Z); g.scale(CAM_Z, CAM_Z); }

/* ---------------------------------------------------------------- ИГРА */
SCENES.game = {
  enter(arg) {
    arg = arg || {};
    if (!S) S = loadSave() || newState();
    this.fx = []; this.floats = []; this.wt = []; this.pt = [];
    this.saveT = 0; this.afT = 0; this.quizWait = 0; this.evT = rnd(45, 75); this.susT = rnd(240, 360);
    this.cowAcc = 0; this.sleeping = false; this.cache = {};
    if (S.jail > 0) S.char = 'yarik';
    const home = arg.morning || arg.trip || arg.jailed;
    const startPlace = arg.fresh ? 'yard' : 'house';
    this.ch = { vika: this.mkCh('vika', startPlace), yarik: this.mkCh('yarik', startPlace) };
    if (arg.morning) { this.ch.vika.x = 120; this.ch.yarik.x = 80; this.ch.vika.y = this.ch.yarik.y = 120; }
    if (S.jail > 0) this.ch.vika.hidden = true;
    const a = this.ch[S.char];
    this.view = a.place; this.floor = a.floor;
    this.buildHud(); this.renderPanel();
    if (arg.cont) {
      const gone = Math.min((Date.now() - (S.lastSeen || Date.now())) / 1000, 3600), gain = income() * gone;
      if (gone > 10 && gain >= 1) { S.money += gain; toast('Пока вас не было: +$' + fmt(gain)); }
      if (S.jail > 0) { S.jail = Math.max(0, S.jail - gone); if (S.jail <= 0) this.release(false); }
    }
    if (arg.fresh) {
      say([
        { who: 'vika', text: 'Ну вот и дом… Тут столько работы! Крыша течёт, обои отваливаются.' },
        { who: 'yarik', text: 'Зато он наш. Денег осталось 50$, надо зарабатывать.' },
        { who: 'yarik', text: 'Начнём с двора: куст стоит 10$ и приносит 1$ в секунду. Потом уберём мусор в доме и купим мебель.' },
        { who: 'vika', text: 'А я буду иногда спрашивать, помнишь ли ты… всякое. Лучше помни!' },
      ]);
    }
    if (arg.morning) { toast('Новый день ' + S.day + ' · ' + Day.label(S.clock)); }
    if (arg.jailed) this.jailIntro();
  },
  leave() { save(); },

  mkCh(who, place) {
    const y = place === 'yard' ? 190 : 200, x = who === 'yarik' ? 330 : 270;
    return { who, place, floor: 1, x, y, tx: x, ty: y, face: 1, walk: false, route: [], wait: 0, act: null, actT: 0, ai: rnd(2, 5), bub: null, hidden: false, tick: 0 };
  },

  /* ----- HUD ----- */
  buildHud() {
    const self = this;
    const hud = el('<div class="hud hit"><div class="stat money"><b id="h-m"></b><small id="h-r"></small></div><div class="stat"><b id="h-h"></b><small>любовь</small></div><div class="stat clock"><b id="h-t"></b><small id="h-d"></small></div><button class="mood" id="h-md"></button><div class="ppl" id="h-ppl"></div><button class="chip" id="h-sw"></button><div class="camtog" id="h-cam"></div><button class="gear" id="h-g">⚙</button></div>');
    const panel = el('<div class="panel hit"><div class="tabs"><button data-v="house">' + ICO.house + '<span>Дом</span></button><button data-v="yard">' + ICO.yard + '<span>Двор</span></button><button data-v="barn">' + ICO.barn + '<span>Амбар</span></button><button data-v="shop">' + ICO.cart + '<span>Магазин</span></button></div><div class="prog"><i id="h-pg"></i><span id="h-pt"></span></div><div class="list" id="list"></div></div>');
    ui.appendChild(hud); ui.appendChild(panel);
    panel.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { click(); self.setView(b.dataset.v === 'shop' ? 'shop' : b.dataset.v); });
    $('#h-sw').onclick = () => self.swap();
    $('#h-g').onclick = () => self.pause();
    $('#h-md').onclick = () => { if (S.jail > 0) self.bailModal(); };
    $('#h-cam').innerHTML = '<button data-m="top" title="Вид сверху">' + ICO.top + '</button><button data-m="side" title="Вид сбоку">' + ICO.side + '</button>';
    $('#h-cam').querySelectorAll('button').forEach(b => b.onclick = () => { click(); settings.cam = b.dataset.m; applySettings(); self.paintCam(); });
    this.paintChip(); this.paintCam();
  },
  paintCam() { document.querySelectorAll('#h-cam button').forEach(b => b.classList.toggle('on', b.dataset.m === settings.cam)); },
  paintChip() {
    const w = S.char;
    $('#h-sw').innerHTML = '<span class="mini ' + w + '"></span><span><b>' + NAMES[w] + '</b><small>' + CHAR_INFO[w].perk + ' · сменить</small></span>';
  },
  swap() {
    const to = other(S.char);
    if (to === 'vika' && S.jail > 0) { Aud.sfx('no'); toast('Вика в участке: ещё ' + mmss(S.jail)); return; }
    S.char = to; Aud.sfx('swap');
    this.ch.vika.route = []; this.ch.yarik.route = []; this.ch.vika.act = this.ch.yarik.act = null;
    this.ch[other(to)].ai = 1; this.quizWait = 0;
    this.paintChip();
    const a = this.ch[to];
    this.setView(a.place, a.floor);
    toast('Теперь играешь за ' + NAMES[to] + ': ' + CHAR_INFO[to].perk);
  },
  /* камера: view = 'house' | 'yard' | 'barn' | 'shop' (магазин — это только вкладка панели) */
  setView(v, f) {
    if (v === 'shop') { this.panelTab = 'shop'; this.renderPanel(); return; }
    this.panelTab = v; this.view = v;
    if (v === 'house') { f = f === undefined ? (this.floor || 1) : f; if (f === 0 && S.char !== 'yarik') f = 1; this.floor = f; } else this.floor = 1;
    this.quizPeek = false; this.renderPanel();
  },
  pause() {
    const self = this;
    const m = modal('<h2>Пауза</h2><div class="stack"><button class="btn primary" data-a="r">Продолжить</button><button class="btn" data-a="s">Настройки</button><button class="btn" data-a="m">В главное меню</button></div>');
    m.querySelectorAll('button').forEach(b => b.onclick = () => {
      click(); const a = b.dataset.a;
      if (a === 'r') m.remove();
      else if (a === 's') openSettings();
      else { m.remove(); save(); go('menu'); }
    });
  },
  updateHud() {
    const r = income(), set = (id, v) => { if (this.cache[id] !== v) { this.cache[id] = v; $(id).textContent = v; } };
    const setH = (id, v) => { if (this.cache[id] !== v) { this.cache[id] = v; $(id).innerHTML = v; } };
    set('#h-m', '$' + fmt(S.money));
    set('#h-r', '+' + (r < 10 ? r.toFixed(1) : fmt(r)) + '$/сек');
    set('#h-h', '❤ ' + S.hearts);
    const ph = Day.phase(S.clock);
    set('#h-t', ph.ic + ' ' + ph.name); set('#h-d', 'день ' + S.day);
    const p = Math.round(progress() * 100);
    set('#h-pt', 'Дом готов на ' + p + '%');
    $('#h-pg').style.width = p + '%';
    let st = '';
    if (S.jail > 0) st = '⛓️ Вика в участке ' + mmss(S.jail) + ' · залог';
    else if (S.boostT > 0) st = '⚡ +30% ' + Math.ceil(S.boostT) + 'с';
    else if (S.mood > 0) st = '😤 ' + (S.sulker === 'vika' ? 'Вика обиделась' : 'Ярик обиделся') + ' · ' + Math.ceil(S.mood) + 'с';
    set('#h-md', st); $('#h-md').classList.toggle('jail', S.jail > 0); $('#h-md').classList.toggle('boost', S.jail <= 0 && S.boostT > 0);
    const fb = w => '<span class="pp' + (S.char === w ? ' me' : '') + '" data-w="' + w + '"><i class="mini ' + w + '"></i><em>' + LOCICO(this.ch[w]) + '</em><u><s style="width:' + Math.round(S.food[w]) + '%;background:' + (S.food[w] < CFG.hungryBelow ? '#ff7a7a' : '#7fd19a') + '"></s></u></span>';
    const ppl = fb('vika') + fb('yarik');
    if (this.cache['#h-ppl'] !== ppl) {
      this.cache['#h-ppl'] = ppl; $('#h-ppl').innerHTML = ppl;
      $('#h-ppl').querySelectorAll('.pp').forEach(n => n.onclick = () => { click(); const c2 = this.ch[n.dataset.w]; if (c2.hidden) return; this.setView(c2.place, c2.floor); });
    }
  },

  /* ----- панель справа ----- */
  renderPanel() {
    const self = this, list = $('#list');
    const tab = this.panelTab || this.view;
    document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === tab));
    list.innerHTML = '';
    const add = n => list.appendChild(n);
    const item = (cls, cost, ic, nm, sub, pr, fn) => {
      const b = el('<button class="item ' + cls + '" data-cost="' + cost + '"><span class="ic">' + ic + '</span><span class="nm">' + nm + (sub ? '<small>' + sub + '</small>' : '') + '</span><span class="pr">' + pr + '</span></button>');
      b.onclick = fn; add(b); return b;
    };
    if (tab === 'house') this.panelHouse(add, item);
    else if (tab === 'yard') this.panelYard(add, item);
    else if (tab === 'barn') this.panelBarn(add, item);
    else this.panelShop(add, item);
    this.refreshAfford();
  },
  panelHouse(add, item) {
    const self = this, f = this.floor;
    const fl = el('<div class="floors"></div>');
    [[1, '1'], [2, '2'], [3, '3'], [0, '⬇']].forEach(a => {
      if (a[0] === 0 && S.char !== 'yarik') return;   // подвал знает только Ярик
      const built = floorBuilt(a[0]);
      const b = el('<button class="' + (f === a[0] ? 'on ' : '') + (built ? '' : 'lock') + '">' + (built ? a[1] : '🔒') + '</button>');
      b.onclick = () => { click(); self.setView('house', a[0]); };
      fl.appendChild(b);
    });
    add(fl);
    if (!floorBuilt(f)) {
      const info = FLOOR_INFO[f];
      add(el('<div class="note"><b>' + info.name + '</b><br><small>' + info.desc + '. Пока не достроен.</small></div>'));
      item('', info.cost, '🏗️', 'Достроить', f === 3 && !S.floors[2] ? 'сначала второй этаж' : '', '$' + fmt(info.cost), () => self.buildModal(f));
      return;
    }
    if (f === 0) {
      add(el('<div class="note">🤫 <b>Тайная комната Ярика</b><br><small>Клоны работают вместо него и приносят +$' + CFG.cloneRate + '/сек каждый. Вика об этом не знает.</small></div>'));
      add(el('<h3>Клоны · ' + S.clones + '/' + CFG.cloneMax + '</h3>'));
      if (S.clones < CFG.cloneMax) item('', cloneCost(), '🧬', 'Новый клон', '+$' + CFG.cloneRate + '/сек', '$' + fmt(cloneCost()), () => self.buyClone());
      else add(el('<div class="note ok">Все капсулы заняты</div>'));
      return;
    }
    if (f === 1) {
      const left = trashLeft();
      add(el('<div class="note ' + (left ? '' : 'ok') + '">' + (left ? '🧹 Мусор: осталось ' + left + ' из ' + S.trash.length + '<br><small>Нажимай на кучи в доме (+$' + CFG.trashReward + ' за каждую)</small>' : '✔ В доме чисто, можно обставлять') + '</div>'));
      ROOMS.forEach(room => {
        add(el('<h3>' + room.name + '</h3>'));
        room.items.forEach(it => {
          const done = !!S.bought[it.id], locked = !done && left > 0, p = price(it);
          item((done ? 'done' : '') + (locked ? ' locked' : ''), done || locked ? 0 : p, Art.icon(it.id, it.icon), it.name, '', done ? '✔' : '$' + fmt(p), () => self.buyItem(it));
        });
      });
      const sn = ROOMS2.length;   // подсказка про этажи
      add(el('<div class="note"><small>Выше — 2 и 3 этажи, ниже — подвал. Переключай этажи кнопками сверху.</small></div>'));
      return;
    }
    add(el('<div class="note"><small>Каждый предмет на этажах даёт +' + Math.round(CFG.comfort * 100) + '% к доходу огорода. Сейчас: +' + Math.round(comfort() * 100) + '%.</small></div>'));
    ROOMS2.filter(r => r.floor === f).forEach(room => {
      add(el('<h3>' + room.name + '</h3>'));
      room.items.forEach(it => {
        const done = !!S.bought[it.id], p = price(it);
        item(done ? 'done' : '', done ? 0 : p, Art.icon(it.id, it.icon), it.name, '', done ? '✔' : '$' + fmt(p), () => self.buyExtra(it));
      });
    });
  },
  panelYard(add, item) {
    const self = this, ICON = { bush: '🌿', berry: '🍓', pumpkin: '🎃', apple: '🍎' };
    add(el('<div class="note">Выбери растение и нажимай на пустую грядку. Нажми на растение — полить: +$1.</div>'));
    add(el('<h3>Посадить</h3>'));
    CROPS.forEach(k => {
      const n = S.plots.filter(p => p === k.id).length;
      item(S.tool === k.id ? 'sel' : '', k.cost, ICON[k.id], k.name, '+$' + k.rate + '/сек · посажено ' + n, '$' + fmt(k.cost), () => { click(); S.tool = k.id; self.renderPanel(); });
    });
    item(S.tool === 'mega' ? 'sel mega' : 'mega', 0, '🌟', 'Мега-семя', 'на 20с: +30% всем растениям · есть ' + S.mega, '×' + S.mega, () => { click(); S.tool = 'mega'; self.renderPanel(); if (!S.mega) toast('Мега-семена продаются в супермаркете (вкладка «Магазин»)'); });
    item(S.tool === 'remove' ? 'sel' : '', 0, '⛏️', 'Выкопать', 'вернёт ' + Math.round(CFG.removeRefund * 100) + '% цены', '', () => { click(); S.tool = 'remove'; self.renderPanel(); });
    add(el('<h3>Двор</h3>'));
    if (S.plotCount < CFG.plotsMax) {
      const cost = EXPAND_COST[(S.plotCount - CFG.plotsStart) / 6] || 9000;
      item('', cost, '➕', 'Ещё 6 грядок', 'новый ряд · ' + (S.plotCount / 6 | 0) + ' из ' + (CFG.plotsMax / 6), '$' + fmt(cost), () => self.expandModal(cost));
    }
    UPGRADES.forEach(u => {
      const done = !!S.upg[u.id];
      item(done ? 'done' : '', done ? 0 : u.cost, u.icon, u.name, u.desc, done ? '✔' : '$' + fmt(u.cost), () => self.buyUpgrade(u));
    });
  },
  panelBarn(add, item) {
    const self = this;
    add(el('<div class="note">🐄 Коровы дают молоко и сыр. Герои едят сами: сытые работают лучше, голодные медленнее.</div>'));
    add(el('<h3>Продукты</h3>'));
    add(el('<div class="note stock">🥛 молоко: <b>' + S.prod.milk + '</b> &nbsp; 🧀 сыр: <b>' + S.prod.cheese + '</b></div>'));
    item('', 0, '💵', 'Продать молоко', '$' + CFG.milkSell + ' за штуку', '', () => self.sell('milk'));
    item('', 0, '💵', 'Продать сыр', '$' + CFG.cheeseSell + ' за штуку', '', () => self.sell('cheese'));
    add(el('<h3>Коровы · ' + S.cows + '/' + CFG.cowMax + '</h3>'));
    if (S.cows < CFG.cowMax) item('', cowCost(), '🐄', 'Купить корову', 'продукт раз в ~' + Math.round(CFG.cowEvery / Math.max(1, S.cows + 1)) + ' с', '$' + fmt(cowCost()), () => self.buyCow());
    else add(el('<div class="note ok">Амбар полон</div>'));
  },
  panelShop(add, item) {
    const self = this;
    if (S.jail > 0) {
      add(el('<div class="note">⛓️ Вика в участке ещё ' + mmss(S.jail) + '.<br><small>Можно подождать или заплатить залог.</small></div>'));
      item('', CFG.bail, '🔓', 'Заплатить залог', '', '$' + fmt(CFG.bail), () => self.bailModal());
      return;
    }
    add(el('<div class="note">🛒 <b>Супермаркет</b><br><small>Мега-семена и еда. Ехать — на машине. Права только у Ярика.</small></div>'));
    add(el('<div class="note stock">🌟 мега-семян: <b>' + S.mega + '</b> &nbsp; 🥛 ' + S.prod.milk + ' &nbsp; 🧀 ' + S.prod.cheese + '</div>'));
    if (S.char === 'yarik') item('sel', 0, '🚗', 'Поехать в супермаркет', 'мини-игра по дороге', '', () => { click(); self.startTrip('yarik'); });
    else item('danger', 0, '🚗', 'Поехать тайком от Ярика', 'у Вики нет прав…', '', () => self.sneakModal());
  },
  refreshAfford() {
    document.querySelectorAll('.item[data-cost]').forEach(b => b.classList.toggle('poor', +b.dataset.cost > 0 && S.money < +b.dataset.cost));
  },
  spend(n) {
    if (S.money < n) { Aud.sfx('no'); toast('Не хватает $' + fmt(n - S.money)); return false; }
    S.money -= n; return true;
  },

  /* ----- покупки ----- */
  buyItem(it) {
    if (S.bought[it.id]) return;
    if (!trashDone()) { Aud.sfx('no'); toast('Сначала убери мусор в доме'); return; }
    if (!this.spend(price(it))) return;
    S.bought[it.id] = true; Aud.sfx('coin');
    this.burst(330, 300, 18, '#ffd98a'); this.renderPanel(); this.updateHud();
    if (ALL_ITEMS.every(i => S.bought[i.id]) && !S.finished) this.finale();
  },
  buyExtra(it) {
    if (S.bought[it.id]) return;
    if (!this.spend(price(it))) return;
    S.bought[it.id] = true; Aud.sfx('coin'); this.burst(330, 300, 18, '#ffd98a'); this.renderPanel();
    toast('Комфорт: +' + Math.round(comfort() * 100) + '% к доходу огорода');
  },
  buildModal(f) {
    const self = this, info = FLOOR_INFO[f];
    if (f === 3 && !S.floors[2]) { Aud.sfx('no'); toast('Сначала дострой второй этаж'); return; }
    const m = modal('<h2>' + info.name + '</h2><p>' + info.desc + '. Достроить за <b>$' + fmt(info.cost) + '</b>?</p><div class="stack"><button class="btn primary" id="y">Достроить</button><button class="btn" id="n">Не сейчас</button></div>');
    $('#n', m).onclick = () => { click(); m.remove(); };
    $('#y', m).onclick = () => {
      if (!self.spend(info.cost)) return;
      S.floors[f] = true; Aud.sfx('boost'); m.remove(); self.burst(330, 300, 26, '#ffd98a');
      toast(f === 0 ? '🤫 Подвал готов. Это наш с тобой секрет' : '🏗️ ' + info.name + ' готов!');
      self.setView('house', f);
    };
  },
  expandModal(cost) {
    const self = this;
    const m = modal('<h2>Новый ряд грядок</h2><p>Расширить двор на 6 грядок за <b>$' + fmt(cost) + '</b>?</p><div class="stack"><button class="btn primary" id="y">Купить</button><button class="btn" id="n">Не сейчас</button></div>');
    $('#n', m).onclick = () => { click(); m.remove(); };
    $('#y', m).onclick = () => { if (self.expand(cost)) m.remove(); };
  },
  buyUpgrade(u) {
    if (S.upg[u.id]) return;
    if (!this.spend(u.cost)) return;
    S.upg[u.id] = true; Aud.sfx('coin'); this.burst(330, 300, 14, '#7fd19a'); this.renderPanel();
  },
  expand(cost) {
    if (S.plotCount >= CFG.plotsMax) return false;
    if (!this.spend(cost)) return false;
    S.plotCount += 6; Aud.sfx('coin'); this.renderPanel(); return true;
  },
  buyCow() {
    if (S.cows >= CFG.cowMax) return;
    if (!this.spend(cowCost())) return;
    S.cows++; Aud.sfx('moo'); this.burst(330, 300, 14, '#ffffff'); this.renderPanel();
    toast('🐄 Новая корова!');
  },
  buyClone() {
    if (S.char !== 'yarik') return;
    if (S.clones >= CFG.cloneMax) return;
    if (!this.spend(cloneCost())) return;
    S.clones++; Aud.sfx('boost'); this.burst(330, 300, 18, '#7fffbe'); this.renderPanel();
    toast('🧬 Клон готов: +$' + CFG.cloneRate + '/сек');
  },
  sell(k) {
    const n = S.prod[k]; if (!n) { Aud.sfx('no'); toast('Продавать нечего'); return; }
    const sum = n * (k === 'milk' ? CFG.milkSell : CFG.cheeseSell);
    S.prod[k] = 0; S.money += sum; Aud.sfx('coin'); toast('💵 +$' + sum); this.renderPanel();
  },
  finale() {
    S.finished = true; save();
    say([
      { who: 'vika', text: 'Ярик… Мы справились. Это правда наш дом.' },
      { who: 'yarik', text: 'Наш. Со всеми скрипучими полами и твоими вопросами.' },
      { who: 'vika', text: 'А помнишь, с чего всё началось? Туалетная бумага на вечеринке…', },
      { who: 'yarik', text: 'Такое не забудешь ❤ Спасибо, что играл! Двор ещё растёт — можно продолжать: впереди этажи, амбар и супермаркет.' },
    ]);
  },

  /* ----- еда ----- */
  eat(who) {
    const useCheese = S.prod.cheese > 0 && (S.food[who] < 50 || !S.prod.milk);
    if (useCheese) { S.prod.cheese--; S.food[who] = Math.min(100, S.food[who] + CFG.cheeseFood); }
    else if (S.prod.milk > 0) { S.prod.milk--; S.food[who] = Math.min(100, S.food[who] + CFG.milkFood); }
    else return false;
    this.ch[who].bub = useCheese ? '🧀' : '🥛'; this.ch[who].bubT = 1.6; Aud.sfx('pop');
    if (this.panelTab === 'barn' || this.panelTab === 'shop') this.renderPanel();
    return true;
  },

  /* ----- движение и маршруты ----- */
  routeTo(ch, place, floor, x, y) {
    const legs = []; let px = ch.x, py = ch.y;
    const path = nodePath(nodeOf(ch.place, ch.floor), nodeOf(place, floor));
    for (let i = 0; i + 1 < path.length; i++) {
      const e = EDGE[path[i] + '>' + path[i + 1]], out = e[0], inn = e[1], to = NODEP[path[i + 1]];
      if (Math.hypot(px - out.x, py - out.y) > 6) legs.push({ k: 'walk', x: out.x, y: out.y });
      legs.push({ k: 'xit', place: to[0], floor: to[1], x: inn.x, y: inn.y });
      px = inn.x; py = inn.y;
    }
    if (Math.hypot(px - x, py - y) > 4) legs.push({ k: 'walk', x, y });
    return legs;
  },
  /* Герой появляется в том месте, на которое смотрит камера (если он был в другом). */
  bringHere(ch) {
    const v = this.view, f = this.floor;
    if (ch.place === v && (v !== 'house' || ch.floor === f)) return;
    ch.route = []; ch.act = null; ch.place = v; ch.floor = v === 'house' ? f : 1;
    const e = v === 'yard' ? EXITS.yard.house : v === 'barn' ? EXITS.barn.door : f === 1 ? EXITS.house.door : f === 0 ? EXITS.house.base : EXITS.house.down;
    ch.x = ch.tx = e.x; ch.y = ch.ty = e.y; ch.wait = 0.25; Aud.sfx('door');
  },
  /* команда активному герою */
  cmd(place, floor, x, y, fn) {
    const ch = this.ch[S.char];
    ch.act = null; ch.bub = null;
    if (place === this.view && (place !== 'house' || floor === this.floor)) this.bringHere(ch);
    const b = BOUNDS[place];
    x = clamp(x, b.x0, b.x1); y = clamp(y, b.y0, b.y1);
    ch.route = this.routeTo(ch, place, floor, x, y);
    if (fn) ch.route.push({ k: 'call', fn });
  },
  walkHere(x, y, fn) { this.cmd(this.view, this.floor, x, y, fn); },

  moveCh(ch, dt, spd) {
    const dx = ch.tx - ch.x, dy = ch.ty - ch.y, d = Math.hypot(dx, dy);
    if (d > 1.5) { const k = Math.min(1, spd * dt / d); ch.x += dx * k; ch.y += dy * k; if (Math.abs(dx) > 0.5) ch.face = dx > 0 ? 1 : -1; ch.walk = true; }
    else ch.walk = false;
    return d;
  },
  updateCh(ch, dt, active) {
    if (ch.hidden) return;
    if (ch.bubT > 0) { ch.bubT -= dt; if (ch.bubT <= 0 && !ch.act) ch.bub = null; }
    if (ch.wait > 0) { ch.wait -= dt; return; }
    const leg = ch.route[0];
    if (!leg) {
      ch.walk = false;
      if (!active) this.thinkAI(ch, dt);
      return;
    }
    const spd = active ? 250 : 170;
    if (leg.k === 'walk') {
      ch.tx = leg.x; ch.ty = leg.y;
      if (this.moveCh(ch, dt, spd) <= 3) ch.route.shift();
    } else if (leg.k === 'xit') {
      ch.walk = false; ch.place = leg.place; ch.floor = leg.floor;
      ch.x = ch.tx = leg.x; ch.y = ch.ty = leg.y; ch.wait = 0.35; ch.route.shift();
      if (active) { this.setView(leg.place, leg.floor); Aud.sfx('door'); }
    } else if (leg.k === 'call') { ch.route.shift(); leg.fn(); }
    else if (leg.k === 'act') {
      ch.walk = false;
      if (ch.act !== leg.act) { ch.act = leg.act; ch.actT = leg.dur; ch.tick = 0; ch.bub = leg.bub || BUB[leg.act] || null; ch.bubT = 0; if (leg.face) ch.face = leg.face; }
      ch.actT -= dt; ch.tick += dt;
      if (leg.act === 'water' && ch.tick >= 2.2) { ch.tick = 0; S.money += 1; const s = chScreen(ch, settings.cam); this.floats.push({ x: s.x, y: s.y - s.h, t: 0, s: '+$1' }); Aud.sfx('water'); }
      if (ch.actT <= 0) { ch.route.shift(); this.finishAct(ch, leg); ch.act = null; ch.bub = null; }
    }
  },
  finishAct(ch, leg) {
    if (leg.act === 'eat') { if (!this.eat(ch.who)) { ch.bub = '😕'; ch.bubT = 1.2; } }
    ch.ai = rnd(1.5, 4);
  },

  /* ----- что делает герой, когда им никто не управляет ----- */
  thinkAI(ch, dt) {
    if (this.quizWait > 0) return;
    ch.ai -= dt; if (ch.ai > 0) return;
    const g = this.pickGoal(ch);
    ch.route = this.routeTo(ch, g.place, g.floor, g.x, g.y);
    ch.route.push({ k: 'act', act: g.act, dur: g.dur, face: g.face });
    ch.ai = 2;
  },
  pickGoal(ch) {
    const who = ch.who, opts = [], add = (w, g) => opts.push([w, g]);
    const stock = S.prod.milk + S.prod.cheese, fx = FURN.fridge.tp;
    const fridgeX = S.bought.fridge ? fx[0] + fx[2] / 2 : 330;
    if (S.food[who] < CFG.eatBelow && stock > 0) return { place: 'house', floor: 1, x: fridgeX, y: 66, act: 'eat', dur: 3.5 };
    const planted = []; S.plots.forEach((p, i) => { if (p && i < S.plotCount) planted.push(i); });
    add(1.5, { place: 'house', floor: 1, x: rnd(110, 560), y: rnd(120, 290), act: 'wander', dur: rnd(1.5, 3) });
    if (S.bought.stove) add(1.5, { place: 'house', floor: 1, x: 275, y: 66, act: 'cook', dur: rnd(5, 8), face: 1 });
    if (S.bought.sofa && S.bought.tv) add(2, { place: 'house', floor: 1, x: 520, y: 205, act: 'tv', dur: rnd(9, 15), face: 1 });
    if (planted.length) { const i = planted[Math.floor(Math.random() * planted.length)], r = plotRect(i, 'top'); add(3, { place: 'yard', floor: 1, x: r[0] + r[2] / 2, y: r[1] + r[3] + 6, act: 'water', dur: rnd(7, 11) }); }
    if (S.cows) { const k = Math.floor(Math.random() * S.cows), p = stallPos(k, 'top'); add(2, { place: 'barn', floor: 1, x: p[0], y: p[1] + 56 - HY0 - 14, act: 'pet', dur: rnd(6, 9) }); }
    if (floorBuilt(2) && S.bought.shelf) add(1.5, { place: 'house', floor: 2, x: 540, y: 110, act: 'read', dur: rnd(8, 12) });
    if (who === 'vika') {
      const gym = ['mat', 'treadm', 'weights', 'bike'].some(id => S.bought[id]);
      if (floorBuilt(3)) add(gym ? 6 : 1, { place: 'house', floor: 3, x: rnd(120, 560), y: rnd(150, 290), act: Math.random() < 0.4 ? 'yoga' : 'gym', dur: rnd(12, 20) });
    } else {
      add(S.bought.fridge ? 5 : 2, { place: 'house', floor: 1, x: fridgeX, y: 66, act: 'beer', dur: rnd(5, 7) });
      if (S.floors[0] && S.clones > 0) add(5, { place: 'house', floor: 0, x: rnd(120, 520), y: rnd(120, 260), act: 'clone', dur: rnd(10, 16) });
    }
    let tot = 0; opts.forEach(o => tot += o[0]);
    let r = Math.random() * tot; for (const o of opts) { r -= o[0]; if (r <= 0) return o[1]; }
    return opts[0][1];
  },

  /* ----- действия в мире ----- */
  clean(i) {
    if (S.trash[i]) return;
    S.trash[i] = true; S.money += CFG.trashReward; Aud.sfx('pop');
    const mode = settings.cam, px = mode === 'top' ? TRASH[i].x : TRASH[i].x, py = mode === 'top' ? HY0 + TRASH[i].y : FL - 20;
    this.burst(px, py, 12, '#c9b79a'); this.floats.push({ x: px, y: py - 30, t: 0, s: '+$' + CFG.trashReward });
    if (trashDone()) toast('В доме чисто! Теперь можно покупать мебель');
    this.renderPanel();
  },
  plotCenter(i) { const r = plotRect(i, settings.cam); return [r[0] + r[2] / 2, r[1] + r[3] / 2]; },
  plot(i) {
    const k = S.plots[i], cc = this.plotCenter(i);
    const me = this.ch[S.char];
    if (k === 'mega') { toast('⚡ Мега-растение растёт…'); return; }
    if (S.tool === 'remove') {
      if (!k) { toast('Тут и так пусто'); return; }
      const back = Math.round(CROP[k].cost * CFG.removeRefund);
      S.plots[i] = null; S.money += back; Aud.sfx('pop'); this.burst(cc[0], cc[1], 10, '#a98a5a');
      this.floats.push({ x: cc[0], y: cc[1] - 20, t: 0, s: '+$' + back }); this.renderPanel(); return;
    }
    if (k) {
      if (S.tool !== k && CROP[S.tool]) { this.replaceModal(i, k); return; }
      if (T - (this.wt[i] || 0) < 0.9) return;
      this.wt[i] = T; S.money += 1; Aud.sfx('water'); this.floats.push({ x: cc[0], y: cc[1] - 20, t: 0, s: '+$1' });
      return;
    }
    if (S.tool === 'mega') {
      if (S.mega <= 0) { Aud.sfx('no'); toast('Нет мега-семян: купи в супермаркете'); return; }
      S.mega--; S.plots[i] = 'mega'; this.pt[i] = T; Aud.sfx('plant'); this.burst(cc[0], cc[1], 12, '#b48cff'); this.renderPanel(); return;
    }
    const kk = CROP[S.tool];
    if (!this.spend(kk.cost)) return;
    S.plots[i] = kk.id; this.pt[i] = T; Aud.sfx('plant'); this.burst(cc[0], cc[1], 10, '#7fd19a'); this.renderPanel();
  },
  replaceModal(i, old) {
    const self = this, nw = CROP[S.tool], back = Math.round(CROP[old].cost * CFG.removeRefund);
    const m = modal('<h2>Заменить растение?</h2><p>' + CROP[old].name + ' уйдёт с грядки (вернётся $' + back + '), вместо него — ' + nw.name + ' за $' + fmt(nw.cost) + '.</p><div class="stack"><button class="btn primary" id="y">Заменить</button><button class="btn" id="n">Оставить</button></div>');
    $('#n', m).onclick = () => { click(); m.remove(); };
    $('#y', m).onclick = () => {
      if (S.money + back < nw.cost) { Aud.sfx('no'); toast('Не хватает $' + fmt(nw.cost - S.money - back)); return; }
      S.money += back; S.money -= nw.cost; S.plots[i] = nw.id; self.pt[i] = T; Aud.sfx('plant'); m.remove(); self.renderPanel();
    };
  },
  burst(x, y, n, col) { for (let i = 0; i < n; i++) this.fx.push({ x, y, vx: rnd(-90, 90), vy: rnd(-170, -40), l: rnd(0.5, 0.9), col }); },

  /* ----- нажатия на мир ----- */
  hit(x, y, r) { return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3]; },
  pointer(x, y) {
    if (busy() || x > 660 || y < 60) return;
    const mode = settings.cam, v = this.view, f = this.floor;
    if (camOn(this) && this.cam) { x = logX(x / CAM_Z + this.cam.x, this.floor); y = y / CAM_Z + this.cam.y; }
    if (S.jail > 0 && S.char === 'vika') S.char = 'yarik';
    if (v === 'house') return this.tapHouse(x, y, mode, f);
    if (v === 'yard') return this.tapYard(x, y, mode);
    return this.tapBarn(x, y, mode);
  },
  walkTarget(x, y, mode) {   // нажатие в пустое место: идём туда
    const b = BOUNDS[this.view];
    if (mode === 'top') return [x, this.view === 'yard' ? y : y - HY0 - 14];
    return [x, this.ch[S.char].y];
  },
  tapHouse(x, y, mode, f) {
    const self = this;
    const goHouse = (fl, ax, ay) => { self.cmd('house', fl, ax, ay); };
    // лестницы
    const upR = mode === 'top' ? [572, HY0 + 8, 54, 44] : [586, CEIL + 8, 46, 150];
    const dnR = mode === 'top' ? [572, HY0 + HH - 52, 54, 44] : [586, FL - 60, 46, 60];
    if (f < 3 && f > 0 && this.hit(x, y, upR)) {
      if (!floorBuilt(f + 1)) { Aud.sfx('no'); this.buildModal(f + 1); return; }
      this.cmd('house', f + 1, 560, 296); return;
    }
    if (f > 1 && this.hit(x, y, dnR)) { this.cmd('house', f - 1, 560, 70); return; }
    if (f === 1) {
      const hatch = mode === 'top' ? [36, HY0 + HH - 52, 50, 44] : [36, FL - 30, 62, 50];
      if (this.hit(x, y, hatch)) {
        if (S.char !== 'yarik') { Aud.sfx('no'); toast('Вике незачем в подвал: там просто сыро'); return; }
        if (!S.floors[0]) { Aud.sfx('no'); this.buildModal(0); return; }
        this.cmd('house', 0, 120, 120); return;
      }
      const door = mode === 'top' ? [296, HY0 + HH - 14, 70, 28] : [300, FL - 40, 60, 54];
      if (this.hit(x, y, door)) { this.cmd('yard', 1, 175, 196); return; }
    }
    if (f === 0) {
      const ex = mode === 'top' ? [36, HY0 + 8, 50, 44] : [36, CEIL - 10, 62, 40];
      if (this.hit(x, y, ex) || (mode === 'side' && this.hit(x, y, [586, FL - 60, 46, 60]))) { this.cmd('house', 1, 100, 250); return; }
    }
    if (f === 1) {
      // мусор
      const i = TRASH.findIndex((tr, k) => !S.trash[k] && (mode === 'top' ? Math.hypot(x - tr.x, y - (HY0 + tr.y)) < 32 : Math.abs(x - tr.x) < 36 && y > 330 && y < 440));
      if (i >= 0) { this.cmd('house', 1, TRASH[i].x, mode === 'top' ? TRASH[i].y + 24 : this.ch[S.char].y, () => self.clean(i)); return; }
      // холодильник: перекусить
      if (S.bought.fridge) {
        const fr = FURN.fridge, rr = mode === 'top' ? [fr.tp[0], HY0 + fr.tp[1], fr.tp[2], fr.tp[3]] : [fr.sx, FL - 92, 44, 92];
        if (this.hit(x, y, rr)) {
          this.cmd('house', 1, fr.tp[0] + fr.tp[2] / 2, 66, () => { if (!self.eat(S.char)) { Aud.sfx('no'); toast('В холодильнике пусто: нужны молоко и сыр из амбара'); } });
          return;
        }
      }
    }
    const t = this.walkTarget(x, y, mode); this.walkHere(t[0], t[1]);
  },
  tapYard(x, y, mode) {
    const self = this;
    const houseDoor = [140, mode === 'top' ? 140 : 90, 70, mode === 'top' ? 40 : 80], barnDoor = [495, mode === 'top' ? 140 : 90, 70, mode === 'top' ? 40 : 80];
    if (this.hit(x, y, houseDoor)) { this.cmd('house', 1, 330, 290); return; }
    if (this.hit(x, y, barnDoor)) { this.cmd('barn', 1, 100, 280); return; }
    for (let i = 0; i < CFG.plotsMax; i++) {
      const r = plotRect(i, mode);
      if (!this.hit(x, y, r)) continue;
      if (i < S.plotCount) {
        this.walkHere(r[0] + r[2] / 2, mode === 'top' ? r[1] + r[3] + 8 : this.ch[S.char].y);
        this.plot(i);
      } else if (i === S.plotCount) { Aud.sfx('click'); this.expandModal(EXPAND_COST[(S.plotCount - CFG.plotsStart) / 6] || 9000); }
      else { Aud.sfx('no'); toast('Сначала купи предыдущий ряд'); }
      return;
    }
    const t = this.walkTarget(x, y, mode); this.walkHere(t[0], t[1]);
  },
  tapBarn(x, y, mode) {
    const self = this;
    const door = mode === 'top' ? [36, HY0 + HH - 24, 70, 36] : [36, FL - 80, 66, 94];
    if (this.hit(x, y, door)) { this.cmd('yard', 1, 530, 200); return; }
    for (let k = 0; k < S.cows; k++) {
      const p = stallPos(k, mode), cx = p[0], cy = mode === 'top' ? p[1] : FL - 36;
      if (Math.abs(x - cx) < 50 && Math.abs(y - cy) < (mode === 'top' ? 40 : 46)) {
        this.walkHere(cx, mode === 'top' ? p[1] + 56 - HY0 - 14 : this.ch[S.char].y, () => { Aud.sfx('moo'); S.money += 2; self.burst(cx, cy - 20, 6, '#ff9db1'); self.floats.push({ x: cx, y: cy - 40, t: 0, s: '+$2' }); });
        return;
      }
    }
    const t = this.walkTarget(x, y, mode); this.walkHere(t[0], t[1]);
  },

  /* ----- вопросы Вики ----- */
  startQuiz() {
    if (S.jail > 0) return;
    const act = this.ch[S.char], ask = this.ch[other(S.char)];
    ask.route = []; ask.act = null; ask.bub = null; ask.wait = 0;
    if (ask.place !== act.place || ask.floor !== act.floor) {
      ask.place = act.place; ask.floor = act.floor; ask.hidden = false;
      const b = BOUNDS[act.place]; ask.x = ask.tx = clamp(act.x > 330 ? act.x - 280 : act.x + 280, b.x0, b.x1); ask.y = ask.ty = act.y; Aud.sfx('door');
    }
    this.quizWait = 9; Aud.sfx('swap');
    this.setView(act.place, act.floor);
  },
  randomEvent() {
    const ev = EVENTS[Math.floor(Math.random() * EVENTS.length)];
    say([{ who: ev.who, text: ev.text }], () => { S.money += ev.money; Aud.sfx('coin'); toast('💵 +$' + ev.money); });
  },
  /* Вика замечает странности (клоны Ярика). Смешно, но без последствий. */
  suspect() {
    S.sus++;
    const lines = [
      'Ярик, у нас на огороде сегодня ходил кто-то очень похожий на тебя. Прямо как ты, только зелёный.',
      'Слушай, а почему из пола иногда доносится гудение? И почему Ярик везде одновременно?',
    ];
    say([{ who: 'vika', text: lines[S.sus % 2], choices: [
      { t: 'Показалось. Это эхо.', go: () => say([{ who: 'vika', text: 'Какое эхо? Ладно… Но я за тобой слежу.' }]) },
      { t: 'Это мой двоюродный брат!', go: () => say([{ who: 'vika', text: 'У тебя нет двоюродного брата. Но спорить не буду.' }]) },
    ] }]);
  },
  askQuiz() {
    const self = this, asker = other(S.char), gender = S.char === 'yarik' ? 0 : 1;
    let idx;
    if (!S.qFirst) { S.qFirst = true; idx = 0; } else { if (!S.qBag.length) S.qBag = shuffle(QUESTIONS.map((_, i) => i)); idx = S.qBag.pop(); }
    const reward = Math.round(Math.max(40, income() * CFG.quizReward)), q = QUESTIONS[idx], text = q.q.replace(/\{([^|}]+)\|([^}]+)\}/g, (_, a, b) => gender ? b : a);
    const m = modal('<div class="quiz"><div class="qhead"><div class="portrait"></div><div><b>' + NAMES[asker] + '</b><p></p></div></div><div class="opts"></div><div class="qfoot"></div></div>');
    setPortrait($('.portrait', m), asker); $('.qhead p', m).textContent = text;
    const opts = $('.opts', m), foot = $('.qfoot', m); let answered = false;
    shuffle([q.ok].concat(q.bad)).forEach(o => {
      const b = el('<button class="opt"></button>'); b.textContent = o;
      b.onclick = () => {
        if (answered) return; answered = true; const good = o === q.ok;
        opts.querySelectorAll('.opt').forEach(x => { if (x.textContent === q.ok) x.classList.add('good'); });
        if (!good) b.classList.add('wrong');
        const pool = REACT[asker][good ? 'ok' : 'bad'], line = pool[Math.floor(Math.random() * pool.length)];
        if (good) { S.money += reward; S.hearts++; Aud.sfx('good'); self.burst(480, 270, 18, '#ff7a9a'); }
        else { S.mood = CFG.sulkSeconds; S.sulker = asker; Aud.sfx('bad'); }
        foot.innerHTML = '<span></span><button class="btn small primary">Дальше</button>';
        $('span', foot).textContent = line + (good ? '  (+$' + fmt(reward) + ')' : '');
        $('button', foot).onclick = () => { click(); m.remove(); };
      };
      opts.appendChild(b);
    });
  },

  /* ----- поездки, милиция, тюрьма ----- */
  startTrip(who) { save(); go('road', { who }); },
  sneakModal() {
    const self = this;
    const m = modal('<h2>Поехать тайком?</h2><p>У Вики нет прав, а Ярик ничего не знает. Риск большой: на дороге дежурит милиция.</p><div class="stack"><button class="btn primary" id="y">Всё равно поехать</button><button class="btn" id="n">Передумала</button></div>');
    $('#n', m).onclick = () => { click(); m.remove(); };
    $('#y', m).onclick = () => { m.remove(); self.startTrip('vika'); };
  },
  jailIntro() {
    const self = this;
    say([
      { who: 'yarik', text: 'Звонят из участка… Вику задержали за езду без прав. Две минуты в камере, или залог.' },
      { who: 'yarik', text: 'Залог — десять тысяч долларов. Что делаем?', choices: [
        { t: 'Заплатить залог $' + fmt(CFG.bail), go: () => { if (S.money >= CFG.bail) self.bail(); else { Aud.sfx('no'); toast('Не хватает $' + fmt(CFG.bail - S.money) + ': подождём'); } } },
        { t: 'Подождать, пока выпустят', go: () => toast('Вика выйдет через ' + mmss(S.jail)) },
      ] },
    ]);
  },
  bailModal() {
    const self = this;
    const m = modal('<h2>Залог за Вику</h2><p>Выпустить Вику прямо сейчас за <b>$' + fmt(CFG.bail) + '</b>? Или подождать ещё ' + mmss(S.jail) + '.</p><div class="stack"><button class="btn primary" id="y">Заплатить залог</button><button class="btn" id="n">Подождать</button></div>');
    $('#n', m).onclick = () => { click(); m.remove(); };
    $('#y', m).onclick = () => { if (S.money < CFG.bail) { Aud.sfx('no'); toast('Не хватает $' + fmt(CFG.bail - S.money)); return; } m.remove(); self.bail(); };
  },
  bail() { S.money -= CFG.bail; Aud.sfx('coin'); this.release(true); },
  release(paid) {
    S.jail = 0; const v = this.ch.vika; v.hidden = false; v.place = 'house'; v.floor = 1; v.x = v.tx = 330; v.y = v.ty = 250; v.route = []; v.act = null;
    if (paid) toast('🔓 Вику выпустили по залогу');
    else { S.mood = 20; S.sulker = 'vika'; toast('Вику выпустили. Она обиделась на 20 секунд'); }
    this.renderPanel();
  },

  /* ----- цикл ----- */
  update(dt) {
    this.dtLast = dt;
    const paused = busy();
    if (!paused && !this.sleeping) {
      S.clock += dt;
      if (S.clock >= CFG.nightStart) { this.sleeping = true; save(); go('sleep'); }
      S.money += income() * dt;
      if (S.mood > 0) S.mood = Math.max(0, S.mood - dt);
      if (S.boostT > 0) S.boostT = Math.max(0, S.boostT - dt);
      if (S.jail > 0) { S.jail -= dt; if (S.jail <= 0) this.release(false); }
      ['vika', 'yarik'].forEach(w => { S.food[w] = Math.max(0, S.food[w] - CFG.foodDecay * dt); });
      // коровы
      if (S.cows > 0) {
        this.cowAcc += dt * S.cows / CFG.cowEvery;
        if (this.cowAcc >= 1) {
          this.cowAcc -= 1; S.cowCycle++;
          const cheese = S.cowCycle % 4 === 0; S.prod[cheese ? 'cheese' : 'milk']++;
          if (this.view === 'barn') { const k = Math.floor(Math.random() * S.cows), p = stallPos(k, settings.cam); this.floats.push({ x: p[0], y: settings.cam === 'top' ? p[1] - 30 : FL - 90, t: 0, s: cheese ? '+🧀' : '+🥛' }); }
          if (this.panelTab === 'barn' || this.panelTab === 'shop') this.renderPanel();
        }
      }
      // мега-растения расцветают
      for (let i = 0; i < S.plots.length; i++) {
        if (S.plots[i] === 'mega' && T - (this.pt[i] || -99) >= CFG.megaGrow) {
          S.plots[i] = null; S.boostT = CFG.megaTime; Aud.sfx('boost');
          const cc = this.plotCenter(i); this.burst(cc[0], cc[1], 30, '#b48cff'); this.burst(cc[0], cc[1], 16, '#7be0d1');
          toast('⚡ Мега-бонус! +30% ко всем растениям на ' + CFG.megaTime + ' секунд'); this.renderPanel();
        }
      }
      // герои
      const act = this.ch[S.char], ask = this.ch[other(S.char)];
      this.updateCh(act, dt, true);
      if (this.quizWait > 0 && !ask.hidden) {
        this.quizWait -= dt;
        const b = BOUNDS[act.place], tx = clamp(act.x - 56 * act.face, b.x0, b.x1);
        ask.tx = tx; ask.ty = act.y;
        this.moveCh(ask, dt, 330);
        if (Math.abs(ask.x - tx) < 12 || this.quizWait <= 0) { this.quizWait = 0; this.askQuiz(); }
      } else {
        this.quizWait = 0;
        this.updateCh(ask, dt, false);
        // голодный активный герой перекусывает сам
        if (S.food[S.char] < CFG.hungryBelow + 5 && S.prod.milk + S.prod.cheese > 0) this.eat(S.char);
        if (S.jail <= 0) { S.quizT -= dt; if (S.quizT <= 0) { S.quizT = rnd(CFG.quizEvery[0], CFG.quizEvery[1]); this.startQuiz(); } }
        this.evT -= dt;
        if (this.evT <= 0) { this.evT = rnd(60, 100); this.randomEvent(); }
        if (S.clones >= 2 && S.char === 'vika') { this.susT -= dt; if (this.susT <= 0) { this.susT = rnd(300, 480); this.suspect(); } }
      }
    }
    this.fx.forEach(p => { p.l -= dt; p.vy += 420 * dt; p.x += p.vx * dt; p.y += p.vy * dt; });
    this.fx = this.fx.filter(p => p.l > 0);
    this.floats.forEach(f => { f.t += dt; f.y -= 36 * dt; });
    this.floats = this.floats.filter(f => f.t < 1);
    this.afT -= dt; if (this.afT <= 0) { this.afT = 0.25; this.refreshAfford(); }
    this.saveT += dt; if (this.saveT > 5) { this.saveT = 0; save(); }
    this.updateHud();
  },
  draw(g) {
    const t = this.t, mode = settings.cam;
    const camera = camOn(this);
    if (camera) { camStep(this, this.dtLast || 1 / 60); camBegin(g, this); }
    drawWorld(this.view, this.floor, mode, t);
    const vis = [];
    ['vika', 'yarik'].forEach(w => {
      const ch = this.ch[w];
      if (ch.hidden || ch.wait > 0.12 || ch.place !== this.view || (this.view === 'house' && ch.floor !== this.floor)) return;
      vis.push(ch);
    });
    vis.sort((a, b) => a.y - b.y);
    const sp = vis.map(ch => ({ ch, s: chScreen(ch, mode) }));
    sp.forEach(o => {
      const ch = o.ch, bob = ch.walk ? Math.sin(T * 14) : (ch.act === 'gym' ? Math.sin(T * 7) * 0.6 : ch.act === 'yoga' ? 0 : 0);
      Art.person(g, ch.who, o.s.x, o.s.y, o.s.h, ch.face, bob);
    });
    this.fx.forEach(p => { g.globalAlpha = clamp(p.l * 1.6, 0, 1); g.fillStyle = p.col; g.fillRect(p.x, p.y, 5, 5); });
    g.globalAlpha = 1;
    if (camera) g.restore();
    // освещение суток и звёзды
    Day.apply(g, S.clock);
    if (this.view !== 'barn' && !(this.view === 'house' && this.floor === 0) && mode === 'side') Day.stars(g, S.clock, this.view === 'yard' ? 120 : 330);
    // пузыри над головами, плавающий текст
    if (camera) camBegin(g, this);
    sp.forEach(o => {
      const ch = o.ch;
      if (ch.bub) { g.font = '28px ' + EMOJI_FONT; g.textAlign = 'center'; g.fillStyle = '#000'; g.fillText(ch.bub, o.s.x, o.s.y - o.s.h - 6 - Math.sin(T * 5) * 2); }
      else if (this.quizWait > 0 && ch.who === other(S.char)) { g.font = '30px ' + EMOJI_FONT; g.textAlign = 'center'; g.fillStyle = '#000'; g.fillText('💬', o.s.x, o.s.y - o.s.h - 6); }
    });
    g.font = 'bold 20px sans-serif'; g.textAlign = 'center'; g.lineWidth = 4; g.strokeStyle = 'rgba(20,20,30,.8)';
    this.floats.forEach(f => { g.globalAlpha = clamp(1.4 - f.t * 1.4, 0, 1); g.strokeText(f.s, f.x, f.y); g.fillStyle = '#ffd98a'; g.fillText(f.s, f.x, f.y); });
    g.globalAlpha = 1;
    if (camera) g.restore();
    if (this.view === 'house' && this.floor === 1 && trashLeft() === S.trash.length && this.t < 40) {
      g.textAlign = 'center'; g.font = 'bold 17px sans-serif'; g.fillStyle = '#fff6e6'; g.fillText('Нажимай на мусор, чтобы убрать', 330, 110 + Math.sin(T * 4) * 4);
    }
  },
};
