'use strict';
/* Выезды из дома и ночь: поездка в супермаркет (мини-игра), магазин, милиция и участок, сон. */

const LANES = [428, 476, 524];       // три полосы дороги (уровень колёс машины)
const ROAD_LEN = 5600;               // длина пути до супермаркета, px
const CAR_X = 230;

/* ============================================================ ПОЕЗДКА */
SCENES.road = {
  enter(arg) {
    this.who = (arg && arg.who) || 'yarik';
    this.lane = 1; this.laneY = LANES[1]; this.dist = 0; this.spd = 0; this.gone = false;
    this.hits = 0; this.inv = 0; this.coins = 0; this.shake = 0; this.cop = null; this.stopT = 0; this.arriving = false;
    this.obs = [];
    let x = 700, id = 0;
    while (x < ROAD_LEN - 500) {
      const lane = Math.floor(Math.random() * 3), r = Math.random();
      const o = { wx: x, lane, type: r < 0.38 ? 'cone' : r < 0.62 ? 'cow' : r < 0.82 ? 'car' : 'rock', vx: 0, id: id++, hit: false };
      if (o.type === 'car') o.vx = 170; if (o.type === 'cow') o.vx = 55;
      this.obs.push(o);
      if (Math.random() < 0.55) {     // монетка на другой полосе
        const l2 = (lane + 1 + Math.floor(Math.random() * 2)) % 3;
        this.obs.push({ wx: x + rnd(-120, 120), lane: l2, type: 'coin', vx: 0, id: id++, hit: false });
      }
      x += rnd(380, 560);
    }
    this.cap = el('<div class="caption"></div>'); ui.appendChild(this.cap);
    this.say(this.who === 'yarik' ? 'Ярик едет за покупками' : 'Вика украдкой едет в магазин…');
    const sk = el('<button class="skip hit">Пропустить</button>'); sk.onclick = () => this.skip(); ui.appendChild(sk);
    this.hud = el('<div class="roadhud"><div class="rbar"><i></i><b>🏪</b></div><div class="rinfo"><span id="r-h">Ремонт: 0</span><span id="r-c">Монеты: 0</span></div></div>');
    ui.appendChild(this.hud);
    ui.appendChild(el('<div class="rhint">Нажми выше или ниже машины, чтобы сменить полосу</div>'));
    this.bar = $('.rbar i', this.hud);
    Aud.sfx('swap');
  },
  say(t) { this.cap.classList.remove('in'); void this.cap.offsetWidth; this.cap.textContent = t; this.cap.classList.add('in'); },
  back() { this.skip(); },
  skip() {
    if (this.gone) return; this.gone = true;
    if (this.who === 'vika') go('cop'); else go('market');
  },
  pointer(x, y) {
    if (this.arriving || this.stopT > 0) return;
    if (y < this.laneY - 30) this.lane = Math.max(0, this.lane - 1);
    else if (y > this.laneY + 6) this.lane = Math.min(2, this.lane + 1);
    Aud.sfx('click');
  },
  update(dt) {
    if (this.gone) return;
    const base = 250 + Math.min(80, this.dist / 60);
    if (this.stopT > 0) {
      this.spd = Math.max(0, this.spd - 420 * dt); this.stopT -= dt;
      if (this.stopT <= 0) { this.gone = true; go('cop'); return; }
    } else if (this.arriving) {
      this.spd = Math.max(0, this.spd - 160 * dt);
      if (this.spd <= 0 && !this.gone) { this.gone = true; go('market'); return; }
    } else this.spd = lerp(this.spd, base * (this.inv > 0 ? 0.55 : 1), Math.min(1, dt * 3));
    this.dist += this.spd * dt;
    this.laneY = lerp(this.laneY, LANES[this.lane], Math.min(1, dt * 11));
    if (this.inv > 0) this.inv -= dt;
    if (this.shake > 0) this.shake -= dt;
    // милиция гонится за Викой в любом случае
    if (this.who === 'vika') {
      if (!this.cop && this.dist > 2200) { this.cop = { x: -320, mode: 'chase' }; this.say('Сзади сирена!'); Aud.sfx('siren'); }
      if (this.cop) {
        if (this.cop.mode === 'chase') { this.cop.x += (this.spd + 330) * dt; if (this.cop.x > CAR_X + 330) { this.cop.mode = 'block'; this.stopT = 1.6; this.say('Остановитесь! Милиция!'); Aud.sfx('siren'); } }
        else this.cop.x = Math.min(this.cop.x + 60 * dt, CAR_X + 340);
      }
    }
    // препятствия
    if (!this.stopT && !this.arriving) {
      this.obs.forEach(o => {
        o.wx -= o.vx * dt;
        const sx = CAR_X + (o.wx - this.dist);
        if (o.hit || o.lane !== this.lane || Math.abs(sx - CAR_X) > (o.type === 'coin' ? 60 : 92)) return;
        if (o.type === 'coin') { o.hit = true; this.coins++; S.money += 25; Aud.sfx('coin'); return; }
        if (this.inv <= 0) { o.hit = true; this.hits++; this.inv = 1.4; this.shake = 0.4; const fine = Math.min(S.money, 40); S.money -= fine; Aud.sfx(o.type === 'cow' ? 'moo' : 'crash'); }
      });
    }
    if (this.dist >= ROAD_LEN && this.who === 'yarik' && !this.arriving) { this.arriving = true; this.say('Супермаркет!'); }
    if (this.who === 'vika' && !this.cop && this.dist >= ROAD_LEN - 200) { this.cop = { x: -320, mode: 'chase' }; }
    this.bar.style.width = clamp(this.dist / ROAD_LEN, 0, 1) * 100 + '%';
    $('#r-h').textContent = 'Ремонт: ' + this.hits + ' (−$' + (this.hits * 40) + ')';
    $('#r-c').textContent = 'Монеты: ' + this.coins + ' (+$' + (this.coins * 25) + ')';
  },
  draw(c) {
    const t = this.t, o = this.dist;
    c.save();
    if (this.shake > 0) c.translate(rnd(-4, 4), rnd(-3, 3));
    Art.grad(c, 0, 540, [[0, '#78b4d8'], [0.5, '#f4d7a6'], [1, '#fbe9c6']]);
    Day.sun(c, S ? S.clock : 300, 330, 220);
    Art.clouds(c, t);
    Art.hills(c, 300, 24, '#9fb98f', 0.5, o * 0.05);
    Art.hills(c, 345, 20, '#6f9d72', 2, o * 0.1);
    Art.pineRow(c, o * 0.25, 360, 1.1, '#3c6b52', '#467a5c', 80);
    Art.pineRow(c, o * 0.5, 378, 1.6, '#2c5a45', '#356a50', 110);
    c.fillStyle = '#5e9a5a'; c.fillRect(0, 380, 960, 20);
    c.fillStyle = '#3a3a44'; c.fillRect(0, 396, 960, 144);
    c.fillStyle = '#d8d2c0'; c.fillRect(0, 398, 960, 4);
    c.fillStyle = '#d8d2c0'; c.fillRect(0, 534, 960, 6);
    c.fillStyle = '#f2e2a0';
    for (let k = 1; k <= 2; k++) { const y = 452 + (k - 1) * 48; for (let x = -((o * 1.0) % 90); x < 960; x += 90) c.fillRect(x, y, 48, 5); }
    // дорожный указатель с расстоянием
    const left = Math.max(0, ROAD_LEN - o);
    // супермаркет у дороги
    const mx = CAR_X + 420 + (ROAD_LEN - o);
    if (mx < 1300) { Art.supermarket(c, mx, 396, 300, 150); }
    // препятствия (по полосам, дальние рисуем раньше)
    const list = this.obs.filter(q => !q.hit || q.type === 'coin' && false).filter(q => { const sx = CAR_X + (q.wx - o); return sx > -140 && sx < 1100; });
    const all = list.concat(this.cop ? [{ cop: 1, lane: 1 }] : []);
    for (let L = 0; L < 3; L++) {
      list.filter(q => q.lane === L).forEach(q => this.drawObs(c, q, CAR_X + (q.wx - o), LANES[L], t));
      if (L === this.lane) this.drawCar(c, t);
    }
    if (this.cop) Art.policeCar(c, this.cop.x, this.cop.mode === 'chase' ? LANES[1] : LANES[this.lane] + 6, t, true);
    if (this.cop && this.cop.mode === 'block' && this.stopT > 0) { c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ff6b6b'; c.fillText('СТОП!', CAR_X + 340, 330); }
    c.restore();
    if (S) Day.apply(c, S.clock);
  },
  drawCar(c, t) {
    c.save(); c.translate(CAR_X, this.laneY); c.scale(0.88, 0.88);
    if (this.inv > 0 && Math.floor(t * 12) % 2) c.globalAlpha = 0.45;
    Art.car(c, 0, 0, this.dist * 0.07, this.spd > 5 ? 1 : 0, t, this.who);
    c.restore();
  },
  drawObs(c, q, x, y, t) {
    c.save(); c.translate(x, y);
    if (q.type === 'cone') {
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(0, 2, 22, 5, 0, 0, 7); c.fill();
      c.fillStyle = '#f08a2b'; c.beginPath(); c.moveTo(-18, 0); c.lineTo(-6, -46); c.lineTo(6, -46); c.lineTo(18, 0); c.closePath(); c.fill();
      c.fillStyle = '#fff'; c.fillRect(-12, -24, 24, 7); c.fillStyle = '#d9731a'; c.fillRect(-22, -2, 44, 6);
    } else if (q.type === 'rock') {
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(0, 2, 34, 6, 0, 0, 7); c.fill();
      c.fillStyle = '#8b8d94'; c.beginPath(); c.moveTo(-34, 0); c.lineTo(-26, -30); c.lineTo(-6, -44); c.lineTo(20, -34); c.lineTo(34, 0); c.closePath(); c.fill();
      c.fillStyle = '#a8aab2'; c.beginPath(); c.moveTo(-20, -28); c.lineTo(-6, -40); c.lineTo(8, -30); c.lineTo(-6, -22); c.closePath(); c.fill();
    } else if (q.type === 'cow') {
      Art.cow(c, 0, 0, 1.0, -1, t, 'side', q.id);
    } else if (q.type === 'car') {
      c.scale(-0.8, 0.8); c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 2, 100, 8, 0, 0, 7); c.fill();
      Art.wheel(c, -62, -16, t * 14); Art.wheel(c, 64, -16, t * 14);
      const col = ['#4aa3df', '#8f5ad9', '#3fae7a'][q.id % 3];
      c.fillStyle = col; Art.rr(c, -100, -54, 200, 38, 12); c.fill();
      c.beginPath(); c.moveTo(-70, -54); c.lineTo(-52, -88); c.lineTo(46, -88); c.lineTo(76, -54); c.closePath(); c.fill();
      c.fillStyle = '#bfe6f2'; c.fillRect(-46, -83, 86, 26);
      c.fillStyle = '#ffe9a6'; c.fillRect(92, -48, 7, 9);
    } else if (q.type === 'coin') {
      const b = Math.sin(t * 6 + q.id) * 4;
      c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.ellipse(0, 2, 16, 4, 0, 0, 7); c.fill();
      c.fillStyle = '#f2c14e'; c.beginPath(); c.arc(0, -30 + b, 16, 0, 7); c.fill();
      c.strokeStyle = '#b8892a'; c.lineWidth = 3; c.stroke();
      c.fillStyle = '#b8892a'; c.font = 'bold 18px sans-serif'; c.textAlign = 'center'; c.fillText('$', 0, -24 + b);
    }
    c.restore();
  },
};

/* ============================================================ СУПЕРМАРКЕТ */
SCENES.market = {
  enter() {
    this.boughtN = 0; this.out = false;
    const m = el('<div class="shopwin hit"><div class="shead"><b>🛒 Супермаркет</b><span id="s-m"></span></div><p class="sline">Добро пожаловать! Мега-семена сегодня со скидкой… то есть по обычной цене.</p><div class="sgrid" id="s-g"></div><button class="btn small primary" id="s-x">Выехать домой</button></div>');
    ui.appendChild(m); this.win = m;
    $('#s-x', m).onclick = () => { click(); this.leave(); };
    this.paint();
  },
  back() { this.leave(); },
  leave() { if (this.out) return; this.out = true; go('game', { trip: true }); },
  paint() {
    $('#s-m').textContent = '$' + fmt(S.money);
    const g = $('#s-g'); g.innerHTML = '';
    SHOP.forEach(it => {
      const have = it.id === 'mega' ? S.mega : it.id === 'milk' ? S.prod.milk : S.prod.cheese;
      const b = el('<button class="sitem' + (S.money < it.cost ? ' poor' : '') + '"><span class="ic">' + it.icon + '</span><span class="nm">' + it.name + '<small>' + it.desc + '</small><i>есть: ' + have + '</i></span><span class="pr">$' + fmt(it.cost) + '</span></button>');
      b.onclick = () => this.buy(it);
      g.appendChild(b);
    });
  },
  buy(it) {
    if (S.money < it.cost) { Aud.sfx('no'); toast('Не хватает $' + fmt(it.cost - S.money)); return; }
    S.money -= it.cost; Aud.sfx('coin');
    if (it.id === 'mega') S.mega++; else if (it.id === 'milk') S.prod.milk += 3; else S.prod.cheese += 2;
    this.boughtN++; this.paint();
  },
  update() {},
  draw(c) {
    const t = this.t;
    c.fillStyle = '#e9e4d6'; c.fillRect(0, 0, 960, 540);
    c.fillStyle = '#d8d2c0'; c.fillRect(0, 0, 960, 70);
    for (let x = 0; x < 960; x += 80) { c.fillStyle = 'rgba(255,255,255,.5)'; c.fillRect(x + 10, 20, 60, 8); }
    c.fillStyle = '#b5ad98'; c.fillRect(0, 410, 960, 130);
    c.strokeStyle = 'rgba(0,0,0,.08)'; c.lineWidth = 1; for (let x = 0; x < 960; x += 60) { c.beginPath(); c.moveTo(x, 410); c.lineTo(x - 40, 540); c.stroke(); }
    // стеллажи
    for (let k = 0; k < 3; k++) {
      const sx = 40 + k * 110;
      c.fillStyle = '#7e6a52'; c.fillRect(sx, 120, 100, 290);
      for (let r = 0; r < 4; r++) {
        c.fillStyle = '#5c4a38'; c.fillRect(sx, 120 + r * 72, 100, 5);
        for (let i = 0; i < 6; i++) { c.fillStyle = ['#e9748f', '#7fd19a', '#ffd98a', '#8ec5e8', '#c9a0ff', '#ff9e7a'][(i + r + k) % 6]; c.fillRect(sx + 6 + i * 15, 130 + r * 72 + (i % 2) * 5, 12, 42 - (i % 2) * 5); }
      }
    }
    // касса
    c.fillStyle = '#6b7a86'; c.fillRect(380, 360, 150, 50); c.fillStyle = '#2b2b33'; c.fillRect(400, 330, 40, 30);
    c.fillStyle = '#9fd6f0'; c.fillRect(404, 334, 32, 18); c.fillStyle = '#e8e2d2'; c.fillRect(450, 352, 70, 8);
    c.fillStyle = '#3f8f5b'; c.fillRect(0, 70, 960, 28); c.fillStyle = '#fff6e6'; c.font = 'bold 18px sans-serif'; c.textAlign = 'center'; c.fillText('СУПЕРМАРКЕТ · МЕГА-СЕМЕНА · ПРОДУКТЫ', 480, 90);
    Art.person(c, 'yarik', 340, 470, 170, 1, 0);
    // кассирша: пиксельная
    const u = 5; c.save(); c.translate(560, 410);
    const R = (a, b, w, h, col) => { c.fillStyle = col; c.fillRect(a * u, -(b + h) * u, w * u, h * u); };
    R(-4, 0, 8, 16, '#3f8f5b'); R(-4, 16, 8, 8, '#f0c9a0'); R(-5, 22, 10, 4, '#7a3b2c'); R(-2, 19, 1, 1, '#2b2118'); R(1, 19, 1, 1, '#2b2118'); R(-1, 17, 2, 1, '#c25a5a');
    c.restore();
    c.font = 'bold 14px sans-serif'; c.fillStyle = '#3a3a44'; c.fillText('Кассирша', 560, 424);
    if (S) Day.apply(c, Math.min(S.clock, 1100));
  },
};

/* ============================================================ МИЛИЦИЯ */
SCENES.cop = {
  enter() {
    this.out = false; this.ph = 'talk'; this.pt = 0; this.copX = 600; this.vx = 430; this.vFace = 1; this.cell = 0; this.said = false;
    this.cap = el('<div class="caption"></div>'); ui.appendChild(this.cap);
    Aud.sfx('siren');
    setTimeout(() => this.talk(), 900);
  },
  back() {},
  talk() {
    const self = this, C = COP_TALK;
    const final = () => say([
      { who: 'cop', text: C.end1 },
      { who: 'vika', text: C.vika },
    ], () => self.walkOff());
    const round2 = () => say([{ who: 'cop', text: 'Тогда так: у вас есть что сказать в своё оправдание?', choices: [
      { t: 'Я позвоню мужу!', go: () => say([{ who: 'cop', text: 'Звоните. Он как раз сегодня обещал привезти залог.' }], final) },
      { t: 'Это была не я, а мой клон!', go: () => say([{ who: 'cop', text: 'Клонов у нас не регистрируют. Шутка про клонов засчитана как отягчающая.' }], final) },
      { t: 'Давайте я просто заплачу штраф?', go: () => say([{ who: 'cop', text: 'Штраф — это хорошая идея. Но сначала камера, потом штраф.' }], final) },
    ] }]);
    say([{ who: 'cop', text: C.start, choices: C.choices.map(ch => ({ t: ch.t, go: () => say([{ who: 'cop', text: ch.cop }], round2) })) }]);
  },
  walkOff() { this.ph = 'walk'; this.pt = 0; this.cap.textContent = 'Вику ведут в участок'; this.cap.classList.add('in'); Aud.sfx('siren'); },
  update(dt) {
    this.pt += dt;
    if (this.ph === 'walk') {
      this.copX = Math.min(this.copX + 90 * dt, 800); this.vx = Math.min(this.vx + 90 * dt, 700);
      if (this.pt > 4.2) { this.ph = 'cell'; this.pt = 0; S.jail = CFG.jailSeconds; this.cap.textContent = ''; save(); }
    } else if (this.ph === 'cell') {
      if (this.pt > 1.5 && this.cell === 0) { this.cell = 1; Aud.sfx('clank'); }
      if (this.pt > 6.4 && !this.out) { this.out = true; go('game', { jailed: true }); }
    }
  },
  draw(c) {
    const t = this.t;
    if (this.ph === 'cell') { this.drawCell(c, t); return; }
    Art.grad(c, 0, 540, [[0, '#78b4d8'], [0.5, '#f4d7a6'], [1, '#fbe9c6']]);
    c.save(); c.translate(0, -190);       // сцена приподнята, чтобы диалог не закрывал героев
    Day.sun(c, S ? S.clock : 300, 330, 220);
    Art.clouds(c, t);
    Art.hills(c, 300, 24, '#9fb98f', 0.5, 0);
    Art.hills(c, 345, 20, '#6f9d72', 2, 0);
    Art.pineRow(c, 0, 372, 1.1, '#3c6b52', '#467a5c', 80);
    c.fillStyle = '#5e9a5a'; c.fillRect(0, 390, 960, 20);
    c.fillStyle = '#3a3a44'; c.fillRect(0, 410, 960, 420);
    c.fillStyle = '#d8d2c0'; c.fillRect(0, 412, 960, 4);
    Art.station(c, 830, 410, 250, 150, Math.sin(t * 8) > 0);
    c.save(); c.translate(180, 520); c.scale(0.9, 0.9); Art.car(c, 0, 0, 0, 0, t, false); c.restore();
    Art.policeCar(c, 430, 500, t, true);
    const vx = this.ph === 'walk' ? this.vx : 640, cx = this.ph === 'walk' ? this.copX : 700;
    Art.person(c, 'vika', vx, 500, 170, 1, this.ph === 'walk' ? Math.sin(t * 12) : 0);
    Art.person(c, 'cop', cx, 510, 200, 1, this.ph === 'walk' ? Math.sin(t * 12) : 0);
    if (this.ph === 'walk') { c.strokeStyle = '#c9c9d4'; c.lineWidth = 3; c.beginPath(); c.moveTo(vx + 14, 440); c.lineTo(cx - 14, 440); c.stroke(); }
    c.restore();
    if (S) Day.apply(c, S.clock);
  },
  drawCell(c, t) {
    c.fillStyle = '#4a4e57'; c.fillRect(0, 0, 960, 540);
    c.fillStyle = 'rgba(0,0,0,.14)'; for (let y = 20; y < 540; y += 40) c.fillRect(0, y, 960, 3);
    c.fillStyle = '#2f333a'; c.fillRect(0, 430, 960, 110);
    c.fillStyle = '#7a8088'; c.fillRect(100, 130, 80, 110);   // окно
    c.fillStyle = '#a5c8e4'; c.fillRect(106, 136, 68, 98);
    c.fillStyle = '#35393f'; for (let k = 0; k < 4; k++) c.fillRect(116 + k * 14, 136, 5, 98);
    // койка
    c.fillStyle = '#6b5a4a'; c.fillRect(600, 390, 200, 40); c.fillStyle = '#9a9a9a'; c.fillRect(610, 378, 180, 14);
    c.fillStyle = '#e9e2d6'; c.fillRect(740, 372, 50, 12);
    Art.person(c, 'vika', 440, 460, 190, -1, 0);
    // решётка: опускается и запирается
    const drop = clamp(this.cell ? (this.pt - 1.5) / 0.5 : 0, 0, 1), top = lerp(-420, 0, 1 - Math.pow(1 - drop, 2));
    c.fillStyle = '#17191d'; c.fillRect(0, top - 6, 960, 12);
    for (let x = 30; x < 960; x += 62) { c.fillStyle = '#b5b9c2'; c.fillRect(x, top, 10, 430 + 8); c.fillStyle = 'rgba(255,255,255,.4)'; c.fillRect(x + 2, top, 2, 438); }
    c.fillStyle = '#17191d'; c.fillRect(0, top + 120, 960, 8); c.fillRect(0, top + 320, 960, 8);
    if (drop >= 1) { c.font = '34px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🔒', 480, 280); }
    const s = Math.max(0, Math.ceil(S.jail));
    c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fff6e6'; c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = 5;
    c.strokeText('Вика сидит в участке · ' + mmss(s), 480, 70); c.fillText('Вика сидит в участке · ' + mmss(s), 480, 70);
    const f = clamp((this.pt - 5.3) / 1, 0, 1); if (f > 0) { c.fillStyle = 'rgba(0,0,0,' + f + ')'; c.fillRect(0, 0, 960, 540); }
  },
};

/* ============================================================ НОЧЬ И СНЫ */
SCENES.sleep = {
  enter() {
    this.ph = 'walk'; this.pt = 0; this.dt = 0; this.out = false; this.zs = [];
    this.dr = { yarik: shuffle(DREAMS.yarik.map((_, i) => i)), vika: shuffle(DREAMS.vika.map((_, i) => i)) };
    this.cap = el('<div class="caption night"></div>'); ui.appendChild(this.cap);
    this.sk = el('<button class="skip hit">Пропустить сон</button>'); this.sk.onclick = () => this.wake(); ui.appendChild(this.sk);
    this.setCap('Наступила ночь. Пора спать.');
    Aud.sfx('sleep');
  },
  setCap(t) { this.cap.classList.remove('in'); void this.cap.offsetWidth; this.cap.textContent = t; this.cap.classList.add('in'); },
  back() { this.wake(); },
  wake() {
    if (this.out) return; this.out = true;
    const gain = Math.round(income() * 60 * CFG.sleepIncome);
    S.money += gain; S.clock = 110; S.day++;
    ['vika', 'yarik'].forEach(w => { S.food[w] = Math.max(S.food[w] - 10, 0); });
    save();
    go('game', { morning: true, sleepGain: gain });
    setTimeout(() => { if (gain > 0) toast('🌙 Пока вы спали: +$' + fmt(gain)); }, 900);
  },
  update(dt) {
    this.pt += dt;
    if (this.ph === 'walk' && this.pt > 6.5) { this.ph = 'dream'; this.pt = 0; this.setCap(''); this.cap.classList.remove('in'); }
    if (this.ph === 'dream') {
      this.dt = this.pt;
      if (Math.random() < dt * 1.4) this.zs.push({ x: 440 + rnd(-40, 40), y: 360, a: 1, s: rnd(14, 24) });
      if (this.pt >= 60) this.wake();
    }
    this.zs.forEach(z => { z.y -= 28 * dt; z.x += Math.sin(z.y * 0.05) * 0.4; z.a -= 0.3 * dt; });
    this.zs = this.zs.filter(z => z.a > 0);
  },
  room(c, t) {
    c.fillStyle = '#1c2038'; c.fillRect(0, 0, 960, 540);
    c.fillStyle = '#2b3052'; c.fillRect(60, 60, 840, 380);
    for (let x = 60; x < 900; x += 36) { c.fillStyle = 'rgba(255,255,255,.04)'; c.fillRect(x, 60, 16, 380); }
    c.fillStyle = '#2a1d1a'; c.fillRect(30, 440, 900, 60);
    // окно с луной
    c.fillStyle = '#fdf6e6'; c.fillRect(110, 110, 150, 130); c.fillStyle = '#10163a'; c.fillRect(118, 118, 134, 114);
    c.fillStyle = '#f2f4ff'; Art.circle(c, 190, 160, 22); c.fillStyle = '#10163a'; Art.circle(c, 200, 154, 19);
    for (let i = 0; i < 9; i++) { c.fillStyle = 'rgba(255,255,230,' + (0.5 + 0.5 * Math.sin(t * 2 + i)).toFixed(2) + ')'; c.fillRect(124 + (i * 37) % 120, 124 + (i * 23) % 100, 2, 2); }
    c.fillStyle = '#fdf6e6'; c.fillRect(181, 118, 4, 114); c.fillRect(118, 172, 134, 4);
    // лампа
    c.fillStyle = '#6b4a32'; c.fillRect(700, 380, 60, 60); c.fillStyle = '#ffd98a'; c.fillRect(722, 340, 16, 40); c.fillStyle = '#e9748f'; c.beginPath(); c.moveTo(706, 346); c.lineTo(754, 346); c.lineTo(742, 322); c.lineTo(718, 322); c.closePath(); c.fill();
    const lamp = this.ph === 'walk' && this.pt < 5;
    if (lamp) { c.fillStyle = 'rgba(255,217,138,.18)'; Art.circle(c, 730, 350, 130); }
    // кровать
    c.fillStyle = '#6b4a32'; c.fillRect(300, 370, 360, 70); c.fillRect(290, 330, 16, 110); c.fillRect(654, 350, 16, 90);
    c.fillStyle = '#e9e2d6'; c.fillRect(310, 356, 340, 22);
  },
  draw(c) {
    const t = this.t; this.room(c, t);
    if (this.ph === 'walk') {
      const p = clamp(this.pt / 4.6, 0, 1), e = p * p * (3 - 2 * p), x = lerp(120, 480, e);
      const lying = this.pt > 4.8;
      if (!lying) {
        const bob = Math.abs(Math.sin(t * 9)) * (p < 1 ? 1 : 0);
        Art.person(c, 'yarik', x + 46, 440, 190, 1, bob); Art.person(c, 'vika', x - 36, 440, 182, 1, bob);
        c.strokeStyle = '#ffd0d8'; c.lineWidth = 4; c.beginPath(); c.moveTo(x + 4, 358); c.lineTo(x + 18, 360); c.stroke();
        c.font = '22px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('❤', x + 11, 340 - Math.sin(t * 4) * 4);
      } else this.drawSleepers(c, t, clamp((this.pt - 4.8) / 0.8, 0, 1));
      if (this.pt > 5.4) { c.fillStyle = 'rgba(8,10,24,' + clamp((this.pt - 5.4) / 1.1, 0, 0.9).toFixed(2) + ')'; c.fillRect(0, 0, 960, 540); }
    } else {
      this.drawSleepers(c, t, 1);
      c.fillStyle = 'rgba(8,10,24,.9)'; c.fillRect(0, 0, 960, 540);
      this.drawDreams(c, t);
    }
    this.zs.forEach(z => { c.globalAlpha = clamp(z.a, 0, 1); c.font = 'bold ' + z.s + 'px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#cfd6ff'; c.fillText('z', z.x, z.y); });
    c.globalAlpha = 1;
  },
  drawSleepers(c, t, k) {
    c.save(); c.globalAlpha = k;
    Art.head(c, 'vika', 372, 352, 46); Art.head(c, 'yarik', 538, 352, 46);
    c.fillStyle = '#e9748f'; Art.rr(c, 318, 358, 330, 40, 12); c.fill();
    c.fillStyle = 'rgba(255,255,255,.18)'; c.fillRect(326, 364, 316, 6);
    c.fillStyle = '#fff'; Art.rr(c, 338, 336, 56, 22, 10); c.fill(); Art.rr(c, 512, 336, 56, 22, 10); c.fill();
    Art.head(c, 'vika', 366, 342, 44); Art.head(c, 'yarik', 540, 342, 44);
    c.restore();
  },
  drawDreams(c, t) {
    const idx = Math.min(5, Math.floor(this.dt / 10)), frac = (this.dt % 10) / 10;
    const fade = clamp(Math.min(frac * 6, (1 - frac) * 6), 0, 1);
    const panel = (who, cx, title) => {
      const d = DREAMS[who][this.dr[who][idx % 6]];
      c.save(); c.globalAlpha = fade;
      c.fillStyle = 'rgba(40,46,92,.85)'; Art.rr(c, cx - 210, 40, 420, 250, 30); c.fill();
      c.strokeStyle = 'rgba(180,190,255,.35)'; c.lineWidth = 3; Art.rr(c, cx - 210, 40, 420, 250, 30); c.stroke();
      c.fillStyle = 'rgba(40,46,92,.85)'; Art.circle(c, cx + (who === 'yarik' ? 120 : -120), 318, 12); Art.circle(c, cx + (who === 'yarik' ? 140 : -140), 344, 7);
      c.font = 'bold 16px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd98a'; c.fillText('Сон ' + (who === 'vika' ? 'Вики' : 'Ярика'), cx, 70);
      d.e.forEach((e, i) => { const yy = 150 + Math.sin(t * 2 + i * 1.3) * 10; c.font = '64px ' + EMOJI_FONT; c.fillStyle = '#000'; c.fillText(e, cx - 105 + i * 105, yy + (i === 1 ? -10 : 8)); });
      c.font = '16px sans-serif'; c.fillStyle = '#e6e9ff';
      // перенос текста
      const words = d.t.split(' '); let line = '', y = 228; words.forEach(w => { const test = line + w + ' '; if (c.measureText(test).width > 380) { c.fillText(line.trim(), cx, y); line = w + ' '; y += 22; } else line = test; }); c.fillText(line.trim(), cx, y);
      c.restore();
    };
    panel('yarik', 250, 'Ярик'); panel('vika', 710, 'Вика');
    // таймер
    c.font = 'bold 20px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#cfd6ff'; c.fillText('Утро через ' + Math.max(0, Math.ceil(60 - this.dt)) + ' с', 480, 500);
    c.fillStyle = 'rgba(255,255,255,.15)'; c.fillRect(280, 510, 400, 6); c.fillStyle = '#ffd98a'; c.fillRect(280, 510, 400 * clamp(this.dt / 60, 0, 1), 6);
  },
};
