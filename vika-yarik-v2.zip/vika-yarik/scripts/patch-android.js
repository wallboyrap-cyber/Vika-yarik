// Запускается после `npx cap add android`: включает горизонтальную ориентацию.
const fs = require('fs');
const p = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(p)) { console.error('Нет ' + p + ' — сначала выполни: npx cap add android'); process.exit(1); }
let s = fs.readFileSync(p, 'utf8');
if (s.includes('screenOrientation')) { console.log('Ориентация уже настроена'); process.exit(0); }
s = s.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
fs.writeFileSync(p, s);
console.log('Готово: игра будет запускаться в горизонтальной ориентации');
