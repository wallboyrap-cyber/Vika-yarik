'use strict';
/* Отрисовка: спрайты Вики и Ярика (из assets), дядя Феликс, машина, декорации. */
const Art = (() => {
  const IMG = {};
  const SRC = { vika: 'assets/vika.png', yarik: 'assets/yarik.png', cop: 'assets/cop.png', vika_face: 'assets/vika_face.png', yarik_face: 'assets/yarik_face.png', cop_face: 'assets/cop_face.png' };
  const TAU = Math.PI * 2;

  function load() {
    return Promise.all(Object.keys(SRC).map(k => new Promise(res => {
      const im = new Image();
      im.onload = () => { IMG[k] = im; res(); };
      im.onerror = () => res();
      im.src = SRC[k];
    })));
  }

  function grad(c, y0, y1, stops) {
    const g = c.createLinearGradient(0, y0, 0, y1);
    stops.forEach(s => g.addColorStop(s[0], s[1]));
    c.fillStyle = g;
    c.fillRect(0, y0, 960, y1 - y0);
  }
  function circle(c, x, y, r) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
  function rr(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }

  /* Область спрайта, где реально нарисован человек (у полицейского вокруг фигуры прозрачные поля). Сам PNG не менялся. */
  const BOX = { cop: [186, 1, 670, 1532] };
  /* Человек стоит ногами в точке (x, y), высота h. face: 1 вправо, -1 влево. */
  function person(c, who, x, y, h, face, bob, filt) {
    const im = IMG[who]; if (!im) return;
    face = face || 1; bob = bob || 0;
    const b = BOX[who] || [0, 0, im.width, im.height];
    const w = b[2] / b[3] * h;
    c.fillStyle = 'rgba(0,0,0,.25)';
    c.beginPath(); c.ellipse(x, y, w * 0.38, 5, 0, 0, TAU); c.fill();
    c.save(); c.translate(x, y - Math.abs(bob) * 4); c.scale(face, 1);
    if (filt) c.filter = filt;
    c.drawImage(im, b[0], b[1], b[2], b[3], -w / 2, -h, w, h);
    if (filt) c.filter = 'none';
    c.restore();
  }
  /* Только голова (для окон машины, сна): берётся из готовой иконки лица. */
  function head(c, who, x, y, size) {
    const im = IMG[who + '_face']; if (!im) return;
    c.save(); c.imageSmoothingEnabled = false;
    c.drawImage(im, x - size / 2, y - size / 2, size, size);
    c.restore();
  }

  function hills(c, baseY, amp, col, seed, shift) {
    c.fillStyle = col; c.beginPath(); c.moveTo(0, 540);
    for (let x = 0; x <= 960; x += 20) {
      const y = baseY + Math.sin((x + shift) * 0.008 + seed) * amp + Math.sin((x + shift) * 0.021 + seed * 2) * amp * 0.4;
      c.lineTo(x, y);
    }
    c.lineTo(960, 540); c.closePath(); c.fill();
  }

  function pine(c, x, y, s, c1, c2) {
    c.fillStyle = '#4a3326'; c.fillRect(x - 3 * s, y - 12 * s, 6 * s, 12 * s);
    for (let i = 0; i < 3; i++) {
      c.fillStyle = i % 2 ? c1 : c2;
      const base = y - (10 + i * 16) * s, w = (42 - i * 9) * s;
      c.beginPath(); c.moveTo(x, base - 34 * s); c.lineTo(x - w / 2, base); c.lineTo(x + w / 2, base); c.closePath(); c.fill();
    }
  }
  function pineRow(c, off, baseY, s, c1, c2, gap) {
    const n = Math.ceil(1100 / gap), total = gap * n;
    for (let i = 0; i < n; i++) {
      const x = (((i * gap - off) % total) + total) % total - 60;
      pine(c, x, baseY + ((i * 7) % 3) * 4, s * (0.9 + ((i * 13) % 5) * 0.05), c1, c2);
    }
  }

  function stars(c, t) {
    for (let i = 0; i < 70; i++) {
      const x = (i * 83) % 960, y = (i * 47) % 260, a = 0.4 + 0.6 * Math.abs(Math.sin(t * 1.3 + i));
      c.fillStyle = 'rgba(255,255,230,' + (a * 0.8).toFixed(2) + ')'; c.fillRect(x, y, 2, 2);
    }
  }
  function fireflies(c, t, n) {
    for (let i = 0; i < n; i++) {
      const x = (i * 137.5) % 960 + Math.sin(t * 0.5 + i) * 22;
      const y = 250 + (i * 61) % 230 + Math.cos(t * 0.7 + i * 2) * 16;
      const a = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.6 + i * 1.7));
      c.fillStyle = 'rgba(255,230,140,' + (a * 0.25).toFixed(2) + ')'; circle(c, x, y, 7);
      c.fillStyle = 'rgba(255,240,170,' + a.toFixed(2) + ')'; circle(c, x, y, 2);
    }
  }
  function clouds(c, t) {
    c.fillStyle = 'rgba(255,255,255,.8)';
    for (let i = 0; i < 5; i++) {
      const x = ((i * 230 + t * 8) % 1200) - 120, y = 50 + (i * 37) % 90;
      circle(c, x, y, 20); circle(c, x + 24, y - 8, 26); circle(c, x + 52, y, 20); c.fillRect(x, y, 52, 20);
    }
  }

  /* ----- Дядя Феликс: пиксельный фермер, нарисован кодом ----- */
  function felix(c, x, y, u) {
    const R = (a, b, w, h, col) => { c.fillStyle = col; c.fillRect(x + a * u, y - (b + h) * u, w * u, h * u); };
    const skin = '#e3b48b', denim = '#3f5f93', plaid = '#b8423c';
    c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(x, y, 7 * u, 1.2 * u, 0, 0, TAU); c.fill();
    R(-5, 0, 4, 2, '#3a2a20'); R(1, 0, 4, 2, '#3a2a20');
    R(-5, 2, 4, 9, denim); R(1, 2, 4, 9, denim);
    R(-9, 11, 3, 10, plaid); R(6, 11, 3, 10, plaid);
    R(-9, 9, 3, 2, skin); R(6, 9, 3, 2, skin);
    R(-6, 11, 12, 10, plaid);
    R(-4, 11, 8, 7, denim);
    R(-5, 18, 2, 3, denim); R(3, 18, 2, 3, denim);
    R(-3, 15, 1, 1, '#f2c14e'); R(2, 15, 1, 1, '#f2c14e');
    R(-7, 14, 1, 7, '#8f2f2b'); R(6, 14, 1, 7, '#8f2f2b');
    R(-4, 21, 8, 8, skin);
    R(-5, 25, 1, 2, skin); R(4, 25, 1, 2, skin);
    R(-4, 21, 8, 3, '#ddd8cc'); R(-2, 24, 4, 1, '#ddd8cc');
    R(-2, 26, 1, 1, '#2b2118'); R(1, 26, 1, 1, '#2b2118');
    R(0, 25, 1, 1, '#c98f69');
    R(-7, 29, 14, 1, '#d9b45a'); R(-4, 30, 8, 4, '#d9b45a'); R(-4, 30, 8, 1, '#8a5a2b');
  }

  /* ----- Машина ----- */
  function wheel(c, x, y, spin) {
    c.save(); c.translate(x, y);
    c.fillStyle = '#1a1a1f'; circle(c, 0, 0, 16);
    c.fillStyle = '#8f949c'; circle(c, 0, 0, 8);
    c.strokeStyle = '#cfd3da'; c.lineWidth = 2; c.rotate(spin);
    for (let i = 0; i < 4; i++) { c.rotate(Math.PI / 2); c.beginPath(); c.moveTo(0, 0); c.lineTo(7, 0); c.stroke(); }
    c.restore();
  }
  function car(c, x, y, spin, bounce, t, people) {
    const b = Math.sin(t * 16) * 1.3 * bounce;
    c.save(); c.translate(x, y);
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 2, 112, 8, 0, 0, TAU); c.fill();
    if (bounce > 0) for (let k = 0; k < 4; k++) {
      c.fillStyle = 'rgba(235,235,235,' + (0.35 - k * 0.08).toFixed(2) + ')';
      circle(c, -114 - k * 16 - ((t * 40) % 16), -16 - k * 4, 5 + k * 2);
    }
    wheel(c, -62, -16, spin); wheel(c, 64, -16, spin);
    c.translate(0, b);
    c.fillStyle = '#d9792f'; rr(c, -108, -58, 216, 40, 12); c.fill();
    c.beginPath(); c.moveTo(-76, -58); c.lineTo(-56, -96); c.lineTo(52, -96); c.lineTo(84, -58); c.closePath(); c.fill();
    c.save(); c.beginPath(); c.rect(-50, -90, 42, 30); c.rect(-2, -90, 48, 30); c.clip();
    c.fillStyle = '#bfe6f2'; c.fillRect(-52, -92, 100, 34);
    if (people === 'vika' || people === 'yarik') head(c, people, 22, -72, 40);
    else if (people !== false) { head(c, 'vika', -28, -72, 40); head(c, 'yarik', 22, -72, 40); }
    c.fillStyle = 'rgba(255,255,255,.16)'; c.fillRect(-52, -92, 100, 9);
    c.restore();
    c.strokeStyle = '#8f4b17'; c.lineWidth = 3; c.strokeRect(-50, -90, 42, 30); c.strokeRect(-2, -90, 48, 30);
    c.fillStyle = '#a85d20'; c.fillRect(-4, -58, 3, 38); c.fillRect(-14, -48, 8, 3);
    c.fillStyle = '#ffe9a6'; c.fillRect(100, -52, 8, 9);
    c.fillStyle = '#d23b3b'; c.fillRect(-108, -52, 6, 9);
    c.fillStyle = '#9aa0a8'; c.fillRect(-112, -26, 10, 6); c.fillRect(102, -26, 10, 6);
    c.fillStyle = 'rgba(110,50,20,.35)'; circle(c, -34, -34, 7); circle(c, 44, -30, 5);
    c.restore();
  }

  /* ----- Старый дом (тот самый) ----- */
  function oldHouse(c, x, y, w, h, o) {
    o = o || {};
    const l = x - w / 2;
    c.fillStyle = o.dark ? '#4b4458' : '#b9a283'; c.fillRect(l, y - h, w, h);
    c.fillStyle = 'rgba(0,0,0,.14)';
    for (let i = 1; i < 8; i++) c.fillRect(l, y - h + i * (h / 8), w, 2);
    c.fillStyle = o.dark ? '#2a2236' : '#6e4a46';
    c.beginPath(); c.moveTo(l - 14, y - h + 6); c.lineTo(x, y - h - h * 0.5); c.lineTo(l + w + 14, y - h + 6); c.closePath(); c.fill();
    c.fillStyle = o.dark ? '#1c1626' : '#43302e';
    c.beginPath(); c.moveTo(x - 30, y - h - 4); c.lineTo(x - 8, y - h - 22); c.lineTo(x + 6, y - h - 2); c.closePath(); c.fill();
    c.fillStyle = o.dark ? '#352b45' : '#7a4b3a'; c.fillRect(l + w * 0.72, y - h - h * 0.42, 22, h * 0.34);
    c.fillStyle = '#4a2f22'; c.fillRect(x - 15, y - h * 0.5, 30, h * 0.5);
    c.fillStyle = '#d9b45a'; circle(c, x + 8, y - h * 0.24, 2);
    [l + w * 0.12, l + w * 0.68].forEach((wx, i) => {
      const wy = y - h * 0.78, ww = w * 0.2, wh = h * 0.24;
      c.fillStyle = o.lit && i === 1 ? '#ffd98a' : '#2a2f3a'; c.fillRect(wx, wy, ww, wh);
      c.strokeStyle = '#e8ddc8'; c.lineWidth = 3; c.strokeRect(wx, wy, ww, wh);
      c.beginPath(); c.moveTo(wx + ww / 2, wy); c.lineTo(wx + ww / 2, wy + wh); c.moveTo(wx, wy + wh / 2); c.lineTo(wx + ww, wy + wh / 2); c.stroke();
    });
    c.fillStyle = '#4f8a4a';
    for (let i = 0; i < 9; i++) { const gx = l + 6 + i * (w / 8.5); c.fillRect(gx, y - 8 - (i % 3) * 3, 3, 8 + (i % 3) * 3); }
    if (o.lit) { c.fillStyle = 'rgba(255,217,138,.12)'; circle(c, l + w * 0.78, y - h * 0.66, 70); }
  }


  /* ----- Корова: mode 'side' (сбоку) или 'top' (сверху) ----- */
  function cow(c, x, y, s, face, t, mode, k) {
    face = face || 1; k = k || 0;
    c.save(); c.translate(x, y); c.scale(s, s);
    if (mode === 'top') {
      c.fillStyle = 'rgba(0,0,0,.22)'; c.beginPath(); c.ellipse(2, 4, 34, 18, 0, 0, TAU); c.fill();
      c.fillStyle = '#f4f1ea'; c.beginPath(); c.ellipse(0, 0, 32, 17, 0, 0, TAU); c.fill();
      c.fillStyle = '#3b3b44'; c.beginPath(); c.ellipse(-10, -4, 9, 6, 0.4, 0, TAU); c.fill(); c.beginPath(); c.ellipse(8, 6, 8, 5, 0, 0, TAU); c.fill();
      c.fillStyle = '#f4f1ea'; c.beginPath(); c.ellipse(34 * face, -1, 12, 10, 0, 0, TAU); c.fill();
      c.fillStyle = '#e8a6a6'; c.beginPath(); c.ellipse(41 * face, -1, 5, 6, 0, 0, TAU); c.fill();
      c.fillStyle = '#3b3b44'; c.beginPath(); c.arc(31 * face, -8, 2.5, 0, TAU); c.fill(); c.beginPath(); c.arc(31 * face, 6, 2.5, 0, TAU); c.fill();
      c.strokeStyle = '#d9d4c8'; c.lineWidth = 3; c.beginPath(); c.moveTo(-32 * face, 0); c.quadraticCurveTo(-42 * face, 8, -38 * face, 16); c.stroke();
    } else {
      const bob = Math.sin(t * 2 + k) * 1.2;
      c.fillStyle = 'rgba(0,0,0,.22)'; c.beginPath(); c.ellipse(0, 0, 42, 6, 0, 0, TAU); c.fill();
      c.scale(face, 1);
      c.fillStyle = '#e9e5dc'; c.fillRect(-30, -42, 6, 42); c.fillRect(-14, -42, 6, 42); c.fillRect(10, -42, 6, 42); c.fillRect(24, -42, 6, 42);
      c.fillStyle = '#f4f1ea'; rr(c, -38, -70 + bob, 76, 38, 14); c.fill();
      c.fillStyle = '#3b3b44'; rr(c, -26, -66 + bob, 20, 14, 6); c.fill(); rr(c, 4, -56 + bob, 18, 14, 6); c.fill();
      c.fillStyle = '#f4f1ea'; rr(c, 30, -74 + bob, 26, 24, 8); c.fill();
      c.fillStyle = '#e8a6a6'; rr(c, 46, -62 + bob, 12, 12, 5); c.fill();
      c.fillStyle = '#2a2a30'; c.fillRect(42, -68 + bob, 3, 3);
      c.fillStyle = '#c9c1ac'; c.fillRect(34, -80 + bob, 4, 8); c.fillRect(46, -80 + bob, 4, 8);
      c.strokeStyle = '#d9d4c8'; c.lineWidth = 3; c.beginPath(); c.moveTo(-38, -64 + bob); c.quadraticCurveTo(-48, -50, -44, -34); c.stroke();
      c.fillStyle = '#e8a6a6'; c.fillRect(-6, -34, 10, 6);
    }
    c.restore();
  }

  /* ----- Милиционер Артур Воложин: пиксельный, как Феликс ----- */
  function cop(c, x, y, u) {
    const R = (a, b, w, h, col) => { c.fillStyle = col; c.fillRect(x + a * u, y - (b + h) * u, w * u, h * u); };
    const skin = '#e3b48b', uni = '#33527f', dark = '#1f3354';
    c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(x, y, 7 * u, 1.2 * u, 0, 0, TAU); c.fill();
    R(-5, 0, 4, 2, '#1c1c22'); R(1, 0, 4, 2, '#1c1c22');
    R(-5, 2, 4, 9, dark); R(1, 2, 4, 9, dark);
    R(-9, 11, 3, 10, uni); R(6, 11, 3, 10, uni);
    R(-9, 9, 3, 2, skin); R(6, 9, 3, 2, skin);
    R(-6, 11, 12, 10, uni);
    R(-6, 12, 12, 1, '#c9a227');           // ремень
    R(2, 17, 2, 2, '#f2d36b');             // значок
    R(-4, 21, 8, 7, skin);
    R(-2, 24, 1, 1, '#2b2118'); R(1, 24, 1, 1, '#2b2118');
    R(-2, 22, 4, 1, '#7a3b2c');            // усы
    R(-5, 28, 10, 2, dark); R(-4, 30, 8, 3, uni); R(-1, 31, 2, 1, '#f2d36b'); // фуражка
  }

  /* ----- Полицейская машина с мигалкой ----- */
  function policeCar(c, x, y, t, siren) {
    c.save(); c.translate(x, y);
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 2, 112, 8, 0, 0, TAU); c.fill();
    wheel(c, -62, -16, t * 14); wheel(c, 64, -16, t * 14);
    c.fillStyle = '#f2f4f7'; rr(c, -108, -58, 216, 40, 12); c.fill();
    c.beginPath(); c.moveTo(-76, -58); c.lineTo(-56, -96); c.lineTo(52, -96); c.lineTo(84, -58); c.closePath(); c.fill();
    c.fillStyle = '#2b5fa8'; c.fillRect(-100, -44, 200, 10);
    c.fillStyle = '#bfe6f2'; c.fillRect(-50, -90, 42, 30); c.fillRect(-2, -90, 48, 30);
    c.strokeStyle = '#9aa0a8'; c.lineWidth = 3; c.strokeRect(-50, -90, 42, 30); c.strokeRect(-2, -90, 48, 30);
    const on = siren && Math.sin(t * 18) > 0;
    c.fillStyle = on ? '#ff3b3b' : '#7a2020'; c.fillRect(-26, -106, 22, 10);
    c.fillStyle = on ? '#2a2a2a' : '#3b7bff'; c.fillRect(0, -106, 22, 10);
    if (siren) {
      c.fillStyle = on ? 'rgba(255,60,60,.25)' : 'rgba(60,120,255,.25)'; circle(c, on ? -15 : 11, -100, 46);
    }
    c.fillStyle = '#ffe9a6'; c.fillRect(100, -52, 8, 9); c.fillStyle = '#d23b3b'; c.fillRect(-108, -52, 6, 9);
    c.fillStyle = '#26343f'; c.font = 'bold 14px sans-serif'; c.textAlign = 'center'; c.fillText('МИЛИЦИЯ', 0, -22);
    c.restore();
  }

  /* ----- Здания: супермаркет и отделение ----- */
  function supermarket(c, x, y, w, h) {
    const l = x - w / 2;
    c.fillStyle = '#e8e2d2'; c.fillRect(l, y - h, w, h);
    c.fillStyle = '#3f8f5b'; c.fillRect(l - 8, y - h - 14, w + 16, 34);
    c.fillStyle = '#fff6e6'; c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillText('СУПЕРМАРКЕТ', x, y - h + 10);
    for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#e9748f' : '#fff6e6'; c.fillRect(l + i * (w / 8), y - h + 20, w / 8, 18); }
    c.fillStyle = '#9fd6f0'; c.fillRect(l + 14, y - h + 46, w * 0.5, h * 0.5);
    c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(l + 20, y - h + 52, 12, h * 0.5 - 12);
    c.fillStyle = '#6b7a86'; c.fillRect(l + w * 0.62, y - h * 0.58, w * 0.3, h * 0.58);
    c.fillStyle = '#9fd6f0'; c.fillRect(l + w * 0.64, y - h * 0.55, w * 0.12, h * 0.52); c.fillRect(l + w * 0.78, y - h * 0.55, w * 0.12, h * 0.52);
  }
  function station(c, x, y, w, h, lamp) {
    const l = x - w / 2;
    c.fillStyle = '#b9b2a4'; c.fillRect(l, y - h, w, h);
    c.fillStyle = 'rgba(0,0,0,.1)'; for (let i = 1; i < 6; i++) c.fillRect(l, y - h + i * h / 6, w, 2);
    c.fillStyle = '#33527f'; c.fillRect(l - 6, y - h - 12, w + 12, 30);
    c.fillStyle = '#fff6e6'; c.font = 'bold 20px sans-serif'; c.textAlign = 'center'; c.fillText('МИЛИЦИЯ · ОТДЕЛЕНИЕ', x, y - h + 10);
    c.fillStyle = lamp ? '#4a90ff' : '#2a4a8a'; circle(c, l + 20, y - h - 22, 9);
    c.fillStyle = '#2a2f3a'; c.fillRect(l + 18, y - h + 36, 36, 30); c.fillRect(l + w - 54, y - h + 36, 36, 30);
    c.strokeStyle = '#8f949c'; c.lineWidth = 2; for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(l + 24 + k * 8, y - h + 36); c.lineTo(l + 24 + k * 8, y - h + 66); c.stroke(); c.beginPath(); c.moveTo(l + w - 48 + k * 8, y - h + 36); c.lineTo(l + w - 48 + k * 8, y - h + 66); c.stroke(); }
  }

  return { IMG, load, grad, circle, rr, person, head, hills, pine, pineRow, stars, fireflies, clouds, felix, car, oldHouse, cow, cop, policeCar, supermarket, station, wheel };
})();
