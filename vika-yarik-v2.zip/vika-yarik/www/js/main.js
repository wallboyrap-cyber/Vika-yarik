'use strict';
/* Запуск: подгружаем картинки героев, подгоняем размер и показываем заставку. */
window.addEventListener('resize', fit);
window.addEventListener('orientationchange', () => setTimeout(fit, 150));
fit();
applySettings();
Art.load().then(() => {
  enterScene('splash');
  requestAnimationFrame(frame);
});
try {
  const A = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (A && A.addListener) A.addListener('backButton', onBack);
} catch (e) {}
window.VY = { go, enterScene, SCENES, getState: () => S, setState: s => { S = s; } }; // для отладки
