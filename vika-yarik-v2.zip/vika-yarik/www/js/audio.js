'use strict';
/* Звук и музыка генерируются кодом (WebAudio), отдельных файлов не нужно. */
const Aud = (() => {
  let ctx = null, master = null, musicBus = null;
  let sfxOn = true, musOn = true, step = 0, nextT = 0;
  const hz = n => 440 * Math.pow(2, (n - 69) / 12);

  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
      musicBus = ctx.createGain(); musicBus.gain.value = musOn ? 0.55 : 0; musicBus.connect(master);
      nextT = ctx.currentTime + 0.2;
      setInterval(sched, 120);
    } catch (e) { ctx = null; }
  }

  function tone(f, t0, d, type, v, bus) {
    if (!ctx) return;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(v, t0 + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(bus || master);
    o.start(t0); o.stop(t0 + d + 0.05);
  }

  function sfx(n) {
    if (!ctx || !sfxOn) return;
    const t = ctx.currentTime;
    switch (n) {
      case 'click': tone(660, t, 0.08, 'square', 0.05); break;
      case 'coin':  tone(988, t, 0.09, 'square', 0.06); tone(1319, t + 0.08, 0.18, 'square', 0.06); break;
      case 'pop':   tone(420, t, 0.1, 'triangle', 0.1); tone(640, t + 0.05, 0.1, 'triangle', 0.08); break;
      case 'plant': tone(300, t, 0.12, 'triangle', 0.1); tone(450, t + 0.07, 0.12, 'triangle', 0.08); break;
      case 'water': tone(1100, t, 0.05, 'sine', 0.05); break;
      case 'good':  [523, 659, 784, 1047].forEach((f, i) => tone(f, t + i * 0.09, 0.2, 'triangle', 0.09)); break;
      case 'bad':   tone(220, t, 0.25, 'sawtooth', 0.05); tone(165, t + 0.18, 0.35, 'sawtooth', 0.05); break;
      case 'swap':  tone(520, t, 0.08, 'triangle', 0.08); tone(780, t + 0.07, 0.1, 'triangle', 0.08); break;
      case 'no':    tone(160, t, 0.15, 'square', 0.04); break;
      case 'siren': for (let i = 0; i < 4; i++) tone(i % 2 ? 640 : 880, t + i * 0.22, 0.2, 'square', 0.05); break;
      case 'clank': tone(110, t, 0.35, 'square', 0.08); tone(1400, t, 0.12, 'sawtooth', 0.04); tone(90, t + 0.12, 0.4, 'square', 0.06); break;
      case 'honk':  tone(330, t, 0.22, 'sawtooth', 0.06); tone(415, t, 0.22, 'sawtooth', 0.05); break;
      case 'moo':   tone(130, t, 0.5, 'sawtooth', 0.06); tone(110, t + 0.25, 0.5, 'sawtooth', 0.05); break;
      case 'crash': tone(90, t, 0.25, 'sawtooth', 0.09); tone(60, t + 0.05, 0.3, 'square', 0.07); break;
      case 'boost': [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, t + i * 0.07, 0.2, 'triangle', 0.08)); break;
      case 'door':  tone(180, t, 0.08, 'square', 0.04); tone(140, t + 0.08, 0.1, 'square', 0.04); break;
      case 'sleep': [523, 440, 392, 330].forEach((f, i) => tone(f, t + i * 0.5, 1.0, 'sine', 0.06)); break;
      case 'end':   [392, 330, 262, 196].forEach((f, i) => tone(f, t + i * 0.45, 0.8, 'triangle', 0.1)); break;
    }
  }

  const prog = [[60, 64, 67], [57, 60, 64], [53, 57, 60], [55, 59, 62]];
  const pat = [0, 1, 2, 1, 2, 1, 0, 1];
  function sched() {
    if (!ctx) return;
    if (!musOn || ctx.state !== 'running') { nextT = Math.max(nextT, ctx.currentTime); return; }
    while (nextT < ctx.currentTime + 0.35) {
      const bar = Math.floor(step / 8) % 4, i = step % 8, ch = prog[bar];
      tone(hz(ch[pat[i]] + 12), nextT, 0.3, 'triangle', 0.05, musicBus);
      if (i === 0) tone(hz(ch[0] - 12), nextT, 1.5, 'sine', 0.08, musicBus);
      if (i === 4 && bar % 2 === 1) tone(hz(ch[2] + 19), nextT, 0.5, 'sine', 0.03, musicBus);
      step++; nextT += 0.3125;
    }
  }

  return {
    init, sfx,
    setSfx(v) { sfxOn = v; },
    setMusic(v) { musOn = v; if (musicBus) musicBus.gain.value = v ? 0.55 : 0; },
    suspend() { if (ctx && ctx.state === 'running') ctx.suspend(); },
    resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); },
  };
})();
