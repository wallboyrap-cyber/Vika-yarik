'use strict';
/* Время суток. Сутки идут CFG.dayLen секунд (24 минуты):
   рассвет → утро → день → вечер → ночь. Последние 60 секунд суток — ночь: герои ложатся спать. */
const Day = (() => {
  const PH = [
    { from: 0,    id: 'dawn',    name: 'Рассвет', ic: '🌅' },
    { from: 120,  id: 'morning', name: 'Утро',    ic: '🌤️' },
    { from: 480,  id: 'day',     name: 'День',    ic: '☀️' },
    { from: 900,  id: 'evening', name: 'Вечер',   ic: '🌇' },
    { from: 1380, id: 'night',   name: 'Ночь',    ic: '🌙' },
  ];
  /* цвет освещения (умножается на картинку): белый = день без изменений */
  const KEYS = [
    [0,    [150, 140, 190]], [60,   [255, 200, 170]], [140,  [255, 236, 216]],
    [260,  [255, 255, 255]], [780,  [255, 255, 255]], [920,  [255, 240, 205]],
    [1100, [255, 186, 140]], [1250, [120, 112, 170]], [1380, [62, 72, 130]], [1440, [150, 140, 190]],
  ];

  function phase(t) { let p = PH[0]; for (const q of PH) if (t >= q.from) p = q; return p; }
  function tint(t) {
    t = clamp(t, 0, 1440);
    for (let i = 1; i < KEYS.length; i++) {
      if (t <= KEYS[i][0]) {
        const a = KEYS[i - 1], b = KEYS[i], k = (t - a[0]) / (b[0] - a[0]);
        return [lerp(a[1][0], b[1][0], k), lerp(a[1][1], b[1][1], k), lerp(a[1][2], b[1][2], k)];
      }
    }
    return [255, 255, 255];
  }
  /* 0 — светло, 1 — совсем темно */
  function dark(t) { const c0 = tint(t); return clamp(1 - (c0[0] + c0[1] + c0[2]) / 765, 0, 1) * 1.7; }

  /* Накладывает освещение на уже нарисованную сцену. */
  function apply(g, t) {
    const k = tint(t);
    if (k[0] > 250 && k[1] > 250 && k[2] > 250) return;
    g.save(); g.globalCompositeOperation = 'multiply';
    g.fillStyle = 'rgb(' + (k[0] | 0) + ',' + (k[1] | 0) + ',' + (k[2] | 0) + ')'; g.fillRect(0, 0, 960, 540);
    g.restore();
  }

  /* Солнце/луна по небу: рисуется ДО холмов, чтобы заходить за горизонт. y0 — линия горизонта, amp — высота дуги. */
  function sun(g, t, y0, amp) {
    const p = (t - 20) / 1260;
    if (p > 0 && p < 1) {
      const x = 40 + p * 580, y = y0 - Math.sin(p * Math.PI) * amp;
      g.fillStyle = 'rgba(255,230,150,.28)'; Art.circle(g, x, y, 46);
      g.fillStyle = '#fff1b8'; Art.circle(g, x, y, 26);
    } else {
      const q = ((t + 1440 - 1240) % 1440) / 260;     // луна от вечера до рассвета
      if (q >= 0 && q <= 1) {
        const x = 60 + q * 540, y = y0 - Math.sin(q * Math.PI) * amp * 0.9;
        g.fillStyle = 'rgba(220,230,255,.2)'; Art.circle(g, x, y, 34);
        g.fillStyle = '#f2f4ff'; Art.circle(g, x, y, 20);
        g.fillStyle = 'rgba(160,170,210,.5)'; Art.circle(g, x - 6, y - 4, 4); Art.circle(g, x + 6, y + 6, 3);
      }
    }
  }
  /* Звёзды ночью — рисуются ПОСЛЕ освещения, в верхней части неба. */
  function stars(g, t, h) {
    const d = clamp((dark(t) - 0.45) * 2.2, 0, 1); if (d <= 0) return;
    g.save(); g.globalAlpha = d;
    for (let i = 0; i < 46; i++) {
      const x = (i * 97) % 660, y = 10 + (i * 53) % Math.max(40, h - 20), a = 0.4 + 0.6 * Math.abs(Math.sin(T * 1.3 + i));
      g.fillStyle = 'rgba(255,255,230,' + (a * 0.9).toFixed(2) + ')'; g.fillRect(x, y, 2, 2);
    }
    g.restore();
  }

  function label(t) { const p = phase(t); return p.ic + ' ' + p.name; }
  return { phase, tint, dark, apply, sun, stars, label, PH };
})();
