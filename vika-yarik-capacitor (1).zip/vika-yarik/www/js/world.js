'use strict';
/* Основная игра: дом (уборка и мебель), двор (огород), вопросы Вики. */

/* ---------- геометрия дома ---------- */
const ROOM_X = [30, 230, 430], ROOM_W = 200, FL = 410, CEIL = 190;
const PLACE = { bed: [0, 14], wardrobe: [0, 130], stove: [1, 10], table: [1, 78], fridge: [1, 152], sofa: [2, 10], tv: [2, 140] };
const WALLS = { bedwall: ['#e9b7c8', 0], kitwall: ['#bfe3cd', 1], livwall: ['#f0d9a0', 2] };
const TRASH = [
  { x: 75, e: '🗑️' }, { x: 170, e: '📦' }, { x: 265, e: '🪵' },
  { x: 350, e: '📰' }, { x: 490, e: '🍂' }, { x: 585, e: '🧱' },
];
/* ---------- геометрия двора ---------- */
const PX0 = 42, PY0 = 172, PW = 96, PSTRIDE = 80, PCOLS = 6;

const ALL_ITEMS = [].concat.apply([], ROOMS.map(r => r.items));
const CROP = {}; CROPS.forEach(k => CROP[k.id] = k);
const EMOJI_FONT = '"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';

/* ---------- экономика ---------- */
const trashLeft = () => S.trash.filter(x => !x).length;
const trashDone = () => trashLeft() === 0;
function mult() {
  let m = 1; UPGRADES.forEach(u => { if (S.upg[u.id]) m += u.bonus; });
  if (S.char === 'yarik') m *= CFG.yarikFarmBonus;
  if (S.mood > 0) m *= 0.5;
  return m;
}
function income() { let b = 0; S.plots.forEach(p => { if (p) b += CROP[p].rate; }); return b * mult(); }
const price = it => Math.round(it.cost * (S.char === 'vika' ? CFG.vikaDiscount : 1));
const progress = () => ALL_ITEMS.filter(i => S.bought[i.id]).length / ALL_ITEMS.length;

/* ---------- рисование предметов ---------- */
const blob = (x, y, r) => { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); };
const rect = (col, x, y, w, h) => { c.fillStyle = col; c.fillRect(x, y, w, h); };

const IDRAW = {
  bed(x) { rect('#6b4a32', x, FL - 30, 86, 30); rect('#e9e2d6', x + 4, FL - 42, 78, 14); rect('#e9748f', x + 30, FL - 42, 52, 14); rect('#fff', x + 6, FL - 50, 22, 10); rect('#6b4a32', x - 2, FL - 60, 8, 60); },
  wardrobe(x) { rect('#8a5a2b', x, FL - 92, 48, 92); rect('#6e4720', x + 23, FL - 92, 2, 92); rect('#e6c46a', x + 17, FL - 50, 4, 8); rect('#e6c46a', x + 28, FL - 50, 4, 8); },
  stove(x) { rect('#c9ccd2', x, FL - 52, 54, 52); rect('#8e929a', x, FL - 54, 54, 4); rect('#2b2b33', x + 8, FL - 58, 14, 4); rect('#2b2b33', x + 32, FL - 58, 14, 4); rect('#33343c', x + 8, FL - 36, 38, 24); rect('#f4a64a', x + 12, FL - 32, 30, 3); },
  table(x) { rect('#a87a4a', x, FL - 46, 70, 8); rect('#7e5830', x + 6, FL - 38, 6, 38); rect('#7e5830', x + 58, FL - 38, 6, 38); rect('#fff', x + 28, FL - 54, 14, 8); c.fillStyle = '#e9748f'; blob(x + 35, FL - 60, 5); },
  fridge(x) { rect('#eef3f6', x, FL - 92, 44, 92); rect('#b9c4cc', x, FL - 56, 44, 3); rect('#8e9aa3', x + 34, FL - 84, 3, 20); rect('#8e9aa3', x + 34, FL - 50, 3, 22); },
  sofa(x) { rect('#3f8f9c', x, FL - 34, 100, 34); rect('#357c88', x, FL - 62, 100, 30); rect('#2f6f7a', x - 8, FL - 46, 14, 46); rect('#2f6f7a', x + 94, FL - 46, 14, 46); rect('#58b0bd', x + 8, FL - 40, 40, 14); rect('#58b0bd', x + 52, FL - 40, 40, 14); },
  carpet(x) { c.fillStyle = '#d9566f'; c.beginPath(); c.ellipse(x, FL + 4, 54, 9, 0, 0, 7); c.fill(); c.strokeStyle = '#f6c0cc'; c.lineWidth = 2; c.beginPath(); c.ellipse(x, FL + 4, 40, 6, 0, 0, 7); c.stroke(); },
  tv(x) {
    rect('#4a4a55', x + 14, FL - 24, 28, 24); rect('#1b1b22', x, FL - 62, 56, 38);
    const g = c.createLinearGradient(x, 0, x + 56, 0); const k = (T * 0.4) % 1;
    g.addColorStop(0, '#5ac8fa'); g.addColorStop(k, '#ff9bd0'); g.addColorStop(1, '#ffd98a');
    c.fillStyle = g; c.fillRect(x + 3, FL - 59, 50, 32);
  },
};

function drawWindow(x, y, done) {
  if (done) {
    rect('#fdf6e6', x - 4, y - 4, 68, 58); rect('#9fd6f0', x, y, 60, 50);
    rect('#fdf6e6', x + 28, y, 4, 50); rect('#fdf6e6', x, y + 23, 60, 4);
    rect('rgba(240,96,122,.85)', x, y, 12, 50); rect('rgba(240,96,122,.85)', x + 48, y, 12, 50);
  } else {
    rect('#4c4f57', x, y, 60, 50);
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 8, y + 4); c.lineTo(x + 30, y + 26); c.lineTo(x + 20, y + 44); c.moveTo(x + 30, y + 26); c.lineTo(x + 52, y + 18); c.stroke();
    c.fillStyle = '#7a5a3a';
    c.save(); c.translate(x + 30, y + 25); c.rotate(-0.4); c.fillRect(-42, -5, 84, 10); c.rotate(0.8); c.fillRect(-42, -5, 84, 10); c.restore();
  }
}

function drawRoof(t) {
  const ok = S.bought.roof;
  rect('#7a4b3a', 520, 100, 26, 52);
  c.fillStyle = ok ? '#9a3d3d' : '#5b4a45';
  c.beginPath(); c.moveTo(14, CEIL); c.lineTo(330, 76); c.lineTo(646, CEIL); c.closePath(); c.fill();
  if (ok) {
    c.strokeStyle = 'rgba(0,0,0,.22)'; c.lineWidth = 2;
    for (let y = CEIL - 18; y > 90; y -= 18) { const dx = (CEIL - y) * 2.772; c.beginPath(); c.moveTo(14 + dx, y); c.lineTo(646 - dx, y); c.stroke(); }
  } else {
    c.fillStyle = '#2a2420'; blob(200, 152, 16); blob(420, 140, 12); blob(250, 170, 9);
    c.fillStyle = '#8ec5e8'; c.beginPath(); c.moveTo(285, 124); c.lineTo(345, 108); c.lineTo(362, 144); c.lineTo(300, 152); c.closePath(); c.fill();
    c.strokeStyle = '#7a5a3a'; c.lineWidth = 6; c.beginPath(); c.moveTo(270, 140); c.lineTo(372, 118); c.stroke();
  }
  if (S.bought.porch) {
    for (let k = 0; k <= 20; k++) {
      let x, y;
      if (k <= 10) { const f = k / 10; x = 14 + f * 316; y = CEIL - f * 114; } else { const f = (k - 10) / 10; x = 330 + f * 316; y = 76 + f * 114; }
      const on = Math.sin(t * 3 + k) > -0.3;
      c.fillStyle = ['#ffd98a', '#ff9bd0', '#9be3ff'][k % 3];
      c.globalAlpha = on ? 1 : 0.45; blob(x, y + 10, 4); c.globalAlpha = 1;
    }
  }
}

function drawHouseView(t) {
  Art.grad(c, 0, 432, [[0, '#8ec5e8'], [1, '#f6e7c8']]);
  Art.clouds(c, t);
  Art.hills(c, 360, 18, '#9cc08f', 0.7, 0);
  rect('#6fae6a', 0, 432, W, 108); rect('#5f9a5c', 0, 474, W, 66);
  c.fillStyle = '#c9ad82'; c.beginPath(); c.moveTo(250, 432); c.lineTo(410, 432); c.lineTo(470, 540); c.lineTo(190, 540); c.closePath(); c.fill();

  const cl = S.trash.filter(Boolean).length;
  for (let r = 0; r < 3; r++) {
    const x = ROOM_X[r], wid = ['bedwall', 'kitwall', 'livwall'][r];
    if (S.bought[wid]) {
      rect(WALLS[wid][0], x, CEIL, ROOM_W, FL - CEIL);
      for (let sx = x; sx < x + ROOM_W; sx += 24) rect('rgba(255,255,255,.28)', sx, CEIL, 10, FL - CEIL);
    } else {
      rect('#82776d', x, CEIL, ROOM_W, FL - CEIL);
      rect('rgba(40,30,25,.22)', x + 20 + r * 7, CEIL + 30, 44, 28); rect('rgba(40,30,25,.18)', x + 110, CEIL + 90, 56, 34); rect('rgba(40,30,25,.16)', x + 60, CEIL + 150, 40, 24);
      c.strokeStyle = 'rgba(30,22,18,.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(x + 150, CEIL); c.lineTo(x + 140, CEIL + 40); c.lineTo(x + 156, CEIL + 70); c.stroke();
    }
    drawWindow(x + 70, CEIL + 28, !!S.bought.windows);
  }
  rect('#6d4b33', 30, FL, 600, 22); rect('rgba(0,0,0,.18)', 30, FL - 6, 600, 6);
  c.strokeStyle = 'rgba(0,0,0,.2)'; c.lineWidth = 1; for (let x = 60; x < 630; x += 40) { c.beginPath(); c.moveTo(x, FL); c.lineTo(x - 6, FL + 22); c.stroke(); }
  c.strokeStyle = '#3a2a20'; c.lineWidth = 4; for (let r = 0; r < 3; r++) c.strokeRect(ROOM_X[r], CEIL, ROOM_W, FL - CEIL);

  if (S.bought.carpet) IDRAW.carpet(ROOM_X[2] + 105);
  Object.keys(PLACE).forEach(id => { if (S.bought[id]) IDRAW[id](ROOM_X[PLACE[id][0]] + PLACE[id][1]); });

  c.font = '38px ' + EMOJI_FONT; c.textAlign = 'center';
  TRASH.forEach((tr, i) => { if (!S.trash[i]) { c.fillStyle = '#000'; c.fillText(tr.e, tr.x, FL + 6); } });
  rect('rgba(45,35,28,' + (0.25 * (1 - cl / S.trash.length)).toFixed(2) + ')', 30, CEIL, 600, FL - CEIL);

  drawRoof(t);
  if (S.bought.porch) {
    rect('#b99269', 290, 434, 80, 8); rect('#8f6b49', 280, 442, 100, 8);
    rect('#4a3326', 262, 398, 6, 36); rect('#4a3326', 392, 398, 6, 36);
    c.fillStyle = 'rgba(255,226,154,.3)'; blob(265, 392, 16); blob(395, 392, 16);
    c.fillStyle = '#ffe29a'; blob(265, 392, 6); blob(395, 392, 6);
  }
  c.font = 'bold 13px sans-serif'; c.textAlign = 'left';
  ['Спальня', 'Кухня', 'Гостиная'].forEach((n, i) => { c.fillStyle = S.bought[['bedwall', 'kitwall', 'livwall'][i]] ? 'rgba(40,30,30,.6)' : 'rgba(255,255,255,.8)'; c.fillText(n, ROOM_X[i] + 8, CEIL + 18); });
  if (cl === 0) { c.textAlign = 'center'; c.font = 'bold 17px sans-serif'; c.fillStyle = '#fff6e6'; c.fillText('Нажимай на мусор, чтобы убрать', 330, 292 + Math.sin(t * 4) * 4); }
}

function drawCrop(id, x, y, t, age) {
  const k = age < 0.5 ? 0.4 + age * 1.2 : 1, sw = Math.sin(t * 2 + x * 0.05) * 1.5;
  c.save(); c.translate(x, y); c.scale(k, k);
  if (id === 'bush') {
    c.fillStyle = '#2f7d3d'; blob(-12 + sw, -12, 14); blob(10 + sw, -12, 13); blob(sw, -22, 15);
    c.fillStyle = '#43a357'; blob(-3 + sw, -26, 8);
  } else if (id === 'berry') {
    c.fillStyle = '#3a8f45'; blob(-10 + sw, -9, 11); blob(10 + sw, -9, 11); blob(sw, -16, 11);
    c.fillStyle = '#e03a4e'; blob(-12 + sw, -6, 3); blob(8 + sw, -4, 3); blob(2 + sw, -14, 3); blob(14 + sw, -12, 3); blob(-4 + sw, -2, 3);
  } else if (id === 'pumpkin') {
    c.fillStyle = '#3a8f45'; blob(-20, -8, 9); blob(20, -8, 9);
    c.fillStyle = '#f08a2b'; c.beginPath(); c.ellipse(0, -15, 21, 16, 0, 0, 7); c.fill();
    c.strokeStyle = '#c7681a'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -30); c.lineTo(0, 0); c.moveTo(-10, -29); c.quadraticCurveTo(-14, -15, -10, -1); c.moveTo(10, -29); c.quadraticCurveTo(14, -15, 10, -1); c.stroke();
    rect('#4a7a2f', -2, -34, 5, 8);
  } else if (id === 'apple') {
    rect('#6b4a32', -5, -34, 10, 34);
    c.fillStyle = '#2f7d3d'; blob(-16 + sw, -42, 18); blob(16 + sw, -42, 18); blob(sw, -54, 20);
    c.fillStyle = '#43a357'; blob(sw - 4, -58, 10);
    c.fillStyle = '#e8393f'; blob(-14 + sw, -38, 4); blob(12 + sw, -46, 4); blob(2 + sw, -34, 4); blob(-4 + sw, -56, 4);
  }
  c.restore();
}

function drawYardView(t) {
  Art.grad(c, 0, 150, [[0, '#8ec5e8'], [1, '#f6e7c8']]);
  Art.clouds(c, t);
  Art.hills(c, 120, 12, '#9cc08f', 1.1, 0);
  Art.grad(c, 130, 540, [[0, '#8fd08a'], [1, '#5ea85f']]);
  Art.oldHouse(c, 560, 150, 150, 92, { });
  c.fillStyle = '#e8dcc0'; for (let x = 6; x < 660; x += 22) c.fillRect(x, 140, 10, 34);
  c.fillRect(0, 150, 660, 5); c.fillRect(0, 164, 660, 5);

  const total = CFG.plotsMax;
  for (let i = 0; i < total; i++) {
    const col = i % PCOLS, row = Math.floor(i / PCOLS), x = PX0 + col * PW + 4, y = PY0 + row * PSTRIDE, w = PW - 8, h = 64;
    if (i < S.plotCount) {
      const fl = SCENES.game.wt[i] && T - SCENES.game.wt[i] < 0.35;
      c.fillStyle = fl ? '#7a5636' : '#6b4a32'; Art.rr(c, x, y, w, h, 12); c.fill();
      c.fillStyle = 'rgba(0,0,0,.18)'; for (let k = 0; k < 3; k++) c.fillRect(x + 8, y + 12 + k * 18, w - 16, 3);
      if (S.plots[i]) drawCrop(S.plots[i], x + w / 2, y + h - 10, t, T - (SCENES.game.pt[i] || -9));
      else { c.fillStyle = 'rgba(255,255,255,.22)'; c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.fillText('+', x + w / 2, y + h / 2 + 9); }
    } else if (i < S.plotCount + CFG.plotsStart) {
      c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 2; c.setLineDash([6, 6]); Art.rr(c, x, y, w, h, 12); c.stroke(); c.setLineDash([]);
      if (i === S.plotCount) { c.font = '24px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🔒', x + w / 2, y + h / 2 + 8); }
    }
  }
  if (S.upg.scare) { c.font = '34px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🎃', 630, 215); }
  if (S.upg.ghouse) { c.font = '34px ' + EMOJI_FONT; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🏡', 630, 300); }
}

/* ---------------------------------------------------------------- ИГРА */
SCENES.game = {
  enter(arg) {
    if (!S) S = loadSave() || newState();
    this.view = arg && arg.fresh ? 'yard' : 'house';
    this.fx = []; this.floats = []; this.wt = []; this.pt = [];
    this.saveT = 0; this.afT = 0; this.quizWait = 0; this.evT = rnd(45, 75); this.ax = 300; this.atx = 300; this.px = 230; this.face = 1; this.walk = false; this.pend = -1;
    this.cache = {};
    this.buildHud(); this.renderPanel();
    if (arg && arg.cont) {
      const gone = Math.min((Date.now() - (S.lastSeen || Date.now())) / 1000, 3600), gain = income() * gone;
      if (gone > 10 && gain >= 1) { S.money += gain; toast('Пока вас не было: +$' + fmt(gain)); }
    }
    if (arg && arg.fresh) {
      say([
        { who: 'vika', text: 'Ну вот и дом… Тут столько работы! Крыша течёт, обои отваливаются.' },
        { who: 'yarik', text: 'Зато он наш. Денег осталось 50$, надо зарабатывать.' },
        { who: 'yarik', text: 'Начнём с двора: куст стоит 10$ и приносит 1$ в секунду. Потом уберём мусор в доме и купим мебель.' },
        { who: 'vika', text: 'А я буду иногда спрашивать, помнишь ли ты… всякое. Лучше помни!' },
      ]);
    }
  },
  leave() { save(); },

  /* ----- HUD ----- */
  buildHud() {
    const self = this;
    const hud = el('<div class="hud hit"><div class="stat money"><b id="h-m"></b><small id="h-r"></small></div><div class="stat"><b id="h-h"></b><small>любовь</small></div><div class="prog"><i id="h-pg"></i><span id="h-pt"></span></div><span class="mood" id="h-md"></span><button class="chip" id="h-sw"></button><button class="gear" id="h-g">⚙</button></div>');
    const panel = el('<div class="panel hit"><div class="tabs"><button data-v="house">🏠 Дом</button><button data-v="yard">🌱 Двор</button></div><div class="list" id="list"></div></div>');
    ui.appendChild(hud); ui.appendChild(panel);
    panel.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { click(); self.view = b.dataset.v; self.pend = -1; self.renderPanel(); });
    $('#h-sw').onclick = () => self.swap();
    $('#h-g').onclick = () => self.pause();
    this.paintChip();
  },
  paintChip() {
    const w = S.char;
    $('#h-sw').innerHTML = '<span class="mini ' + w + '"></span><span><b>' + NAMES[w] + '</b><small>' + CHAR_INFO[w].perk + ' · сменить</small></span>';
  },
  swap() {
    S.char = S.char === 'yarik' ? 'vika' : 'yarik'; Aud.sfx('swap');
    this.paintChip(); this.renderPanel();
    toast('Теперь играешь за ' + (S.char === 'vika' ? 'Вику' : 'Ярика') + ': ' + CHAR_INFO[S.char].perk);
  },
  pause() {
    const self = this;
    const m = modal('<h2>Пауза</h2><div class="stack"><button class="btn primary" data-a="r">Продолжить</button><button class="btn" data-a="s">Настройки</button><button class="btn" data-a="m">В главное меню</button></div>');
    m.querySelectorAll('button').forEach(b => b.onclick = () => {
      click(); const a = b.dataset.a;
      if (a === 'r') m.remove();
      else if (a === 's') openSettings();
      else { m.remove(); save(); go('menu'); }
    });
  },
  updateHud() {
    const r = income(), set = (id, v) => { if (this.cache[id] !== v) { this.cache[id] = v; $(id).textContent = v; } };
    set('#h-m', '$' + fmt(S.money));
    set('#h-r', '+' + (r < 10 ? r.toFixed(1) : fmt(r)) + '$/сек');
    set('#h-h', '❤ ' + S.hearts);
    const p = Math.round(progress() * 100);
    set('#h-pt', 'Дом готов на ' + p + '%');
    $('#h-pg').style.width = p + '%';
    set('#h-md', S.mood > 0 ? '😤 ' + (S.sulker === 'vika' ? 'Вика обиделась' : 'Ярик обиделся') + ' · ' + Math.ceil(S.mood) + 'с' : '');
  },

  /* ----- панель покупок ----- */
  renderPanel() {
    const self = this, list = $('#list');
    document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === this.view));
    list.innerHTML = '';
    const add = n => list.appendChild(n);
    if (this.view === 'house') {
      const left = trashLeft();
      add(el('<div class="note ' + (left ? '' : 'ok') + '">' + (left ? '🧹 Мусор: осталось ' + left + ' из ' + S.trash.length + '<br><small>Нажимай на кучи в доме (+$' + CFG.trashReward + ' за каждую)</small>' : '✔ В доме чисто, можно обставлять') + '</div>'));
      ROOMS.forEach(room => {
        add(el('<h3>' + room.name + '</h3>'));
        room.items.forEach(it => {
          const done = !!S.bought[it.id], locked = !done && left > 0, p = price(it);
          const b = el('<button class="item ' + (done ? 'done' : '') + (locked ? ' locked' : '') + '" data-cost="' + (done || locked ? 0 : p) + '"><span class="ic">' + it.icon + '</span><span class="nm">' + it.name + '</span><span class="pr">' + (done ? '✔' : '$' + fmt(p)) + '</span></button>');
          b.onclick = () => self.buyItem(it);
          add(b);
        });
      });
    } else {
      add(el('<div class="note">Выбери растение и нажимай на пустую грядку. Нажми на растение, чтобы полить: +$1.</div>'));
      add(el('<h3>Посадить</h3>'));
      CROPS.forEach(k => {
        const n = S.plots.filter(p => p === k.id).length;
        const b = el('<button class="item ' + (S.tool === k.id ? 'sel' : '') + '" data-cost="' + k.cost + '"><span class="ic">' + ({ bush: '🌿', berry: '🍓', pumpkin: '🎃', apple: '🍎' })[k.id] + '</span><span class="nm">' + k.name + '<small>+$' + k.rate + '/сек · посажено ' + n + '</small></span><span class="pr">$' + fmt(k.cost) + '</span></button>');
        b.onclick = () => { click(); S.tool = k.id; self.renderPanel(); };
        add(b);
      });
      add(el('<h3>Двор</h3>'));
      if (S.plotCount < CFG.plotsMax) {
        const cost = EXPAND_COST[(S.plotCount - CFG.plotsStart) / 6] || 300;
        const b = el('<button class="item" data-cost="' + cost + '"><span class="ic">➕</span><span class="nm">Ещё 6 грядок</span><span class="pr">$' + fmt(cost) + '</span></button>');
        b.onclick = () => self.expand(cost);
        add(b);
      }
      UPGRADES.forEach(u => {
        const done = !!S.upg[u.id];
        const b = el('<button class="item ' + (done ? 'done' : '') + '" data-cost="' + (done ? 0 : u.cost) + '"><span class="ic">' + u.icon + '</span><span class="nm">' + u.name + '<small>' + u.desc + '</small></span><span class="pr">' + (done ? '✔' : '$' + fmt(u.cost)) + '</span></button>');
        b.onclick = () => self.buyUpgrade(u);
        add(b);
      });
    }
    this.refreshAfford();
  },
  refreshAfford() {
    document.querySelectorAll('.item[data-cost]').forEach(b => b.classList.toggle('poor', S.money < +b.dataset.cost));
  },
  spend(n) {
    if (S.money < n) { Aud.sfx('no'); toast('Не хватает $' + fmt(n - S.money)); return false; }
    S.money -= n; return true;
  },
  buyItem(it) {
    if (S.bought[it.id]) return;
    if (!trashDone()) { Aud.sfx('no'); toast('Сначала убери мусор в доме'); return; }
    if (!this.spend(price(it))) return;
    S.bought[it.id] = true; Aud.sfx('coin');
    this.burst(330, 300, 18, '#ffd98a'); this.renderPanel(); this.updateHud();
    if (ALL_ITEMS.every(i => S.bought[i.id]) && !S.finished) this.finale();
  },
  buyUpgrade(u) {
    if (S.upg[u.id]) return;
    if (!this.spend(u.cost)) return;
    S.upg[u.id] = true; Aud.sfx('coin'); this.burst(330, 300, 14, '#7fd19a'); this.renderPanel();
  },
  expand(cost) {
    if (S.plotCount >= CFG.plotsMax) return;
    if (!this.spend(cost)) return;
    S.plotCount += 6; Aud.sfx('coin'); this.renderPanel();
  },
  finale() {
    S.finished = true; save();
    say([
      { who: 'vika', text: 'Ярик… Мы справились. Это правда наш дом.' },
      { who: 'yarik', text: 'Наш. Со всеми скрипучими полами и твоими вопросами.' },
      { who: 'vika', text: 'А помнишь, с чего всё началось? Туалетная бумага на вечеринке…', },
      { who: 'yarik', text: 'Такое не забудешь ❤ Спасибо, что играл! Двор ещё растёт — можно продолжать.' },
    ]);
  },

  /* ----- действия в мире ----- */
  clean(i) {
    S.trash[i] = true; S.money += CFG.trashReward; Aud.sfx('pop');
    this.burst(TRASH[i].x, FL - 20, 12, '#c9b79a'); this.floats.push({ x: TRASH[i].x, y: FL - 50, t: 0, s: '+$' + CFG.trashReward });
    if (trashDone()) { toast('В доме чисто! Теперь можно покупать мебель'); }
    this.renderPanel();
  },
  plot(i) {
    const cx = PX0 + (i % PCOLS) * PW + PW / 2, cy = PY0 + Math.floor(i / PCOLS) * PSTRIDE + 30;
    if (S.plots[i]) {
      if (T - (this.wt[i] || 0) < 0.9) return;
      this.wt[i] = T; S.money += 1; Aud.sfx('water'); this.floats.push({ x: cx, y: cy - 20, t: 0, s: '+$1' });
    } else {
      const k = CROP[S.tool];
      if (!this.spend(k.cost)) return;
      S.plots[i] = k.id; this.pt[i] = T; Aud.sfx('plant'); this.burst(cx, cy, 10, '#7fd19a'); this.renderPanel();
    }
  },
  burst(x, y, n, col) { for (let i = 0; i < n; i++) this.fx.push({ x, y, vx: rnd(-90, 90), vy: rnd(-170, -40), l: rnd(0.5, 0.9), col }); },

  pointer(x, y) {
    if (busy() || x > 660 || y < 60) return;
    if (this.view === 'house') {
      const i = TRASH.findIndex((tr, k) => !S.trash[k] && Math.abs(x - tr.x) < 36 && y > 330 && y < 440);
      if (i >= 0) { this.pend = i; this.atx = TRASH[i].x; return; }
      this.pend = -1; this.atx = clamp(x, 50, 620);
    } else {
      const col = Math.floor((x - PX0) / PW), row = Math.floor((y - PY0) / PSTRIDE), i = row * PCOLS + col;
      if (col >= 0 && col < PCOLS && row >= 0 && y - PY0 - row * PSTRIDE < 66 && i < S.plotCount) { this.plot(i); }
      else if (col >= 0 && col < PCOLS && row >= 0 && i === S.plotCount && i < CFG.plotsMax && y - PY0 - row * PSTRIDE < 66) {
        Aud.sfx('no'); toast('Новые грядки можно купить справа: «Ещё 6 грядок»');
      }
      this.atx = clamp(x, 40, 620);
    }
  },

  startQuiz() {
    this.quizWait = 3; Aud.sfx('swap');
    this.px = clamp(this.ax + (this.ax > 330 ? -300 : 300), 40, 620);
  },
  randomEvent() {
    const ev = EVENTS[Math.floor(Math.random() * EVENTS.length)];
    say([{ who: ev.who, text: ev.text }], () => { S.money += ev.money; Aud.sfx('coin'); toast('💵 +$' + ev.money); });
  },

  /* ----- Вика задаёт вопросы ----- */
  askQuiz() {
    const self = this, asker = S.char === 'yarik' ? 'vika' : 'yarik', gender = S.char === 'yarik' ? 0 : 1;
    let idx;
    if (!S.qFirst) { S.qFirst = true; idx = 0; } else { if (!S.qBag.length) S.qBag = shuffle(QUESTIONS.map((_, i) => i)); idx = S.qBag.pop(); }
    const reward = Math.round(Math.max(40, income() * CFG.quizReward)), q = QUESTIONS[idx], text = q.q.replace(/\{([^|}]+)\|([^}]+)\}/g, (_, a, b) => gender ? b : a);
    const m = modal('<div class="quiz"><div class="qhead"><div class="portrait"></div><div><b>' + NAMES[asker] + '</b><p></p></div></div><div class="opts"></div><div class="qfoot"></div></div>');
    setPortrait($('.portrait', m), asker); $('.qhead p', m).textContent = text;
    const opts = $('.opts', m), foot = $('.qfoot', m); let answered = false;
    shuffle([q.ok].concat(q.bad)).forEach(o => {
      const b = el('<button class="opt"></button>'); b.textContent = o;
      b.onclick = () => {
        if (answered) return; answered = true; const good = o === q.ok;
        opts.querySelectorAll('.opt').forEach(x => { if (x.textContent === q.ok) x.classList.add('good'); });
        if (!good) b.classList.add('wrong');
        const pool = REACT[asker][good ? 'ok' : 'bad'], line = pool[Math.floor(Math.random() * pool.length)];
        if (good) { S.money += reward; S.hearts++; Aud.sfx('good'); self.burst(480, 270, 18, '#ff7a9a'); }
        else { S.mood = CFG.sulkSeconds; S.sulker = asker; Aud.sfx('bad'); }
        foot.innerHTML = '<span></span><button class="btn small primary">Дальше</button>';
        $('span', foot).textContent = line + (good ? '  (+$' + fmt(reward) + ')' : '');
        $('button', foot).onclick = () => { click(); m.remove(); };
      };
      opts.appendChild(b);
    });
  },

  /* ----- цикл ----- */
  update(dt) {
    const pausedNow = busy();
    if (!pausedNow) {
      S.money += income() * dt;
      if (S.mood > 0) S.mood = Math.max(0, S.mood - dt);
      const spd = 240, d = this.atx - this.ax;
      this.walk = Math.abs(d) > 2;
      if (this.walk) { this.ax += clamp(d, -spd * dt, spd * dt); this.face = d > 0 ? 1 : -1; }
      if (this.quizWait > 0) {
        this.quizWait -= dt;
        const tgt = this.ax - 50 * this.face;
        this.px += clamp(tgt - this.px, -330 * dt, 330 * dt);
        if (Math.abs(tgt - this.px) < 10 || this.quizWait <= 0) { this.quizWait = 0; this.askQuiz(); }
      } else {
        this.px += clamp((this.ax - 70 * this.face) - this.px, -200 * dt, 200 * dt);
        S.quizT -= dt;
        if (S.quizT <= 0) { S.quizT = rnd(CFG.quizEvery[0], CFG.quizEvery[1]); this.startQuiz(); }
        this.evT -= dt;
        if (this.evT <= 0) { this.evT = rnd(60, 100); this.randomEvent(); }
      }
      if (this.pend >= 0 && Math.abs(this.ax - TRASH[this.pend].x) < 20) { const i = this.pend; this.pend = -1; this.clean(i); }
    }
    this.fx.forEach(p => { p.l -= dt; p.vy += 420 * dt; p.x += p.vx * dt; p.y += p.vy * dt; });
    this.fx = this.fx.filter(p => p.l > 0);
    this.floats.forEach(f => { f.t += dt; f.y -= 36 * dt; });
    this.floats = this.floats.filter(f => f.t < 1);
    this.afT -= dt; if (this.afT <= 0) { this.afT = 0.25; this.refreshAfford(); }
    this.saveT += dt; if (this.saveT > 5) { this.saveT = 0; save(); }
    this.updateHud();
  },
  draw(g) {
    const t = this.t;
    if (this.view === 'house') drawHouseView(t); else drawYardView(t);
    const feet = this.view === 'house' ? FL + 16 : 522, h = this.view === 'house' ? 124 : 118;
    const other = S.char === 'yarik' ? 'vika' : 'yarik', bob = this.walk ? Math.sin(T * 14) : 0;
    Art.person(g, other, this.px, feet, h * (other === 'vika' ? 0.96 : 1), this.face, bob);
    Art.person(g, S.char, this.ax, feet, h * (S.char === 'vika' ? 0.96 : 1), this.face, bob);
    if (this.quizWait > 0) { g.font = '30px ' + EMOJI_FONT; g.textAlign = 'center'; g.fillStyle = '#000'; g.fillText('💬', this.px, feet - h - 6 - Math.abs(bob) * 4); }
    this.fx.forEach(p => { g.globalAlpha = clamp(p.l * 1.6, 0, 1); g.fillStyle = p.col; g.fillRect(p.x, p.y, 5, 5); });
    g.globalAlpha = 1;
    g.font = 'bold 20px sans-serif'; g.textAlign = 'center'; g.lineWidth = 4; g.strokeStyle = 'rgba(20,20,30,.8)';
    this.floats.forEach(f => { g.globalAlpha = clamp(1.4 - f.t * 1.4, 0, 1); g.strokeText(f.s, f.x, f.y); g.fillStyle = '#ffd98a'; g.fillText(f.s, f.x, f.y); });
    g.globalAlpha = 1;
  },
};
