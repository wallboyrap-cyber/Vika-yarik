'use strict';
/* Отрисовка: спрайты Вики и Ярика (из assets), дядя Феликс, машина, декорации. */
const Art = (() => {
  const IMG = {};
  const SRC = { vika: 'assets/vika.png', yarik: 'assets/yarik.png' };
  const TAU = Math.PI * 2;

  function load() {
    return Promise.all(Object.keys(SRC).map(k => new Promise(res => {
      const im = new Image();
      im.onload = () => { IMG[k] = im; res(); };
      im.onerror = () => res();
      im.src = SRC[k];
    })));
  }

  function grad(c, y0, y1, stops) {
    const g = c.createLinearGradient(0, y0, 0, y1);
    stops.forEach(s => g.addColorStop(s[0], s[1]));
    c.fillStyle = g;
    c.fillRect(0, y0, 960, y1 - y0);
  }
  function circle(c, x, y, r) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
  function rr(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }

  /* Человек стоит ногами в точке (x, y), высота h. face: 1 вправо, -1 влево. */
  function person(c, who, x, y, h, face, bob) {
    const im = IMG[who]; if (!im) return;
    face = face || 1; bob = bob || 0;
    const w = im.width / im.height * h;
    c.fillStyle = 'rgba(0,0,0,.25)';
    c.beginPath(); c.ellipse(x, y, w * 0.38, 5, 0, 0, TAU); c.fill();
    c.save(); c.translate(x, y - Math.abs(bob) * 4); c.scale(face, 1);
    c.drawImage(im, -w / 2, -h, w, h);
    c.restore();
  }
  /* Только голова (для окон машины). */
  function head(c, who, x, y, size) {
    const im = IMG[who]; if (!im) return;
    const s = im.height * 0.30;
    c.drawImage(im, (im.width - s) / 2, 0, s, s, x - size / 2, y - size / 2, size, size);
  }

  function hills(c, baseY, amp, col, seed, shift) {
    c.fillStyle = col; c.beginPath(); c.moveTo(0, 540);
    for (let x = 0; x <= 960; x += 20) {
      const y = baseY + Math.sin((x + shift) * 0.008 + seed) * amp + Math.sin((x + shift) * 0.021 + seed * 2) * amp * 0.4;
      c.lineTo(x, y);
    }
    c.lineTo(960, 540); c.closePath(); c.fill();
  }

  function pine(c, x, y, s, c1, c2) {
    c.fillStyle = '#4a3326'; c.fillRect(x - 3 * s, y - 12 * s, 6 * s, 12 * s);
    for (let i = 0; i < 3; i++) {
      c.fillStyle = i % 2 ? c1 : c2;
      const base = y - (10 + i * 16) * s, w = (42 - i * 9) * s;
      c.beginPath(); c.moveTo(x, base - 34 * s); c.lineTo(x - w / 2, base); c.lineTo(x + w / 2, base); c.closePath(); c.fill();
    }
  }
  function pineRow(c, off, baseY, s, c1, c2, gap) {
    const n = Math.ceil(1100 / gap), total = gap * n;
    for (let i = 0; i < n; i++) {
      const x = (((i * gap - off) % total) + total) % total - 60;
      pine(c, x, baseY + ((i * 7) % 3) * 4, s * (0.9 + ((i * 13) % 5) * 0.05), c1, c2);
    }
  }

  function stars(c, t) {
    for (let i = 0; i < 70; i++) {
      const x = (i * 83) % 960, y = (i * 47) % 260, a = 0.4 + 0.6 * Math.abs(Math.sin(t * 1.3 + i));
      c.fillStyle = 'rgba(255,255,230,' + (a * 0.8).toFixed(2) + ')'; c.fillRect(x, y, 2, 2);
    }
  }
  function fireflies(c, t, n) {
    for (let i = 0; i < n; i++) {
      const x = (i * 137.5) % 960 + Math.sin(t * 0.5 + i) * 22;
      const y = 250 + (i * 61) % 230 + Math.cos(t * 0.7 + i * 2) * 16;
      const a = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.6 + i * 1.7));
      c.fillStyle = 'rgba(255,230,140,' + (a * 0.25).toFixed(2) + ')'; circle(c, x, y, 7);
      c.fillStyle = 'rgba(255,240,170,' + a.toFixed(2) + ')'; circle(c, x, y, 2);
    }
  }
  function clouds(c, t) {
    c.fillStyle = 'rgba(255,255,255,.8)';
    for (let i = 0; i < 5; i++) {
      const x = ((i * 230 + t * 8) % 1200) - 120, y = 50 + (i * 37) % 90;
      circle(c, x, y, 20); circle(c, x + 24, y - 8, 26); circle(c, x + 52, y, 20); c.fillRect(x, y, 52, 20);
    }
  }

  /* ----- Дядя Феликс: пиксельный фермер, нарисован кодом ----- */
  function felix(c, x, y, u) {
    const R = (a, b, w, h, col) => { c.fillStyle = col; c.fillRect(x + a * u, y - (b + h) * u, w * u, h * u); };
    const skin = '#e3b48b', denim = '#3f5f93', plaid = '#b8423c';
    c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(x, y, 7 * u, 1.2 * u, 0, 0, TAU); c.fill();
    R(-5, 0, 4, 2, '#3a2a20'); R(1, 0, 4, 2, '#3a2a20');
    R(-5, 2, 4, 9, denim); R(1, 2, 4, 9, denim);
    R(-9, 11, 3, 10, plaid); R(6, 11, 3, 10, plaid);
    R(-9, 9, 3, 2, skin); R(6, 9, 3, 2, skin);
    R(-6, 11, 12, 10, plaid);
    R(-4, 11, 8, 7, denim);
    R(-5, 18, 2, 3, denim); R(3, 18, 2, 3, denim);
    R(-3, 15, 1, 1, '#f2c14e'); R(2, 15, 1, 1, '#f2c14e');
    R(-7, 14, 1, 7, '#8f2f2b'); R(6, 14, 1, 7, '#8f2f2b');
    R(-4, 21, 8, 8, skin);
    R(-5, 25, 1, 2, skin); R(4, 25, 1, 2, skin);
    R(-4, 21, 8, 3, '#ddd8cc'); R(-2, 24, 4, 1, '#ddd8cc');
    R(-2, 26, 1, 1, '#2b2118'); R(1, 26, 1, 1, '#2b2118');
    R(0, 25, 1, 1, '#c98f69');
    R(-7, 29, 14, 1, '#d9b45a'); R(-4, 30, 8, 4, '#d9b45a'); R(-4, 30, 8, 1, '#8a5a2b');
  }

  /* ----- Машина ----- */
  function wheel(c, x, y, spin) {
    c.save(); c.translate(x, y);
    c.fillStyle = '#1a1a1f'; circle(c, 0, 0, 16);
    c.fillStyle = '#8f949c'; circle(c, 0, 0, 8);
    c.strokeStyle = '#cfd3da'; c.lineWidth = 2; c.rotate(spin);
    for (let i = 0; i < 4; i++) { c.rotate(Math.PI / 2); c.beginPath(); c.moveTo(0, 0); c.lineTo(7, 0); c.stroke(); }
    c.restore();
  }
  function car(c, x, y, spin, bounce, t, people) {
    const b = Math.sin(t * 16) * 1.3 * bounce;
    c.save(); c.translate(x, y);
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 2, 112, 8, 0, 0, TAU); c.fill();
    if (bounce > 0) for (let k = 0; k < 4; k++) {
      c.fillStyle = 'rgba(235,235,235,' + (0.35 - k * 0.08).toFixed(2) + ')';
      circle(c, -114 - k * 16 - ((t * 40) % 16), -16 - k * 4, 5 + k * 2);
    }
    wheel(c, -62, -16, spin); wheel(c, 64, -16, spin);
    c.translate(0, b);
    c.fillStyle = '#d9792f'; rr(c, -108, -58, 216, 40, 12); c.fill();
    c.beginPath(); c.moveTo(-76, -58); c.lineTo(-56, -96); c.lineTo(52, -96); c.lineTo(84, -58); c.closePath(); c.fill();
    c.save(); c.beginPath(); c.rect(-50, -90, 42, 30); c.rect(-2, -90, 48, 30); c.clip();
    c.fillStyle = '#bfe6f2'; c.fillRect(-52, -92, 100, 34);
    if (people !== false) { head(c, 'vika', -28, -72, 40); head(c, 'yarik', 22, -72, 40); }
    c.fillStyle = 'rgba(255,255,255,.16)'; c.fillRect(-52, -92, 100, 9);
    c.restore();
    c.strokeStyle = '#8f4b17'; c.lineWidth = 3; c.strokeRect(-50, -90, 42, 30); c.strokeRect(-2, -90, 48, 30);
    c.fillStyle = '#a85d20'; c.fillRect(-4, -58, 3, 38); c.fillRect(-14, -48, 8, 3);
    c.fillStyle = '#ffe9a6'; c.fillRect(100, -52, 8, 9);
    c.fillStyle = '#d23b3b'; c.fillRect(-108, -52, 6, 9);
    c.fillStyle = '#9aa0a8'; c.fillRect(-112, -26, 10, 6); c.fillRect(102, -26, 10, 6);
    c.fillStyle = 'rgba(110,50,20,.35)'; circle(c, -34, -34, 7); circle(c, 44, -30, 5);
    c.restore();
  }

  /* ----- Старый дом (тот самый) ----- */
  function oldHouse(c, x, y, w, h, o) {
    o = o || {};
    const l = x - w / 2;
    c.fillStyle = o.dark ? '#4b4458' : '#b9a283'; c.fillRect(l, y - h, w, h);
    c.fillStyle = 'rgba(0,0,0,.14)';
    for (let i = 1; i < 8; i++) c.fillRect(l, y - h + i * (h / 8), w, 2);
    c.fillStyle = o.dark ? '#2a2236' : '#6e4a46';
    c.beginPath(); c.moveTo(l - 14, y - h + 6); c.lineTo(x, y - h - h * 0.5); c.lineTo(l + w + 14, y - h + 6); c.closePath(); c.fill();
    c.fillStyle = o.dark ? '#1c1626' : '#43302e';
    c.beginPath(); c.moveTo(x - 30, y - h - 4); c.lineTo(x - 8, y - h - 22); c.lineTo(x + 6, y - h - 2); c.closePath(); c.fill();
    c.fillStyle = o.dark ? '#352b45' : '#7a4b3a'; c.fillRect(l + w * 0.72, y - h - h * 0.42, 22, h * 0.34);
    c.fillStyle = '#4a2f22'; c.fillRect(x - 15, y - h * 0.5, 30, h * 0.5);
    c.fillStyle = '#d9b45a'; circle(c, x + 8, y - h * 0.24, 2);
    [l + w * 0.12, l + w * 0.68].forEach((wx, i) => {
      const wy = y - h * 0.78, ww = w * 0.2, wh = h * 0.24;
      c.fillStyle = o.lit && i === 1 ? '#ffd98a' : '#2a2f3a'; c.fillRect(wx, wy, ww, wh);
      c.strokeStyle = '#e8ddc8'; c.lineWidth = 3; c.strokeRect(wx, wy, ww, wh);
      c.beginPath(); c.moveTo(wx + ww / 2, wy); c.lineTo(wx + ww / 2, wy + wh); c.moveTo(wx, wy + wh / 2); c.lineTo(wx + ww, wy + wh / 2); c.stroke();
    });
    c.fillStyle = '#4f8a4a';
    for (let i = 0; i < 9; i++) { const gx = l + 6 + i * (w / 8.5); c.fillRect(gx, y - 8 - (i % 3) * 3, 3, 8 + (i % 3) * 3); }
    if (o.lit) { c.fillStyle = 'rgba(255,217,138,.12)'; circle(c, l + w * 0.78, y - h * 0.66, 70); }
  }

  return { IMG, load, grad, circle, rr, person, head, hills, pine, pineRow, stars, fireflies, clouds, felix, car, oldHouse };
})();
