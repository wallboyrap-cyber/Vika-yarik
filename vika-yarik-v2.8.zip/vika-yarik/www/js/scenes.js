'use strict';
/* Сцены: заставка → меню → дорога → ферма Феликса → (конец) / игра. */

const TITLE_HTML = '<span class="v">Вика</span><span class="and">и</span><span class="y">Ярик</span>';
const easeOut = p => 1 - (1 - p) * (1 - p);

/* ---------------------------------------------------------------- ЗАСТАВКА */
SCENES.splash = {
  enter() {
    this.hearts = []; this.hn = 0.8; this.leaving = false; this.head = { x: 500, y: 290 };
    ui.appendChild(el('<div class="stitle"><h1 class="logo">' + TITLE_HTML + '</h1><p>Старый дом. Последние деньги. Новая жизнь.</p></div>'));
    ui.appendChild(el('<div class="load"><div class="bar"><i></i></div><span>Загрузка…</span></div>'));
    this.bar = $('.load i');
  },
  pointer() { this.finish(); },
  finish() { if (this.leaving) return; this.leaving = true; go('menu'); },
  update(dt) {
    this.bar.style.width = (clamp((this.t - 2.4) / 2.8, 0, 1) * 100) + '%';
    if (this.t > 5.6) this.finish();
    this.hn -= dt;
    if (this.hn <= 0) { this.hn = 1.4; this.hearts.push({ x: this.head.x, y: this.head.y - 30, a: 1 }); }
    this.hearts.forEach(h => { h.y -= 34 * dt; h.x += Math.sin(h.y * 0.05) * 0.4; h.a -= 0.4 * dt; });
    this.hearts = this.hearts.filter(h => h.a > 0);
  },
  draw(c) {
    const t = this.t;
    Art.grad(c, 0, 540, [[0, '#2b1d4a'], [0.45, '#a8506f'], [0.75, '#f2a46b'], [1, '#f7c98a']]);
    c.fillStyle = 'rgba(255,240,200,.25)'; Art.circle(c, 230, 335, 80);
    c.fillStyle = 'rgba(255,240,200,.95)'; Art.circle(c, 230, 335, 46);
    Art.hills(c, 372, 22, '#6b3f6a', 1, 0);
    Art.hills(c, 420, 18, '#4b3057', 2.3, 0);
    Art.pineRow(c, 0, 440, 0.9, '#3a2a55', '#43315f', 70);
    c.fillStyle = '#35553f'; c.fillRect(0, 470, 960, 70);
    c.fillStyle = '#2b4733'; c.fillRect(0, 500, 960, 40);
    c.strokeStyle = '#4d7a55'; c.lineWidth = 2;
    for (let i = 0; i < 60; i++) { const x = (i * 53) % 960, y = 474 + (i * 29) % 60; c.beginPath(); c.moveTo(x, y); c.lineTo(x - 3, y - 7); c.moveTo(x, y); c.lineTo(x + 3, y - 6); c.stroke(); }

    // дуб с веткой
    c.fillStyle = '#4a3326'; c.beginPath(); c.moveTo(610, 478); c.lineTo(620, 170); c.lineTo(668, 170); c.lineTo(684, 478); c.closePath(); c.fill();
    c.strokeStyle = '#4a3326'; c.lineWidth = 22; c.lineCap = 'round';
    c.beginPath(); c.moveTo(640, 170); c.quadraticCurveTo(560, 100, 450, 116); c.stroke(); c.lineCap = 'butt';
    c.fillStyle = '#2d5a38'; [[560, 90, 70], [650, 70, 90], [730, 120, 70], [600, 150, 60], [690, 150, 70], [500, 80, 40]].forEach(a => Art.circle(c, a[0], a[1], a[2]));
    c.fillStyle = '#3b7045'; [[610, 80, 50], [690, 100, 55], [540, 105, 35]].forEach(a => Art.circle(c, a[0], a[1], a[2]));

    // качели + Вика
    const a = 0.5 * Math.sin(t * 2.0), L = 250, px = 500, py = 112;
    c.save(); c.translate(px, py); c.rotate(a);
    c.strokeStyle = '#d9c9a3'; c.lineWidth = 3;
    c.beginPath(); c.moveTo(-24, 0); c.lineTo(-24, L); c.moveTo(24, 0); c.lineTo(24, L); c.stroke();
    c.fillStyle = '#8a5a2b'; c.fillRect(-32, L, 64, 8);
    const im = Art.IMG.vika;
    if (im) {
      const h = 170, w = im.width / im.height * h, hh = im.height / 2;
      c.save(); c.translate(0, L);
      c.drawImage(im, 0, 0, im.width, hh, -w / 2, -h / 2, w, h / 2);
      c.translate(0, -3); c.rotate(-Math.PI / 2 + 0.28 * Math.sin(t * 4 + 1));
      c.drawImage(im, 0, hh, im.width, hh, -w / 2, 0, w, h / 2);
      c.restore();
    }
    c.restore();
    this.head.x = px - (L - 75) * Math.sin(a); this.head.y = py + (L - 75) * Math.cos(a);

    // Ярик подталкивает
    Art.person(c, 'yarik', 340 - 12 * (a / 0.5), 478, 190, 1, 0);

    this.hearts.forEach(h => { c.globalAlpha = clamp(h.a, 0, 1); c.font = '24px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ff7a9a'; c.fillText('❤', h.x, h.y); });
    c.globalAlpha = 1;
    Art.fireflies(c, t, 14);
  },
};

/* -------------------------------------------------------------------- МЕНЮ */
SCENES.menu = {
  enter() {
    const has = !!loadSave();
    const m = el('<div class="menu"><h1 class="logo">' + TITLE_HTML + '</h1><p class="tag">Старый дом, пара грядок и очень много работы.</p>' +
      (has ? '<button class="btn primary" id="b-cont">Продолжить</button>' : '') +
      '<button class="btn' + (has ? '' : ' primary') + '" id="b-start">Начать</button>' +
      '<button class="btn" id="b-set">Настройки</button>' +
      '<button class="btn" id="b-exit">Выход</button>' +
      '<p class="ver">Вика и Ярик · v2.8</p></div>');
    ui.appendChild(m);
    const on = (id, fn) => { const b = $(id, m); if (b) b.onclick = () => { Aud.init(); click(); fn(); }; };
    on('#b-cont', () => { S = loadSave(); go('game', { cont: true }); });
    on('#b-start', () => go('drive'));
    on('#b-set', openSettings);
    on('#b-exit', quitApp);
    try { const P = window.Capacitor && window.Capacitor.Plugins; if (P && P.StatusBar) P.StatusBar.hide(); } catch (e) {}
  },
  draw(c) {
    const t = this.t, sh = t * 8;
    Art.grad(c, 0, 540, [[0, '#0e1530'], [0.55, '#2b2553'], [1, '#5b3a6b']]);
    Art.stars(c, t);
    c.fillStyle = 'rgba(255,246,214,.15)'; Art.circle(c, 780, 90, 52);
    c.fillStyle = '#fff3cf'; Art.circle(c, 780, 90, 32);
    Art.hills(c, 360, 20, '#241d46', 1, sh * 0.2);
    Art.hills(c, 410, 16, '#1b1a3a', 3, sh * 0.4);
    Art.pineRow(c, sh * 0.5, 430, 1.2, '#1f3b45', '#274a52', 80);
    c.fillStyle = '#18291f'; c.fillRect(0, 462, 960, 78);
    Art.oldHouse(c, 740, 470, 230, 150, { dark: true, lit: true });
    const gl = c.createRadialGradient(740, 430, 10, 740, 430, 230); gl.addColorStop(0, 'rgba(255,200,120,.28)'); gl.addColorStop(1, 'rgba(255,200,120,0)');
    c.fillStyle = gl; c.fillRect(480, 200, 480, 340);
    Art.person(c, 'vika', 665, 520, 300, 1, 0);
    Art.person(c, 'yarik', 800, 520, 300, 1, 0);
    Art.fireflies(c, t, 22);
  },
};

/* ------------------------------------------------------------------ ДОРОГА */
// сколько всего «проезжает» дорога за сцену (300 px/с до 8.4 с и плавное торможение 1.8 с): 300*8.4 + 300*1.8/2
const DRIVE_STOP_OFF = 300 * 8.4 + 300 * 1.8 / 2;
SCENES.drive = {
  enter() {
    this.off = 0; this.speed = 300; this.done = false; this.mi = -1;
    this.cap = el('<div class="caption"></div>'); ui.appendChild(this.cap);
    const sk = el('<button class="skip hit">Пропустить</button>'); sk.onclick = () => this.finish(); ui.appendChild(sk);
    this.msgs = [[0.3, 'Все сбережения — на один старый дом.'], [3.6, 'Дорога через лес…'], [6.8, 'Ферма дяди Феликса.']];
  },
  finish() { if (this.done) return; this.done = true; go('farm'); },
  update(dt) {
    const t = this.t;
    this.speed = t < 8.4 ? 300 : Math.max(0, 300 * (1 - (t - 8.4) / 1.8));
    this.off += this.speed * dt;
    let k = -1; this.msgs.forEach((m, i) => { if (t >= m[0]) k = i; });
    if (k !== this.mi && k >= 0) {
      this.mi = k; this.cap.classList.remove('in'); void this.cap.offsetWidth;
      this.cap.textContent = this.msgs[k][1]; this.cap.classList.add('in');
    }
    if (t > 10.8) this.finish();
  },
  draw(c) {
    const t = this.t, o = this.off;
    Art.grad(c, 0, 540, [[0, '#78b4d8'], [0.5, '#f4d7a6'], [1, '#fbe9c6']]);
    c.fillStyle = 'rgba(255,245,210,.95)'; Art.circle(c, 760, 120, 42);
    Art.clouds(c, t);
    Art.hills(c, 300, 24, '#9fb98f', 0.5, o * 0.05);
    Art.hills(c, 345, 20, '#6f9d72', 2, o * 0.1);
    Art.pineRow(c, o * 0.25, 372, 1.1, '#3c6b52', '#467a5c', 80);
    Art.pineRow(c, o * 0.5, 396, 1.6, '#2c5a45', '#356a50', 110);
    c.fillStyle = '#5e9a5a'; c.fillRect(0, 398, 960, 40);
    Art.pineRow(c, o * 0.9, 424, 2.2, '#25503c', '#2d5f46', 230);
    c.fillStyle = '#3a3a44'; c.fillRect(0, 430, 960, 110);
    c.fillStyle = '#d8d2c0'; c.fillRect(0, 434, 960, 4);
    c.fillStyle = '#f2e2a0';
    for (let x = -((o * 1.0) % 90); x < 960; x += 90) c.fillRect(x, 488, 48, 6);

    // знак фермы
    // табличка стоит на обочине: её положение привязано к прокрутке дороги (как деревья и разметка),
    // поэтому она подъезжает навстречу машине и остаётся на месте, когда машина встала
    const sx = 740 + Math.max(0, DRIVE_STOP_OFF - o);
    if (sx < 1100) {
      c.fillStyle = '#5a3b2a'; c.fillRect(sx - 4, 340, 8, 92);
      c.fillStyle = '#c99655'; Art.rr(c, sx - 110, 316, 220, 50, 8); c.fill();
      c.strokeStyle = '#6b4a2a'; c.lineWidth = 3; Art.rr(c, sx - 110, 316, 220, 50, 8); c.stroke();
      c.fillStyle = '#3b2616'; c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillText('Ферма Феликса  ➜', sx, 348);
    }
    c.save(); c.translate(400 + Math.sin(t * 0.8) * 6, 520); c.scale(1.4, 1.4);
    Art.car(c, 0, 0, o * 0.07, this.speed > 5 ? 1 : 0, t, true);
    c.restore();
  },
};

/* ------------------------------------------------------------------- ФЕРМА */
const GY = 385; // уровень земли на ферме (над диалоговым окном)
SCENES.farm = {
  enter() {
    this.ppl = { vika: { x: 0, tx: 480, on: false }, yarik: { x: 0, tx: 545, on: false } };
    this.started = false; this.entering = false; this.alpha = 1; this.carX = -170; this.ended = false;
  },
  pointer() {},
  startTalk() {
    const self = this;
    say([
      { who: 'felix', text: 'О, приехали! Добро пожаловать на мою ферму, ребятки.' },
      { who: 'felix', text: 'Вот он, домик. Старый, скрипучий, зато свой. Крыша с характером, полы с историей.' },
      { who: 'felix', text: 'Ну что, ребятки, покупаете этот дом? Пятьсот долларов — и ключи ваши.', choices: [
        { t: 'Да, покупаем!', go: () => self.yes() },
        { t: 'Нет, не сейчас', go: () => self.no() },
      ] },
    ]);
  },
  yes() {
    const self = this;
    S = newState(); Aud.sfx('coin'); toast('💵 −$' + CFG.housePrice + ' · осталось $' + (CFG.startMoney - CFG.housePrice));
    say([
      { who: 'yarik', text: 'Берём!' },
      { who: 'vika', text: 'Берём. Это наш дом.' },
      { who: 'felix', text: 'Держите ключи! Крыша с характером, зато фундамент крепкий. Если что — я рядом, на ферме.' },
    ], () => { self.entering = true; });
  },
  no() {
    say([{ who: 'felix', text: 'Эх… Жаль, ребятки. Может, ещё вернётесь.' }], () => { go('end'); });
  },
  update(dt) {
    const t = this.t;
    this.carX = -170 + 470 * easeOut(Math.min(t / 3, 1));
    const p = this.ppl;
    if (t > 3.3 && !p.vika.on) { p.vika.on = p.yarik.on = true; p.vika.x = this.carX - 20; p.yarik.x = this.carX + 20; }
    if (this.entering) { p.vika.tx = 800; p.yarik.tx = 812; }
    ['vika', 'yarik'].forEach(k => { const q = p[k]; if (q.on) q.x += clamp(q.tx - q.x, -130 * dt, 130 * dt); });
    if (!this.started && t > 4.8 && Math.abs(p.vika.x - p.vika.tx) < 2 && Math.abs(p.yarik.x - p.yarik.tx) < 2) { this.started = true; this.startTalk(); }
    if (this.entering) {
      this.alpha = clamp((800 - p.vika.x) / 50, 0, 1);
      if (!this.ended && this.alpha <= 0.02) { this.ended = true; go('game', { fresh: true }); }
    }
  },
  walking() {
    const p = this.ppl;
    return p.vika.on && (Math.abs(p.vika.x - p.vika.tx) > 2 || Math.abs(p.yarik.x - p.yarik.tx) > 2);
  },
  draw(c) {
    const t = this.t;
    Art.grad(c, 0, 330, [[0, '#6a5aa8'], [0.5, '#f09a78'], [1, '#fbd8a0']]);
    c.fillStyle = 'rgba(255,230,170,.9)'; Art.circle(c, 170, 250, 50);
    Art.clouds(c, t * 0.6);
    Art.hills(c, 270, 18, '#8e7aa0', 1.2, 0);
    Art.hills(c, 305, 14, '#6e8a6a', 2.8, 0);
    // амбар
    c.fillStyle = '#9c3a33'; c.fillRect(70, 250, 130, 80);
    c.fillStyle = '#6e2723'; c.beginPath(); c.moveTo(60, 252); c.lineTo(135, 205); c.lineTo(210, 252); c.closePath(); c.fill();
    c.strokeStyle = '#f2e6d0'; c.lineWidth = 4; c.strokeRect(110, 280, 50, 50); c.beginPath(); c.moveTo(110, 280); c.lineTo(160, 330); c.moveTo(160, 280); c.lineTo(110, 330); c.stroke();
    // земля
    Art.grad(c, 318, 540, [[0, '#8bb36a'], [1, '#4f7d4a']]);
    c.fillStyle = '#c4a574'; c.beginPath(); c.moveTo(0, 360); c.lineTo(960, 346); c.lineTo(960, 410); c.lineTo(0, 428); c.closePath(); c.fill();
    c.fillStyle = '#5a3b2a';
    for (let x = 0; x < 960; x += 44) { c.fillRect(x, 318, 6, 30); }
    c.fillRect(0, 326, 960, 4); c.fillRect(0, 338, 960, 4);

    Art.oldHouse(c, 800, GY - 8, 230, 150, {});
    // табличка
    c.fillStyle = '#5a3b2a'; c.fillRect(710, GY - 40, 5, 40);
    c.fillStyle = '#e8d8b8'; c.fillRect(676, GY - 70, 74, 28);
    c.fillStyle = '#b3342d'; c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.fillText('ПРОДАЁТСЯ', 713, GY - 52);

    Art.felix(c, 640, GY, 4.2);
    const p = this.ppl, bob = this.walking() ? Math.sin(t * 14) : 0;
    c.globalAlpha = this.alpha;
    if (p.vika.on) { Art.person(c, 'vika', p.vika.x, GY, 168, 1, bob); Art.person(c, 'yarik', p.yarik.x, GY, 176, 1, bob); }
    c.globalAlpha = 1;
    Art.car(c, this.carX, GY + 22, this.carX * 0.07, 0, t, !p.vika.on);
    Art.fireflies(c, t, 8);
  },
};

/* ------------------------------------------------------------------- КОНЕЦ */
SCENES.end = {
  enter() {
    this.leaves = []; for (let i = 0; i < 40; i++) this.leaves.push({ x: rnd(0, 960), y: rnd(-540, 0), s: rnd(10, 22), v: rnd(30, 70), r: rnd(0, 6) });
    this.btn = false; Aud.sfx('end');
  },
  update(dt) {
    this.leaves.forEach(l => { l.y += l.v * dt; l.x += Math.sin(this.t + l.r) * 18 * dt; l.r += dt; if (l.y > 560) { l.y = -20; l.x = rnd(0, 960); } });
    if (this.t > 5 && !this.btn) {
      this.btn = true;
      const b = el('<button class="btn endbtn hit">В меню</button>'); b.onclick = () => { click(); go('menu'); }; ui.appendChild(b);
    }
  },
  draw(c) {
    const t = this.t;
    Art.grad(c, 0, 540, [[0, '#0a0b12'], [1, '#1a1426']]);
    this.leaves.forEach(l => { c.save(); c.translate(l.x, l.y); c.rotate(l.r); c.fillStyle = 'rgba(214,140,70,.55)'; c.beginPath(); c.ellipse(0, 0, l.s, l.s * 0.45, 0, 0, Math.PI * 2); c.fill(); c.restore(); });
    const word = 'THE END';
    c.font = 'bold 92px Georgia, "Times New Roman", serif'; c.textAlign = 'left';
    let total = 0; const ws = []; for (const ch of word) { const w = c.measureText(ch).width + 8; ws.push(w); total += w; }
    let x = (960 - total) / 2;
    for (let i = 0; i < word.length; i++) {
      const a = clamp((t - 0.6 - i * 0.28) / 0.6, 0, 1);
      c.globalAlpha = a; c.fillStyle = '#fff6e6'; c.fillText(word[i], x, 270 + (1 - a) * 24); x += ws[i];
    }
    c.globalAlpha = clamp((t - 3.4) / 1, 0, 1);
    c.font = '22px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(255,246,230,.75)';
    c.fillText('Иногда старый дом — это просто чужая история.', 480, 330);
    c.globalAlpha = 1;
  },
};
