'use strict';
/* ==========================================================================
   Ядро: размеры, сохранения, смена сцен, диалоги, окна.
   ========================================================================== */
const W = 960, H = 540;
const $ = (s, r) => (r || document).querySelector(s);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, k) => a + (b - a) * k;
const rnd = (a, b) => a + Math.random() * (b - a);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; };
const fmt = n => String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };

const stage = $('#stage'), cv = $('#cv'), c = cv.getContext('2d'), ui = $('#ui'), fadeEl = $('#fade');

/* ---------- масштаб под любой экран (логический размер 960x540) ---------- */
let RES = 1;   // во сколько раз холст чётче логических 960×540 (чтобы картинка не мылилась на большом экране)
function fit() {
  const s = Math.min(window.innerWidth / W, window.innerHeight / H);
  const r = Math.max(1, Math.min(3, Math.round(s * (window.devicePixelRatio || 1) * 2) / 2));
  if (r !== RES || cv.width !== W * r) { RES = r; cv.width = Math.round(W * r); cv.height = Math.round(H * r); }
  const ox = (window.innerWidth - W * s) / 2, oy = (window.innerHeight - H * s) / 2;
  stage.style.transform = 'translate(' + ox + 'px,' + oy + 'px) scale(' + s + ')';
}

/* ---------- настройки и сохранение ---------- */
const SKEY = 'vika-yarik-settings-v1', GKEY = 'vika-yarik-save-v1';
const settings = { sfx: true, music: true, cam: 'top' };
try { Object.assign(settings, JSON.parse(localStorage.getItem(SKEY) || '{}')); } catch (e) {}
function applySettings() {
  Aud.setSfx(settings.sfx); Aud.setMusic(settings.music);
  try { localStorage.setItem(SKEY, JSON.stringify(settings)); } catch (e) {}
}

let S = null; // состояние игры
const SAVE_VER = 2;
function newState() {
  return {
    v: SAVE_VER, money: CFG.startMoney - CFG.housePrice,
    plots: new Array(CFG.plotsMax).fill(null), plotCount: CFG.plotsStart,
    bought: {}, trash: [false, false, false, false, false, false], upg: {},
    char: 'yarik', hearts: 0, mood: 0, sulker: 'vika', tool: 'bush',
    quizT: CFG.firstQuizIn, qFirst: false, qBag: [], finished: false, lastSeen: Date.now(),
    // версия 2
    clock: 150, day: 1, floors: { 2: false, 3: false, 0: false },
    clones: 0, cows: 0, prod: { milk: 0, cheese: 0 }, food: { vika: 85, yarik: 85 },
    mega: 0, boostT: 0, jail: 0, sus: 0, cowCycle: 0,
  };
}
/* Дополняет старые сохранения недостающими полями (v1 -> v2). */
function migrate(j) {
  const d = newState();
  Object.keys(d).forEach(k => { if (j[k] === undefined) j[k] = d[k]; });
  while (j.plots.length < CFG.plotsMax) j.plots.push(null);
  j.floors = Object.assign({ 2: false, 3: false, 0: false }, j.floors);
  j.prod = Object.assign({ milk: 0, cheese: 0 }, j.prod);
  j.food = Object.assign({ vika: 85, yarik: 85 }, j.food);
  j.v = SAVE_VER; return j;
}
function save() { if (!S) return; try { S.lastSeen = Date.now(); localStorage.setItem(GKEY, JSON.stringify(S)); } catch (e) {} }
function loadSave() {
  try { const j = JSON.parse(localStorage.getItem(GKEY)); return j && (j.v === 1 || j.v === 2) ? migrate(j) : null; } catch (e) { return null; }
}

/* ---------- сцены ---------- */
const SCENES = {};
let scene = null, sceneName = '', T = 0, switching = false;

function enterScene(name, arg) {
  if (scene && scene.leave) scene.leave();
  ui.innerHTML = '';
  sceneName = name; scene = SCENES[name]; scene.t = 0;
  if (scene.enter) scene.enter(arg);
}
function go(name, arg) {
  if (switching) return;
  switching = true;
  fadeEl.classList.add('on');
  setTimeout(() => { enterScene(name, arg); fadeEl.classList.remove('on'); switching = false; }, 460);
}

let lastTs = 0;
function frame(ts) {
  const dt = Math.min(0.05, (ts - lastTs) / 1000 || 0); lastTs = ts; T += dt;
  if (scene) { scene.t += dt; if (scene.update) scene.update(dt); c.setTransform(RES, 0, 0, RES, 0, 0); c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high'; if (scene.draw) scene.draw(c); }
  requestAnimationFrame(frame);
}

cv.addEventListener('pointerdown', e => {
  Aud.init();
  const r = cv.getBoundingClientRect();
  const x = (e.clientX - r.left) * W / r.width, y = (e.clientY - r.top) * H / r.height;
  if (scene && scene.pointer && !switching) scene.pointer(x, y);
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { save(); Aud.suspend(); } else Aud.resume();
});
window.addEventListener('pagehide', save);

/* ---------- окна, подсказки ---------- */
function modal(html, cls) {
  const m = el('<div class="modal hit ' + (cls || '') + '"><div class="card">' + html + '</div></div>');
  ui.appendChild(m); return m;
}
const busy = () => !!ui.querySelector('.modal,.dlg');
function toast(msg) {
  const t = el('<div class="toast">' + msg + '</div>');
  ui.appendChild(t);
  setTimeout(() => t.classList.add('out'), 1900);
  setTimeout(() => t.remove(), 2400);
}
function click() { Aud.sfx('click'); }

function setPortrait(node, who) {
  node.innerHTML = '';
  node.className = 'portrait ' + who;
  if (who === 'felix') {
    const p = document.createElement('canvas'); p.width = p.height = 104;
    Art.felix(p.getContext('2d'), 52, 236, 7);
    node.appendChild(p);
  }
}

/* Диалог: lines = [{who, text, choices:[{t, go}]}], done вызывается после последней реплики. */
function say(lines, done) {
  let i = 0, timer = null, full = '', shown = 0, typing = false;
  const root = el('<div class="dlg hit"><div class="portrait"></div><div class="dbox"><b class="nm"></b><p class="tx"></p><div class="chs"></div><i class="more">▾</i></div></div>');
  ui.appendChild(root);
  const por = $('.portrait', root), nm = $('.nm', root), tx = $('.tx', root), chs = $('.chs', root), more = $('.more', root);

  function close() { clearInterval(timer); root.remove(); }
  function finishType() {
    clearInterval(timer); typing = false; tx.textContent = full;
    const L = lines[i];
    if (L.choices) {
      L.choices.forEach(ch => {
        const b = el('<button class="btn small primary"></button>'); b.textContent = ch.t;
        b.onclick = () => { click(); close(); ch.go(); };
        chs.appendChild(b);
      });
    } else more.style.visibility = 'visible';
  }
  function show() {
    const L = lines[i];
    nm.textContent = NAMES[L.who]; setPortrait(por, L.who);
    chs.innerHTML = ''; more.style.visibility = 'hidden';
    full = L.text; shown = 0; typing = true; tx.textContent = '';
    clearInterval(timer);
    timer = setInterval(() => { shown += 2; tx.textContent = full.slice(0, shown); if (shown >= full.length) finishType(); }, 28);
  }
  root.addEventListener('pointerdown', e => {
    if (e.target.closest && e.target.closest('button')) return;
    if (typing) { finishType(); return; }
    if (lines[i].choices) return;
    i++;
    if (i >= lines.length) { close(); if (done) done(); } else show();
  });
  show();
}

/* ---------- настройки / выход ---------- */
function openSettings() {
  const m = modal('<h2>Настройки</h2>' +
    '<div class="row"><span>Звуки</span><button class="tog" data-k="sfx"></button></div>' +
    '<div class="row"><span>Музыка</span><button class="tog" data-k="music"></button></div>' +
    '<div class="row"><span>Прогресс игры</span><button class="btn small danger" id="rs">Сбросить</button></div>' +
    '<button class="btn small primary" id="cl">Готово</button>');
  const paint = () => m.querySelectorAll('.tog').forEach(b => {
    const on = settings[b.dataset.k]; b.classList.toggle('on', on); b.dataset.l = on ? 'Вкл' : 'Выкл';
  });
  m.querySelectorAll('.tog').forEach(b => b.onclick = () => { settings[b.dataset.k] = !settings[b.dataset.k]; applySettings(); Aud.sfx('click'); paint(); });
  let armed = false; const rs = $('#rs', m);
  rs.onclick = () => {
    if (!armed) { armed = true; rs.textContent = 'Точно сбросить?'; return; }
    try { localStorage.removeItem(GKEY); } catch (e) {}
    S = null; m.remove();
    if (sceneName === 'game') go('menu');
    else if (sceneName === 'menu') { enterScene('menu'); toast('Прогресс сброшен'); }
  };
  $('#cl', m).onclick = () => { click(); m.remove(); };
  paint();
}

function quitApp() {
  const P = window.Capacitor && window.Capacitor.Plugins;
  if (P && P.App && P.App.exitApp) { P.App.exitApp(); return; }
  const m = modal('<h2>До встречи!</h2><p>Спасибо за игру. Приложение можно закрыть.</p><button class="btn small primary" id="bk">Вернуться</button>');
  $('#bk', m).onclick = () => m.remove();
}

/* Кнопка «Назад» на Android */
function onBack() {
  const m = ui.querySelector('.modal');
  if (m) { if (!m.querySelector('.quiz')) m.remove(); return; }
  if (ui.querySelector('.dlg')) return;
  if (sceneName === 'game') SCENES.game.pause();
  else if (sceneName === 'menu') quitApp();
  else if (sceneName === 'drive') SCENES.drive.finish();
  else if (scene && scene.back) scene.back();
}
